$(function() {

	// checkbox on/off on click on div
	$('.alchk').click(function ()
	{
	    var cb = $(this).find(':checkbox');
	    if (cb.is(':checked')) {
	      cb.prop('checked', false);
	    } else {
	      cb.prop('checked', true);
	    }
	});

	//Disable mouse right click
    $(".restrict").on("contextmenu",function(e){
        return false;
    });

	//Fees collection future date off
	$('#Datein').pickadate({
 	 	min: -90,
 	 	max: new Date()
	});
	//15days future and 5days past days limit
    $('.pastdateoff').pickadate({
 	 	min: -90,
 	 	max: +15,
 	 	format: 'dd/mm/yyyy',
 	 	 	 
	 });
    //1yr date limit
    $('.futuredateoff').pickadate({
 	 	min: -90,
 	 	max: +365,
 	 	format: 'dd/mm/yyyy'	 
	 });
    //Only future date off
	$('#future-date-off').pickadate({
 	 	
 	 	min: undefined,
 	 	max: new Date(),
 	 	format: 'dd/mm/yyyy'
	});



		//15days future and 5days past days limit
    $('.pastdateoff').pickadate({
 	 	min: -5,
 	 	max: +15,
 	 	format: 'dd-mm-yyyy'	 
	 });
    //1yr date limit
    $('.futuredateoff').pickadate({
 	 	min: -5,
 	 	max: +365,
 	 	format: 'dd/mm/yyyy'	 
	 });
    //attendence
    $('.attenlimit').pickadate({
 	 	min: -90,
 	 	max: new Date(),
 	 	format: 'dd/mm/yyyy' 
	 });

	$(".load-exponent").delay(500).fadeOut("slow");

	//type js slider on dropin
	$('.typeit-box').typeIt({
		// what to type
		strings : ['Empowering <b>individuals</b> to succeed through digital knowledge.', "Anudip's <b>mission</b> is to make impact with livelihood initiative."],
		// typing speed
		speed : 100,
		// delete speed
		deleteSpeed : 100,
		// make the typing pace irregular
		lifeLike : false,
		// show cursor
		cursor : true,
		// Choose whether you want multiple strings to be printed on top of each other
		breakLines : false,
		// The amount of time between typing multiple strings.
		breakDelay : 750,
		// The amount of time before the plugin begins typing after initalizing.
		startDelay : 200,
		// Have your string or strings continuously loop after completing.
		loop : true,
		// The amount of time between looping over a string or set of strings again.
		loopDelay : 750,
		// Handle strings as HTML, which will process tags and HTML entities
		html : true,
		// Auto start
		autoStart : true,
		// A function that executes after your typing has completed
		callback : function() {
		}
	});

	//sidebar navigation
	$(".button-collapse").sideNav();

	//dropdown
	$(".dropdown-button").dropdown();

	//animated effect of message
	setTimeout(function() {
		$('.success-message').removeClass('bounceInDown').slideUp("normal");
	}, 15000);

	setTimeout(function() {
		$('.error-message').removeClass('bounceInUp').addClass("slideOutRight");
	}, 10000);

	setTimeout(function() {
		$('.danger-message').removeClass('bounceInDown').slideUp("normal");
	}, 10000);

	//selecting text type on radio element
	$(".reset-type").on('click', function() {
		var data_value = $(this).attr('data-type');
		$(".reset-details .input-field").addClass("flipOutX no-display");
		$(".reset-details .input-field").each(function() {
			if ($(this).hasClass(data_value)) {
				$(this).removeClass("no-display flipOutX").addClass("flipInX");
			}
		});
	});

	//animated loader
	paceOptions = {
		ajax : true, // Monitors all ajax requests on the page
		document : true, // Checks for the existance of specific elements on the page
		eventLag : true, // Checks the document readyState
		elements : {
			selectors : ['.top-app-bar'] // Checks for event loop lag signaling that javascript is being executed
		}
	};

	//image materialbox
	$('.materialboxed').materialbox();

	//clockpicker init
	$(".clockpicker").clockpicker({
		placement : 'bottom',
		align : 'left',
		autoclose : true,
		'default' : true
	});

	//datepicker
	//$('.datepicker').pickadate();
	$("input.datepicker").focus(function() {
		if ($(this).hasClass("dob")) {
			var yesterday = new Date((new Date()).valueOf() - 1000 * 60 * 60 * 24 * 365 * 18);
			$(this).pickadate({
				selectMonths : true,
				selectYears : 60,
				max : yesterday
			});
		} else {
			$(this).pickadate({
				format: 'dd/mm/yyyy',
				selectMonths : true, // Creates a dropdown to control month
				selectYears : 15 // Creates a dropdown of 15 years to control year
			});
		}
	});

	//materialize select
	$('select').material_select();

	//called when key is pressed in textbox
	$(".numeric").keypress(function(e) {
		//if the letter is not digit then display error and don't type anything
		if (e.which != 8 && e.which != 0 && (e.which < 48 || e.which > 57)) {
			//display error message
			$("#errmsg").html("Digits Only").show().fadeOut("slow");
			return false;
		}
	});
	$('.demo').attr("placeholder", Date());
});

$(window).on("load", function() {
	var viewportWidth = $(window).width();
	if (viewportWidth < 960) {
		$(".logview").removeClass("slideInLeft");
	}
});

//tooltip function
function tooltip(){
	$('.tooltipped').tooltip({delay: 50,position: 'top'});
}

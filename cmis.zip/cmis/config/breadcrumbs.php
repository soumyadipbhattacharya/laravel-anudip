<?php
return [
	'view' => 'includes/breadcrumb',
];
@extends('layouts.app')
@section('title') Schedule A Batch @stop
@section('content')
<div class="container">
	@include('includes.tabs.batch')
	<div class="row top-margin content-wrapper schedule bottom-margin">
		<div class="col s12 m12 l8 none auto bottom-gap no-padding">
			<h3 class="grey-text text-darken-2 title page-title">Batch Schedule</h3>
			<form class="form-horizontal form-wrapper" role="form" method="post" action="{{url('/post/u/0/batch/schedule')}}" enctype="multipart/form-data">

				<ul class="collapsible" data-collapsible="expandable">
					<li>
						<div class="collapsible-header padding-top-1X bold active grey-text text-darken-1">
							<i class="material-icons orange-text">today</i>Step 1 - Schedule Date
						</div>
						<div class="collapsible-body padding-1x white black-text text-darken-2">
							{{ csrf_field() }}
							<div class="input-field col s12">
								<i class="material-icons prefix grey-text">playlist_add</i>
								<select name="get_batch_trainer_id" id="get_batch_trainer_id" onchange="getDependentValue(this.value,this.id,'show_trainer_id')">
									<option value="" disabled selected>Choose a Batch</option>
									@foreach ($center_info as $ckey => $cvalue)
									<optgroup label="{{$cvalue->short_code}}">
										@foreach ($batch_info as $bkey => $bvalue)
										@if($bvalue->center_id == $cvalue->id)
										<option value="{{$bvalue->batch_id}}" @if(old('get_batch_trainer_id')=="{{$bvalue->batch_id}}") selected="selected" @endif>{{$bvalue->batch_code}}</option>
										@endif
										@endforeach
									</optgroup>
									@endforeach
								</select>
								
							</div>

							<div class="input-field col m6 s12">
						
								<i class="material-icons prefix grey-text">today</i>
								<input type="text" name="start_date" id="" class="pointer today pastdateoff datepicker grey-text text-darken-1" id="start_date" value="{{old('start_date')}}">
								<label for="start_date" class="grey-text text-lighten-1">Start Date</label>

							</div>

							<div class="input-field col m6 s12">
								<i class="material-icons prefix grey-text">today</i>
								<input type="text" id="pastdateoff" name="end_date" class="pointer futuredateoff datepicker grey-text text-darken-1" value="{{old('end_date')}}">
								<label for="end_date" class="grey-text text-lighten-1">End Date</label>
							</div>
						</div>
					</li>
					<li>
						<div class="collapsible-header active grey-text text-darken-1 bold">
							<i class="material-icons orange-text">query_builder</i>Step 2 - Schedule Day & Time
						</div>
						<div class="collapsible-body padding-1x white black-text text-darken-2">
							<div class="input-field col s12">
								<i class="material-icons prefix grey-text">perm_identity</i>
								<select class="icons" name="show_trainer_id"  id="show_trainer_id" disabled>
									<option value="" disabled selected >Choose Trainer</option>
								</select>
								 
							</div>

							<div class="input-field col s12">
								<i class="chip-icon material-icons prefix grey-text">web</i>
								<div class="chip day-selected no-radius col s10 m11 offset-m1 offset-s2 left">
									<input type="checkbox" class="day-check" id="mon" value="Mon" name="day_selected[]" @if(old('day_selected[]')=="Mon") checked="checked" @endif/>
									<label for="mon" class="round waves-effect waves-light center-align">Mon</label>

									<input type="checkbox" class="day-check" id="tue" value="Tue" name="day_selected[]" @if(old('day_selected[]')=="Tue") checked="checked" @endif/>
									<label for="tue" class="round waves-effect waves-light center-align">Tue</label>

									<input type="checkbox" class="day-check" id="wed" value="Wed" name="day_selected[]" @if(old('day_selected[]')=="Wed") checked="checked" @endif/>
									<label for="wed" class="waves-effect waves-light round center-align">Wed</label>

									<input type="checkbox" class="day-check" id="thu" value="Thu" name="day_selected[]"/>
									<label for="thu" class="round waves-effect waves-light center-align">Thu</label>

									<input type="checkbox" class="day-check" id="fri" value="Fri" name="day_selected[]" />
									<label for="fri" class="round waves-effect waves-light center-align">Fri</label>

									<input type="checkbox" class="day-check" id="sat" value="Sat" name="day_selected[]" />
									<label for="sat" class="round waves-effect waves-light center-align">Sat</label>

									<input type="checkbox" class="day-check" id="sun" disabled="" />
									<label for="sun" class="intro-text round white-text red no-border accent-2 center-align">Sun</label>
								</div>
							</div>

							<div class="input-field col m5 s6 input-field-2X">
								<i class="chip-icon material-icons prefix grey-text">query_builder</i>
								<input type="text" name="start_time" class="clockpicker" data-placement="left" data-align="right" data-autoclose="true" class="validate" id="start_time" value="{{old('start_time')}}">
								<label for="start_time" class="grey-text text-lighten-1">Pick Start Time</label>
							</div>

							<div class="input-field col m5 s6 input-field-2X">
								<i class="chip-icon material-icons prefix grey-text">snooze</i>
								<input value="{{old('end_time')}}" type="text" name="end_time" class="clockpicker" data-placement="left" data-align="right" data-autoclose="true" value="" class="validate" id="end_time" >
								<label for="end_time" class="grey-text text-lighten-1">Pick End Time</label>
							</div>
							
							<div class="col m2 s12 input-field-2X clear-on-mobile top-gap">
								<a href="#" class="box-shadow pointer more link green accent-4 white-text bold">
									<i class="material-icons add-icon relative">add</i>Add
								</a>
							</div>
							
							<div id="show-batch-trainer-details" class="clear padding-1x no-display">
								<h5 class="title blue-text text-accent-2 center-align bolder"> Scheduled Batch Details</h5>
								<div class="info-wrapper top-gap"></div>
							</div>
							<div class="right-align padding-1x">
								<button type="submit" class="top-gap waves-effect waves-light btn green accent-4">
									Start Batch <i class="fa fa-btn fa-external-link"></i>
								</button>
							</div>
					</li>
				</ul>
			</form>
		</div>
	</div>
</div>
@include('partials.navigation')
@include('partials.batch')
@endsection
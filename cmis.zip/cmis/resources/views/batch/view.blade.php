@extends('layouts.app')
@section('title') Create Batch @stop
@section('content')
{{-- /*dd($get_batch_info)/* --}}
<div class="container">
	@include('includes.tabs.batch')
	<div class="row top-margin content-wrapper view-batches bottom-margin-2x">
		<h3 class="grey-text text-darken-2 title page-title">View Batches</h3>
		@if(empty($get_batch_info))
		<p class="flow-text white red-text padding-1x">
			No batch record found.
		</p>
		@else
		@foreach($get_batch_info as $key=>$value)
		<div class="col m6 s12">
			<ul class="collapsible" data-collapsible="accordion">
				<li>
					<div class="collapsible-header active">
						<i class="material-icons grey-text">supervisor_account</i>
						<span class="black-text text-darken-1">{{$value->batch_code}}</span>
						<p class="right status-checked margin-top-off bottom-margin-off">
							@if($value->status == "not_started")
							<span class="block pinned-batch-status red accent-3"></span>
							<label class="label status grey-text text-darken-1">Not Started</label>
							@elseif($value->status == "running")
							<span class="block pinned-batch-status green accent-4"></span>
							<label class="label status grey-text text-darken-1">Running</label>
							@elseif($value->status == "complete")
							<i class="material-icons green-text">done_All</i>
							@else
							<span class="block pinned-batch-status orange accent-2"></span>
							<label class="label status grey-text text-darken-1">Paused</label>
							@endif
						</p>
					</div>
					<div class="collapsible-body">
						<p class="white padding-1x">
							<span class="grey-text text-darken-1"> Program Name: </span><span class="black-text">{{$value->program_name}}</span>
							<br/>
							<br/>
							<span class="grey-text text-darken-1">Module Name:</span><span class="black-text">{{$value->name}}</span>
						</p>
					</div>
				</li>
				<li>
					<div class="collapsible-header active">
						<i class="material-icons blue-text">info</i>Click to know more <a href="#show-enrolled-students" class="modal-trigger" onclick="showList({{$value->b_id}})"> <span class="right black-text text-darken-2 tooltipped" data-position="top" data-delay="50" data-tooltip="Total Enrolled"> {{$value->total}}<i class="material-icons grey-text text-darken-1">person_pin</i> </span></a>
					</div>
					<div class="collapsible-body">
						<p class="white padding-1x">
							<span class="grey-text text-darken-1"> Allocated Trainers: </span><span class="black-text"> {{$value->trainers}}</span>
						</p>
					</div>
				</li>
			</ul>
		</div>
		@endforeach
		@endif
	</div>
</div>
<div class="center-align white-text fx-12 footer-search animated slideInUp fixed grey darken-2 row">
	<div class="margin-top-off bottom-margin-off col s12 m6 left grid-status-x">
		<div class="col s6 m4">
			<i class="small material-icons relative">supervisor_account</i>
			@if($get_batch_count == 0)
			<span class="label">No<b class="count spacer">batches found</b></span>
			@else
			<span class="label">Total<b class="count spacer">{{ $get_batch_count }}</b></span>
			@endif
		</div>
		<div class="margin-top-off bottom-margin-off col s6 m5 left-align">
			<i class="small green-text text-accent-3 material-icons relative">check_box</i>
			@if($get_batch_count_running == 0)
			<span class="label"><b class="count spacer">No</b>running batch found</span>
			@else
			<span class="label">Running batches<b class="count spacer">{{ $get_batch_count_running }}</b></span>
			@endif
		</div>
	</div>
	<div class="margin-top-off bottom-margin-off col s12 m6 right grid-status-x">
		<div class="margin-top-off bottom-margin-off col s12 m5 offset-m4">
			<input placeholder="Search for a batch" onkeyup="searchViewBatches(this.value)" id="student-key" type="text" class="bottom-margin-off search-placeholder validate white">
		</div>
	</div>
</div>
<span class="ticker-close pointer fixed"><i class="material-icons white-text fa-3x">expand_more</i></span>
@include('partials.navigation')
@include('partials.batch')

<!-- Modal Structure -->
<div id="show-enrolled-students" class="modal bottom-sheet hidden">
	<div class="modal-content">
		<h5>List Of Enrolled Students <span class="count"></span></h5>
		<p>
			<ul class="collection">
			</ul>
		</p>
	</div>
</div>

@endsection

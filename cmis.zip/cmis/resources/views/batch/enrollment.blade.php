@extends('layouts.app')
@section('title') Enroll Students @stop
@section('content')

<div class="container">
	@include('includes.tabs.batch')
	<div class="row top-margin content-wrapper enrollment">
		<h3 class="grey-text text-darken-2 title page-title">Enroll Students</h3>
		@if(empty($batch_info) || empty($center_info))
			<div class="col s12 m12 none auto bottom-gap no-padding">	
				Nothing to show. <a href="{{URL('/get/u/0/batch/new')}}"> Create</a> batch to start enrollment
			</div>
		@else
		<div class="col s12 m8 none auto bottom-gap no-padding">
			<div class="card white darken-1">
				<div class="card-content padding-1x">
					<form class="form-horizontal support-form" role="form" method="post" action="{{url('post/u/0/batch/enrollment')}}" enctype="multipart/form-data">
						{{ csrf_field() }}
						<div class="input-field col s12">
							<i class="material-icons prefix grey-text text-lighten-2">class</i>
							<select id="getBatchesList" name="getBatchesList" @if(empty($batch_info)) disabled @endif>
								<option value="" selected disabled="">Select a Batch</option>
								@foreach ($center_info as $ckey => $cvalue)
									<optgroup label="{{$cvalue->short_code}}">
										@foreach ($batch_info as $bkey => $bvalue)
										@if($bvalue->center_id == $cvalue->id)
										<option value="{{$bvalue->id}}" @if((!empty($batch_id)) && ($bvalue->id == $batch_id) ) selected @endif>{{$bvalue->batch_code}}</option>
										@endif
										@endforeach
									</optgroup>
								@endforeach
							</select>
						</div>
						
						@if(isset($count_enrolled_students) && isset($get_batch_size))
							<div class="col padding-1x s12 border--normal white grey-text text-darken-2 normal-font fa-1x animated pulse">
								<p class="center-align">
									<a class="active pointer" @if(!empty($batch_id)) onclick="showList({{$batch_id}}) @endif">
										Already Enrolled - 
										<b class="green-text text-accent-4">
											{{$count_enrolled_students}}
										</b> 
									</a>
									&nbsp;&nbsp;&nbsp;
									Max Batch Size - 
									<b class="orange-text text-accent-3">
										{{ $get_batch_size }}
									</b>
								</p>
							</div>
						@endif
						
						<!--suggestion section -->
						<div class="red accent-2 col s12 top-gap small-text">
							<div class="col s2 m1 white-text padding-1x">
										<i class="material-icons left">info_outline</i>
										&nbsp;&nbsp;&nbsp;
							</div>
							<div class="col s10 m11 white-text padding-1x">			
										<strong>Displaying list of students having :</strong>&nbsp;
										1) minimum qualification &nbsp;
										2) paid atleast 50% fee, <br>
										<strong>Submitted Docs :</strong>&nbsp;
										1) Photo &nbsp;
										2) Age Proof &nbsp;
										3) Id Proof &nbsp;
										4) Educational Qualification &nbsp;
										5) Admission Form
	
							</div>
						</div>

						<!--chips start -->
						<div class="input-field col s12">
							<i class="material-icons prefix grey-text text-lighten-2">group</i>
							<h6 class="small-text2 text-lighten-1">Students to Enroll</h6>
						</div>
						<!--chips end -->
						
						<ul class="collection center-align">
							@if(empty($get_students_list))
							<li class="collection-item red-text text-accent-2">
								No eligible students found
							</li>
							@else
							@foreach($get_students_list as $key=>$value)
							<li class="collection-item avatar alchk pointer">
								<i class="circle grey white-text darken-1 bolder">{{$value['name_alias']}}</i>
								<h4 class="title left-align"> {{$value['t_f_name']}} {{$value['t_l_name']}} &nbsp;&nbsp; 
									<span class="blue code white-text box-shadow right relative">{{$value['t_code']}}</span>
									<span class="orange-text text-darken-3 relative right amount no-border bold">&#x20b9; {{$value['t_paid_fees']}}</span></h4>
								<a href="#!" class="secondary-content right">
								<input type="checkbox" name="valid_students[{{$value['t_id']}}]" class="filled-in" value="{{$value['t_paid_fees']}}" id="stud{{$value['t_id']}}"/>
								<label for="stud{{$value['t_id']}}" class="waves-effect"></label> </a>
							</li>
							@endforeach
							@endif
						</ul>
						
						<div class="right-align">
							<button type="submit" class=" waves-effect waves-light btn green accent-4">
								Enroll Student <i class="fa fa-btn fa-external-link"></i>
							</button>
							<div>
					</form>
				</div>
			</div>
		</div>
	</div>
	@endif
</div>
</div>

@include('partials.navigation')
@include('partials.batch')

<!-- Modal Structure -->
<div id="show-enrolled-students" class="modal bottom-sheet hidden">
	<div class="modal-content">
		<h5 class="black-text">Enrollment Details <span class="count"></span></h5>
		<p>
			<ul class="collection">
			</ul>
		</p>
	</div>
</div>
@endsection
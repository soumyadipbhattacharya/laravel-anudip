@extends('layouts.app')
@section('title') Create Batch @stop
@section('content')

<div class="container">
	@include('includes.tabs.batch')
	<div class="row top-margin content-wrapper batch-creation">
		<div class="col s12 m8 none auto bottom-gap no-padding">
			<h3 class="grey-text text-darken-2 title page-title">Create Batch</h3>
			<div class="card white darken-1">
				<div class="card-content padding-1x">
					<form class="form-horizontal support-form" role="form" method="post" action="{{url('/post/u/0/batch/new')}}" enctype="multipart/form-data">
						{{ csrf_field() }}

						<div class="input-field col s12 m12 no-display">
							<i class="material-icons prefix grey-text text-lighten-2">assignment_ind</i>
							<input id="unique_batch_id" name="unique_batch_id" type="text" readonly="readonly" class="validate red-text text-lighten-1" value="@if(Session::has('unique_batch_id')){{Session::get('unique_batch_id')}}@endif">
							<label for="icon_prefix" class="grey-text text-darken-1">Batch Id</label>
						</div>

						<div class="input-field col s12 m12">
							<i class="material-icons prefix grey-text text-lighten-2">store</i>
							<select name="batchx_center_id" id="batchx_center_id" class="icons" onchange="getDependentValue(this.value,this.id,'batchx_program_id')">
								<option value="" disabled selected>Choose a Center</option>
								@foreach($centers as $center)
								<option value="{{$center -> id}}" data-icon="http://static.wixstatic.com/media/0be6f0_ae2a9b5ebd054af5ba3c0f0231ac4a52.png" class="left circle" @if($center->id == old('centre_code')) selected @endif>{{$center -> short_code}}</option>
								@endforeach
							</select>
						</div>

						<div class="input-field col s12 m12">
							<i class="material-icons prefix grey-text text-lighten-2">subject</i>
							<select name="batchx_program_id" id="batchx_program_id" class="icons " disabled onchange="getDependentValue(this.value,this.id,'batchx_module_id')" disabled>
								<option value="" disabled selected>Choose a Program</option>
							</select>
						</div>

						<div class="input-field col s12 m12">
							<i class="material-icons prefix grey-text text-lighten-2">description</i>
							<select name="batchx_module_id" class="icons" id="batchx_module_id" disabled onchange="getDependentValue(this.value,this.id,'batchx_trainer_id')" disabled>
								<option value="" disabled selected>Choose Batch Module</option>
							</select>
						</div>

						<div class="input-field col s12">
							<i class="material-icons prefix grey-text text-lighten-2">people_outline</i>
							<select multiple name="batchx_trainer_id[]" class="icons" id="batchx_trainer_id" disabled>
								<option value="" disabled selected>Choose Trainer (One or more)</option>
							</select>
						</div>

						<div class="input-field col s12">
							<i class="material-icons prefix">mode_edit</i>
							<textarea id="batchx_description" name="batchx_description" class="materialize-textarea"></textarea>
							<label for="batchx_description" class="text-darken-1">Description</label>
						</div>

						<div class="right-align">
							<button type="submit" class=" waves-effect waves-light btn green accent-4">
								Create Batch <i class="fa fa-btn fa-external-link"></i>
							</button>
							<div>
					</form>
				</div>
			</div>
		</div>
	</div>
</div>
</div>

@include('partials.navigation')
@include('partials.batch')
@endsection

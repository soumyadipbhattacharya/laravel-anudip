@extends('layouts.app')
@section('title') Choose A Reset Method @stop
<!-- Main Content -->
@section('content')
<div class="container">
  <div class="row password-reset-check top-margin content-wrapper">
    <div class="col s12 m7 none auto no-padding">
    <h3 class="grey-text text-darken-2 title">Way to reset</h3>
     <div class="card white darken-1">
       <div class="card-content">
        <form class="form-horizontal" role="form" method="post" action="{{ url('/password/reset/post') }}">
          {{ csrf_field() }}
          <input type="hidden" name="client_ip" value=""/>
          <div class="input-field ">
            <input class="with-gap reset-type" data-type="email" name="reset_type" value="1" type="radio" id="email" checked />
            <label for="email">Email</label>
            <!--input class="with-gap reset-type" data-type="mobile" name="reset_type" value="0" type="radio" id="mobile" />
            <label for="mobile">Mobile</label-->
          </div>
          <div class="reset-details">
            <div class="input-field email animated col s12 margin-top-off">
              <i class="material-icons prefix grey-text">email</i>
              <input id="icon_email" type="email" class="validate" name="email" value="{{ old('email') }}">
              <label for="icon_email">Registered Email Address</label>
            </div>
            <!--div class="input-field no-display mobile animated">
              <i class="material-icons prefix grey-text">phonelink_lock</i>
              <input id="icon_mobile" type="text" class="validate" name="mobile" value="{{ old('mobile') }}">
              <label for="icon_mobile">Registered Mobile No.</label>
            </div-->
            <div class="col s12"> 
            {!! app('captcha')->display(); !!}
            </div>
          </div>
          <button type="submit" class="waves-effect waves-light btn green accent-4">
           Reset Password <i class="fa fa-btn fa-external-link"></i> 
         </button>
       </form>
     </div>
   </div>
 </div>
</div>
</div>
@include('partials.getip')
@endsection

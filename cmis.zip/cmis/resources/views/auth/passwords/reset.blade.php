@extends('layouts.app')
@section('title') Change Password @stop
@section('content')
<div class="container">
	<div class="row password-change top-margin content-wrapper">
		<div class="col s12 m7 none auto no-padding">
			<h3 class="grey-text text-darken-2 title">Change Password</h3>
			<form class="form-horizontal" role="form" method="post" action="{{ url('/password/reset') }}">
				{{ csrf_field() }}
				<div class="card white darken-1 animated zoomIn reset-password">
					<div class="card-content">
						<input type="hidden" name="token" value="{{ $token }}">
						<div class="input-field {{ $errors->has('email') ? ' has-error' : '' }}">
							<i class="material-icons prefix grey-text ">email</i>
							<input id="email" type="email" class="validate" name="email" readonly="true" value="{{ $email or old('email') }}">
							<label for="email" data-error="wrong" data-success="right" class="grey-text darken-2-text">Your Email Address</label>
						</div>
						<div class="input-field {{ $errors->has('password') ? ' has-error' : '' }}">
							<i class="material-icons prefix grey-text darken-2-text">https</i>
							<input id="password" type="password" class="validate" name="password">
							<label for="first_name" class="grey-text darken-2-text">Password</label>
						</div>
						<div class="input-field {{ $errors->has('password_confirmation') ? ' has-error' : '' }}">
							<i class="material-icons prefix grey-text darken-2-text">lock_outline</i>
							<input id="password" type="password" class="validate" name="password_confirmation">
							<label for="first_name" class="grey-text darken-2-text">Confirm Password</label>
						</div>
						<div class="check-top client-meta-data">
							<div class="left clear grey-text text-lighten-1 bottom-gap none">We have detected</div>
								<div class="chip amber accent-4 white-text">
								    <i class="fa fa-globe"></i>
								    {{$browser}} Browser
								</div>
								<div class="chip amber accent-4 white-text">
								    <i class="fa fa-desktop"></i>
								    {{$platform}} OS
								</div>
								@if($device)
									<div class="chip amber accent-4 white-text">
									    <i class="fa fa-tablet"></i>
									    {{$device}} Device
									</div>
								@endif
								<div class="chip amber accent-4 white-text">
								    <i class="fa fa-map-marker"></i>
								    <span class="ip_token"></span>
								</div>
							</div>
						<button type="submit" class="waves-effect waves-light btn green accent-4 align-r">
							Update Password <i class="fa fa-btn fa-external-link"></i>
						</button>
					</div>
				</div>
			</form>
		</div>
	</div>
</div>
@include('partials.getip')
@endsection
@extends('layouts.app')
@section('title') Enter OTP Details @stop
<!-- Main Content -->
@section('content')
<div class="container">
	<div class="row password-reset-check top-margin content-wrapper">
		<div class="col s12 m7 none auto no-padding">
			<h3 class="grey-text text-darken-2 title">Verify OTP 
			<a class="otp relative pointer tooltipped" data-position="right" data-delay="50" data-tooltip="We have send an OTP to your registered mobile no."> <i class="small material-icons">error_outline</i> </a></h3>
			<form class="form-horizontal" role="form" method="post" action="{{ url('/password/reset/otp') }}">
				{{ csrf_field() }}
				<div class="card white darken-1 animated zoomIn reset-password">
					<input type="hidden" name="otp_token" value="{{$getToken}}">
					<input type="hidden" name="encode_mobile" value="{{$encode_mobile}}">
					<div class="card-content">
						<div class="check-top">
							<div class="input-field otp animated">
								<i class="material-icons prefix grey-text">perm_device_information</i>
								<input id="icon_otp" type="text" class="validate" name="otp" value="{{ old('otp') }}">
								<label for="icon_otp">Enter code sent to you ( e.g <b>a12f0</b> ) </label>
							</div>
						</div>
						<div class="check-top">
							<div class="input-field password animated">
								<i class="material-icons prefix grey-text">vpn_key</i>
								<input id="icon_password" type="password" class="validate" name="password" value="{{ old('password') }}">
								<label for="icon_password">Enter Password (<b>Must be min. of 6 digits</b>) </label>
							</div>
						</div>
						<div class="check-top">
							<div class="input-field password_confimration animated">
								<i class="material-icons prefix grey-text">vpn_key</i>
								<input id="icon_password_confirmation" type="password" class="validate" name="password_confirmation" value="{{ old('password_confirmation') }}">
								<label for="icon_password_confirmation">Re-enter Password </label>
							</div>
						</div>
						<div class="check-top client-meta-data">
							<div class="left clear grey-text text-lighten-1 bottom-gap none">We have detected</div>
								<div class="chip amber accent-4 white-text">
								    <i class="fa fa-globe"></i>
								    {{$browser}} Browser
								</div>
								<div class="chip indigo accent-4 white-text">
								    <i class="fa fa-desktop"></i>
								    {{$platform}} OS
								</div>
								@if($device)
									<div class="chip teal accent-4 white-text">
									    <i class="fa fa-tablet"></i>
									    {{$device}} Device
									</div>
								@endif
								<div class="chip orange accent-4 white-text">
								    <i class="fa fa-map-marker"></i>
								    <span class="ip_token"></span>
								</div>
							</div>
						<button type="submit" class="waves-effect waves-light btn green accent-4">
							Reset Pasword <i class="fa fa-btn fa-check-circle"></i>
						</button>
					</div>
				</div>
			</form>
		</div>
	</div>
</div>
@include('partials.getip')
@endsection

@extends('layouts.app')
@section('title') Change Password @stop
@section('content')

<div class="container">
	<div class="row top-margin password-change content-wrapper">
		<div class="col s12 m6 none auto no-padding">
			<h3 class="grey-text text-darken-2 title">Change Password</h3>
			<form class="form-horizontal" role="form" method="post" action="{{ url('/u/0/change/password') }}">
				{{ csrf_field() }}
				<div class="card white darken-1 animated zoomIn reset-password">
					<div class="card-content">
						<div class="input-field col s12">
							<i class="material-icons prefix grey-text">lock_open</i>
							<input id="current_password" type="password" class="validate" name="current_password" value="{{old('current_password')}}">
							<label for="current_password" class="grey-text text-darken-2">Current Password</label>
						</div>

						<div class="input-field col s12">
							<i class=" material-icons prefix grey-text">lock_outline</i>
							<input id="password" type="password" class="validate" name="password" value="{{old('password')}}">
							<label for="password" class="grey-text text-darken-2">New Password</label>
						</div>

						<div class="input-field col s12">
							<i class="material-icons prefix grey-text">vpn_key</i>
							<input id="password_confirmation" type="password" class="validate" name="password_confirmation" value="{{old('password_confirmation')}}">

							<label for="password_confirmation" class="grey-text text-darken-2">Confirm Password</label>
						</div>

						<button type="submit" class=" waves-effect waves-light btn green accent-4 align-r">
							Update Password <i class="fa fa-btn fa-external-link"></i>
						</button>
					</div>
				</div>
			</form>
		</div>
	</div>
</div>

@endsection

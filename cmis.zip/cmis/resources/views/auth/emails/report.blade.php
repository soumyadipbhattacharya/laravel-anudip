<body style="background: #4285F4;padding: 10px 20px;
margin: 10px 0; color: #000;
border: 1px solid #e9ecef;
box-shadow: 1px 1px 6px #e9ecef;">
	<p style="padding:25px;">
		<h2 style="color: white; padding-bottom: 10px;">
			Center Wise Report from {{$start}} to {{$end}}
		</h2>
	</p>
	<p style="padding:15px; 0">
		{{--*/ $ta = 0;$tf = 0;$tb = 0;$te = 0;$tbs = 0; /*--}}
			@foreach($report as $key)
				{{--*/ 
					$ta += $key['t_admission']; 
					$tf += $key['t_fee'];
					$tb += $key['t_new_batch'];
					$te += $key['t_enroll'];
					$tbs += $key['t_batchstart']; 
				/*--}}
			@endforeach
		<h4 style="color: white; padding-bottom: 10px;">Total Admissions - {{$ta}}</h4>
		<h4 style="color: white; padding-bottom: 10px;">Total Fees Collected -  {{$tf}}</h4>
		<h4 style="color: white; padding-bottom: 10px;">Total New Batches - {{$tb}}</h4>
		<h4 style="color: white; padding-bottom: 10px;">Total Enrolled Students - {{$te}}</h4>
		<h4 style="color: white; padding-bottom: 10px;">Total Started Batches - {{$tbs}}</h4>
	</p>
	<table style="background-color: #fff; padding: 10px; width: 100%; display: table;">
		<thead>
			<tr style="border-bottom: 1px solid #d0d0d0;">
				<th style="padding: 15px 5px;
				display: table-cell;
				text-align: center;
				vertical-align: middle;
				border-radius: 2px;">Center Id</th>
				<th>Center Name</th>
				<th>Total Admission</th>
				<th>Fees Collected</th>
				<th>New Batch</th>
				<th>Total Enrollment</th>
				<th>Batch Started</th>
			</tr>
		</thead>
		<tbody>

			@foreach($report as $key)
				
				<tr style="border-bottom: 1px solid #d0d0d0;">
					<td style="padding: 15px 5px;
					display: table-cell;
					text-align: center;
					vertical-align: middle;">{{ $key['t_center_id'] }} </td>
					<td style="padding: 15px 5px;
					display: table-cell;
					text-align: center;
					vertical-align: middle;">{{ $key['t_centername'] }}</td>
					<td style="padding: 15px 5px;display: table-cell;text-align: center;vertical-align: middle;"> {{ $key['t_admission'] }}</td>
					<td style="padding: 15px 5px;
					display: table-cell;
					text-align: center;
					vertical-align: middle;">{{ $key['t_fee'] }}</td>
					<td style="padding: 15px 5px;
					display: table-cell;
					text-align: center;
					vertical-align: middle;">{{ $key['t_new_batch'] }}</td>
					<td style="padding: 15px 5px;
					display: table-cell;
					text-align: center;
					vertical-align: middle;">{{ $key['t_enroll'] }}</td>
					<td style="padding: 15px 5px;
					display: table-cell;
					text-align: center;
					vertical-align: middle;">{{ $key['t_batchstart'] }}</td>
				</tr>
			@endforeach
		</tbody>
	</table>
</body>
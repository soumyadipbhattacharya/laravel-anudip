<div style="background: #FCFCFC;padding: 5px 20px; width: 550px;
margin: 10px 0; color: #000;
border: 1px solid #e9ecef;
box-shadow: 1px 1px 6px #e9ecef;">
	<p>
		<h3>Hi {{$full_name}},</h3>
	</p>
		Thank you for contacting us with your concern. We request you to provide us more details.

        The information will help our team in assisting you more effectively. we'll do everything mecessary to address this at the earliest.

		Please keep this ticket no. for future reference to resolve if required.
		<div style="margin-top: 30px;margin-bottom: 40px; text-align: left;">
			<p style="margin-bottom: 40px;">
				<a style="background: #2196F3; text-decoration: none; padding: 15px; color:#fff;" href="#"
					<b>{{$ticket}}</b>
				</a>
			</p>
				<b style="color: grey;">Requested time {{ $time }}</b>.
				
			Meanwhile you can ask further help if you are in emeregency to resolve your issue.<a style="color: #D84A38;text-decoration: none;" href="{{url('support')}}"> Let us know </a> about this hijacking.
			<p style="margin-top: 30px;margin-bottom: 30px;">
				Thanks,<br/>CMIS Team, Anudip Foundation For Social Welfare
			</p>
			<p>
				<b>P.S.</b> We also love hearing from you with any issues you have. Please send us your 
				query and suggestion to tech-team@anudip.org with just saying hi :).
			</p>
		</div>
		<p style="margin-top: 50px;">
			<h6>
				<em>
					Unauthorized use is defined as the use of any computer authorization not assigned to a user 
					for his or her use; and/or any attempt to gain access to a computer or network system for other 
					than legitimate, approved purposes. Each offender will be dealt with on an individual basis, 
					and should expect suspension of computer privileges and possible disciplinary action under standard 
					University rules for misconduct and existing judicial, disciplinary, or personnel processes. 
					Illegal use, including the disclosure of passwords to a computer system, copyright infringement, 
					and the knowing distribution of malicious computer software such as viruses, may be prosecuted under 
					appropriate federal or state law. Other violations to University policy include, but are not limited 
					to, any violation of the University policy on harassment (such as sending harassing memos to other 
					users), as well as abuse of system resources (unnecessary output, chain letters, blocking of 
					communication lines, etc.).
				</em>
			</h6>
		</p>
	</div>
</div>

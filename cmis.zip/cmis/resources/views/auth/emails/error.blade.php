<div style="background: #FCFCFC;padding: 5px 20px; width: 550px;
margin: 10px 0; color: #000;
border: 1px solid #e9ecef;
box-shadow: 1px 1px 6px #e9ecef;">
	<p>
		<h3>Hi {{$first_name}}</h3>
	</p>
		Due to domain relocation issue, CMIS2 will be accessible temporary through below link till next update from tech-team.
		<div style="margin-top: 30px;margin-bottom: 40px; text-align: left;">
			<p style="margin-bottom: 40px;">
				<a style="background: #EA4335; text-decoration: none; padding: 10px; color:#fff;" href="http://14.141.72.149/cmis/public"
					<b>Click here to visit</b>
				</a>
			</p>
			
			<p style="margin-top: 30px;margin-bottom: 30px;">
				Thanks,<br/>CMIS Team, Anudip Foundation For Social Welfare
			</p>
			<p>
				<b>P.S.</b> We also love hearing from you with any issues you have. Please send us your 
				query and suggestion to tech-team@anudip.org with just saying hi :).
			</p>
		</div>
		<p style="margin-top: 50px;">
			<h6>
				<em>
					Unauthorized use is defined as the use of any computer authorization not assigned to a user 
					for his or her use; and/or any attempt to gain access to a computer or network system for other 
					than legitimate, approved purposes. Each offender will be dealt with on an individual basis, 
					and should expect suspension of computer privileges and possible disciplinary action under standard 
					University rules for misconduct and existing judicial, disciplinary, or personnel processes. 
					Illegal use, including the disclosure of passwords to a computer system, copyright infringement, 
					and the knowing distribution of malicious computer software such as viruses, may be prosecuted under 
					appropriate federal or state law. Other violations to University policy include, but are not limited 
					to, any violation of the University policy on harassment (such as sending harassing memos to other 
					users), as well as abuse of system resources (unnecessary output, chain letters, blocking of 
					communication lines, etc.).
				</em>
			</h6>
		</p>
	</div>
</div>

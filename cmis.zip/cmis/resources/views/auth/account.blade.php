@extends('layouts.app')
@section('title') My Account @stop
@section('content')

<div class="container top-margin-x content-wrapper view-my-account">

	<div class="row">
		<h3 class="grey-text text-darken-2 title page-title">Profile Summary</h3>

		<div class="col s12 m4">

			<div class="card white darken-1 center-align secondary-info">
				<div class="card-content grey-text text-darken-3">
					<span class="card-title">
						<img class="circle width-100 profile" src="{{ asset($getMemberinfo[0]->data) }}"/>
					</span>
					<p class="top-gap bottom-gap left-align">
						<i class="material-icons red-text text-darken-1 relative">location_on</i>
						From {{$getMemberinfo[0]->base_location}}
					</p>
					<p class="bottom-gap-2x left-align"> 
						<i class="material-icons orange-text text-darken-1 relative">contacts</i> 
						Member since {{$getMemberinfo[0]->start_date}}
					</p>
					<p class="bottom-gap center-align top-gap">
						<a class="pointer green accent-4 waves-effect waves-light btn width-100" onclick="Materialize.toast('This feature currently unavailable on this version', 4000)">Edit My Profile</a>
					</p>
				</div>
			</div>
		</div>

		<div class="col s12 m8">
			<div class="card white grey-text text-darken-3">
				<div class="card-content grey-text text-darken-2">
					<span class="card-title bolder col s12 ">
						{{$getMemberinfo[0]->first_name}} {{$getMemberinfo[0]->middle_name}} {{$getMemberinfo[0]->last_name}}
					</span>

					<p class="top-gap bottom-gap col m4 ">
						<label class="line-height-x label block">CMIS Member Id</label> 
						{{$getMemberinfo[0]->user_id}}
					</p>
					<p class="top-gap bottom-gap col m4">
						<label class="line-height-x label block">Contact No.</label> 
						+91-{{$getMemberinfo[0]->mobile_no}}
					</p>
					<p class="top-gap bottom-gap col m4">
						<label class="line-height-x label block">Registered Email Address</label> 
						{{$getMemberinfo[0]->email_id}}
					</p>
					<p class="top-gap bottom-gap col m6">
						<label class="line-height-x label block">Designation</label> 
						{{$getMemberinfo[0]->designation}}
					</p>
					<p class="top-gap bottom-gap col m6">
						<label class="line-height-x label block">Department</label> 
						{{$getMemberinfo[0]->department}}
					</p>
					@if(isset($reporting_name[0]) && !empty($reporting_name[0]))
						<p class="top-gap bottom-gap">
							<label class="line-height-x label block">Reporting Member</label> 
							{{$reporting_name[0]->first_name}} 
							{{$reporting_name[0]->middle_name}}
							{{$reporting_name[0]->last_name}}
							({{$reporting_name[0]->member_code}})
						</p>
					@endif
					<hr/>
					
					@if(isset($last_login_info) && !empty($last_login_info))
						<p class="top-gap bottom-gap">
							<label class="line-height-x label block">Last Sigin</label> 
							On <span class="bolder red-text">{{$last_login_info[0]->platform}}</span> platform, using <span class="bolder red-text">{{$last_login_info[0]->browser}}</span> browser at <span class="bolder red-text">{{$last_login_info[0]->last_login_info}}</span> from <span class="bolder red-text">{{$last_login_info[0]->ip}}</span>
							<br/>
						</p>
					@endif
					
					@if(isset($last_password_change_info) && !empty($last_password_change_info))
						<p class="top-gap bottom-gap">
							<label class="line-height-x label block">Last Password Changed</label> 
							On <span class="bolder red-text">{{$last_password_change_info[0]->platform}}</span> platform, using <span class="bolder red-text">{{$last_password_change_info[0]->browser}}</span> browser at <span class="bolder red-text">{{$last_password_change_info[0]->last_password_change_info}}</span> from <span class="bolder red-text">{{$last_password_change_info[0]->ip}}</span>
							<br/>
						</p>
					@endif
					
					<p class="top-gap bottom-gap">
						<label class="line-height-x label block">Last Profile Updated</label> 
						On <span class="bolder red-text">
								{{$getMemberinfo[0]->modified_at}}
							</span>
						<br/>
					</p>
				</div>
			</div>
		</div>
	</div>
</div>
@endsection
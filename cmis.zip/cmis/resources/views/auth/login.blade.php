@extends('layouts.app')
@section('title')
Welcome to CMIS - Livelihood Through Technology 
@stop
@section('content')

<section class="row white-text" data-value="login cmisv2">
	<article class="col s12 m4 card blue logview fixed animated slideInLeft no-margin   dropin-sidebar no-padding fullwidth">
		<div class="center-align">
			<div class="logo">
				<img src="{{ URL::asset('images/anudip-logo-white.png') }}">
			</div>
			<div class="card-content">
				<div class="card-title">
					<i class="small material-icons relative">lock_outline</i>
					<span class="title white-text"> Login to CMIS </span>
				</div>
				<div class="row no-padding">
					<form class="col s12" role="form" method="POST" action="{{ url('/login') }}">
						{{ csrf_field() }} 
						<div class="input-field col s12 no-padding">
							<i class="material-icons prefix">perm_identity</i>
							<input id="user_id" type="text" class="validate active" name="user_id" autocomplete="off" value="{{old('user_id')}}">
							<label for="user_id" class="@if(old('user_id')) active @endif">CMIS Id</label>
						</div>
						
						<div class="input-field col s12 no-padding">
							<i class="material-icons prefix">vpn_key</i>
							<input id="password" type="password" class="validate" name="password" autocomplete="off" value="{{old('password')}}">
							<label for="email" class="@if(old('password')) active @endif">Password</label>

						</div>
						<button class="top-gap col m11 offset-m1 s12 blue-text text-darken-1 waves-effect waves-dark btn white" type="submit">get started<i class="material-icons right">input</i> </button>
						<a href="{{ url('/password/reset') }}" class="white-text change-password-prompt left">
							<i class="fa fa-x fa-question-circle-o" aria-hidden="true"></i> Forgot Password ?
						</a>
					</form>
				</div>
				<div class="row center-align top-margin">
					<div class="col s12 bottom-margin">
						<div class="col s6">
							<a class="link white-text bold" href="{{ url('about/team') }}">Credits</a>
						</div>
						<div class="col s6">
							<a class="link white-text bold" href="{{ url('support') }}">Get Support</a>
						</div>
					</div>
					<div class="col s12 relative center-align appversion white-text">
					    <h6>App Version 2.3</h6>
					    <p>&copy; {{ date('Y')}} Anudip Foundation for Social Welfare</p>
					    <!--
						<span class="white-text">Designed & Developed by <a class="link white-text" href="#">Anudip Tech-Team</a></span>-->
					</div>
				</div>
			</div>
		</div>
	</article>
</section>
<section class="row intro-text footview white-text fixed">
	<article class="left left-align">
		<span class="typeit-box"></span>
	</article>
</section>

@endsection

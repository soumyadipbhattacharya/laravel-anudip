<!DOCTYPE html>
<html>
<head>
    <title>Be right back.</title>

    <link href="https://fonts.googleapis.com/css?family=Lato:100" rel="stylesheet" type="text/css">

    <style>
        html, body {
            height: 100%;
        }

        body {
            margin: 0;
            padding: 0;
            width: 100%;
            color: #555555;
            background: #F4F4F4;
            display: table;
            font-weight: 600;
            font-family: 'Lato', sans-serif;
        }

        .container {
            text-align: center;
            display: table-cell;
            vertical-align: middle;
        }

        .content {
            text-align: center;
            display: inline-block;
        }
        p.image{
            margin-bottom: 0;
            margin-top: 0;
        }
        .center-align{
            text-align: center;
        }
        img{
            width: 80%;
        }
        .title {
            font-size: 250%;
            margin-bottom: 20px;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="content">
            <p class="center-align image"><img src="{{ URL::asset('images/back-soon.png') }}"></p>
            <div class="title">Keep staring. We will be right back.</div>
        </div>
    </div>
</body>
</html>

	@extends('layouts.app')
	@section('title') Human Resource @stop
	@section('content')

	<div class="container">
		<div class="row top-margin content-wrapper students">
			<div class="col s12 m12 l10 none auto bottom-gap no-padding">
				<input type="hidden" name="token" value="{{csrf_token()}}"/>
				<h3 class="grey-text text-darken-2 title page-title">Relocation</h3>
				<div class="row">
					<div class="col s12 m12">
						<div class="card ">
							<div class="card-content  padding-bottom-off padding-top-off">
								{{-- <span class="card-title grey-text text-darken-1">Employee Code</span> --}}
								<div class="row margin-bottom-off">
									<div class="input-field col s12">
										<i class="material-icons prefix">account_circle</i>
										<input value="" id="member_code" class="validate autocomplete member_id" data-type="staff" type="text">
										<input name="member_code" type="hidden" value="">
										<label for="member_code">Enter Employee Code</label>
										<ul class="autocomplete-content dropdown-content absolute suggestion-box animated"></ul>
									</div>
								</div>
							</div>
							<div class="card-action ">
								<div class="row valign-wrapper margin-bottom-off">
									<div class="col s2 avtar">
										<img src="" alt="" class="circle responsive-img" alt="" class="circle responsive-img"> <!-- notice the "circle" class -->
									</div>
									<div class="col s10">
										<span class="black-text">
											<span class=" left col s8 no-padding title  align-center ">

												 	<span class="code-padding blue defaultId white-text fa-x bolder"></span>
										    </span>
											<h5 class="bottom-gap left col s8 no-padding title  align-center defaultName ">Employee Name 
											</h5>
											<div class="col s12 m12 padding-left-off">
												<div class="left col s12 m4	no-padding title"><i class="material-icons modalicon green-text text-lighten-2">phone</i><span class="defaultPhone fa-1_3x blue-text text-darken-4">Contact No.</span></div>
												<div class="left col s12 m5 no-padding title"><i class="material-icons modalicon green-text text-lighten-2">email</i><span class="defaultEmail fa-1_3x blue-text text-darken-4">Email</span></div>
											</div>
											
											<!-- <h5 class="bottom-gap left col s12 no-padding title  align-center memberName">Mera Name</h5> -->
										</span>
									</div>
								</div>
							</div>
						</div>

					</div>



					<!-- list-->
					<div class="assign_form_and_list">
						<div class="col s12 m5">
							<div class="card ">
								<div class="card-action padding-bottom-off">
									<div class="card-content padding-off grey-text text-darken-1 padding-bottom-off padding-top-off">
										<span class="card-title fa-1_3x grey-text text-darken-1">Assign New Role</span>
										<div class="row">
											<div class="input-field col s12">
												<i class="material-icons prefix grey-text">bookmark</i>
												<select name="program_id" id="program_id" onchange="getCenterList(this)">
													<option value="" disabled selected>Choose a Program</option>
													@if(count($get_program_list)>0)
														@foreach($get_program_list as $program)
															<option value="{{$program->id}}">{{$program->name}}</option>
														@endforeach
													@endif
												</select>
											</div>
											<div class="input-field col s12">
												<i class="material-icons prefix grey-text">account_balance</i>
												<select id="center_lists" name="center_ids[]" multiple='multiple' disabled>
													<option value="" disabled selected>Choose centers</option>
												</select>
											</div>
											
											<input name="user_id" id= "user_id" type="hidden" value="">

											<input name="member_id" id= "member_id" type="hidden" value="">
											<div class="input-field col s12">
											<i class="material-icons prefix grey-text">perm_identity</i>
												<select name="role_id" id="role_id">
													<option value="" disabled selected>Choose a role</option>
													@if(count($get_roles)>0)
													@foreach($get_roles as $role)
														<option value="{{$role->id}}">{{ucfirst($role->name)}}</option>
													@endforeach
													@endif
												</select>
											</div>
											<div class="input-field col m12 s12">
												<i class="material-icons prefix grey-text">today</i>
												<input id="future-date-off" type="text" value="<?php echo date('d/m/Y'); ?>" name="from_date" class=" pointer datepicker grey-text text-darken-1 assign_from_date">
												<label for="from_date" class="grey-text text-lighten-1">Class Date</label>
											</div>



											<div class="col s12 clear-on-mobile ">
												<a class="box-shadow pointer more link green accent-4 white-text bold" onclick="assignUser()" href="#">
													<i class="material-icons add-icon relative">add</i>
													Add
												</a>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
						<div class="col s12 m7">
							<div class="card ">
								<div class="card-content grey-text text-darken-2 padding-bottom-off padding-top-off">
									<table class="bordered centered responsive-table">
										<thead id="roleHead">
											<tr>
												<th data-field="id">CENTER</th>
												<th data-field="id">PROGRAM</th>
												<th data-field="name">ROLE</th>
												<th data-field="price">FROM</th>
												<th data-field="action">
												<i class="material-icons tooltipped" data-position="right" data-delay="50" data-tooltip="Remove Role">clear</i>
												</th>
											</tr>
										</thead>
										<tbody id="roleData" class="centered"></tbody>
									</table>
								</div>
							</div>
						</div>
					</div>
					<!--list-->
				</div>

			</div>
		</div>
	</div>
</div>

@include('partials.relocation')
@endsection

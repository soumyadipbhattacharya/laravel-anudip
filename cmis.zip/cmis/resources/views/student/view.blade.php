@extends('layouts.app')
@section('title') Student Details @stop
@section('content')
{{-- {{var_dump($student_details)}} --}}
<div class="container">
	@include('includes.tabs.student')
	<div class="row top-margin content-wrapper view-students bottom-margin-2x students">
		<div class="col s12 m12">
			<h3 class="black-text title page-title left margin-top-off">Admitted Students</h3>
			<!-- student's row-->
			<input type="hidden" name="toggle_view_param" value="{{$param}}"/>
			<div class="grid-toggle right">
				@if($param == "list" || empty($param))
					<a href="{{URL('get/u/0/student/view/list/token=?'.csrf_token())}}" class="view_type_icon toggle pointer active tooltipped" data-position="left" data-delay="50" data-tooltip="Show me in list">
						<i class="material-icons fa-2x">view_list</i>
					</a>
					<a href="{{URL('get/u/0/student/view/grid/token=?'.csrf_token())}}" class="view_type_icon toggle pointer tooltipped" data-position="right" data-delay="50" data-tooltip="Show me in grid">
						<i class="material-icons fa-2x">apps</i>
					</a>
				@else
					<a href="{{URL('get/u/0/student/view/list/token=?'.csrf_token())}}" class="view_type_icon toggle pointer">
						<i class="material-icons fa-2x">view_list</i>
					</a>
					<a href="{{URL('get/u/0/student/view/grid/token=?'.csrf_token())}}" class="view_type_icon toggle pointer active">
						<i class="material-icons fa-2x">apps</i>
					</a>
				@endif
			</div>
		</div>

		@if(empty($student_details))
			<p class="flow-text white red-text padding-1x">No student record found.</p>
		@elseif($param == "list" || empty($param))
			<div class="grid-view-list">
				<ul class="collection">
					@foreach($student_details as $student_detail)
						<li class="collection-item avatar">
							<i class="material-icons circle line-height-x grey lighten-3 fa-1x grey-text text-darken-1">perm_identity</i>
							<h4 class="col s12 m8 neg-margin title left   margin-top-off">
							@if(!empty($student_detail -> member_code))
									<span class="item-details indigo accent-2 white-text spacer"> 
										{{ $student_detail -> member_code }}
									</span>
							@endif
								<a href="#showFileStatus" onclick="showFileStatus({{$student_detail->member_id}},'{{$student_detail->member_code}}');" class="black-text normal-font spacer text-darken-3 modal-trigger pointer top-gap name-break">
									{{ ucwords($student_detail->first_name) }}  {{ ucwords($student_detail -> last_name)}}
								</a>
							</h4>
							<div class="member-list-info right-align ">
								
								@if(!empty($student_detail->total))
									<span class="item-value amber darken-1 white-text spacer">
										{{ $student_detail->total }}
									</span>
								@endif
								<a href="{{URL('/get/u/0/fees/new/'.encrypt($student_detail->member_id))}}" class="spacer icon tooltipped pointer" data-position="top" data-delay="50" data-tooltip="Add New Fee">
									<i class="material-icons grey-text text-darken-1 relative add-icon">open_in_new</i>
								</a>
								<a href="#showFileStatus" onclick="showFileStatus({{$student_detail->member_id}},'{{$student_detail->member_code}}');" class="black-text normal-font spacer modal-trigger tooltipped"  data-position="top" data-delay="50" data-tooltip="Click to check file upload status">
									<i class="material-icons teal-text text-accent-4 relative add-icon">playlist_add_check</i>
								</a>
							</div>
						</li>
					@endforeach
				</ul>
			</div>
			@else
			<div class="grid-view-box">
				@foreach($student_details as $student_detail)
					<div class="card-grid bottom-gap col m3 s12">
							<div class="card">
								<div class="card-image waves-effect waves-block waves-light">
 
 
									<img class="activator" @if(!empty($student_detail->data)) src="{{ URL::asset($student_detail->data)}}" @else src="/cmis/public/images/default-avatar.png" @endif>
 
								</div>
								<div class="card-content padding-1x">
									<div class="card-title activator grey-text text-darken-4">
										<p class="bottom-gap left col s9 m9 no-padding namelimit">{{ ucwords($student_detail->first_name) }} {{ ucwords($student_detail -> last_name)}}</p>
										<i class="material-icons col s2 m2 right">more_vert</i>
									</div>
									<p class="clear quick-info 24x-member-long-code-x"><i class="material-icons left blue-text text-darken-2">assignment_ind</i><a href="#" class="grey-text text-darken-1 ">{{ $student_detail -> member_code }}</a></p>
								
									<p class="clear quick-info"><i class="material-icons left green-text">phone_in_talk</i><a href="#" class="grey-text text-darken-1 ">+91-{{ $student_detail -> mobile_no }}</a></p>

									@if(!empty($student_detail -> total))
									<p class="clear quick-info"><i class="material-icons left orange-text text-darken-2">style</i><a href="#" class="grey-text text-darken-1 ">{{ $student_detail -> total }}</a></p>
									@endif
								</div>
								<div class="card-reveal">
									<span class="card-title grey-text text-darken-4">{{$student_detail->first_name}} {{$student_detail->middle_name}} {{$student_detail->last_name}}
										<i class="material-icons right icon-span close absolute red-text">close</i>
									</span>	
									<h6 class=" blue-text text-darken-1 bold">Address :</h6>					
									<p class="small-font no-margin ">
									{{$student_detail->p_address}}
									</p>

									 @if(empty($student_detail->email_id))
										@else
										<h6 class=" blue-text text-darken-1 bold">Email :</h6>
										<p class="small-font no-margin">
											{{$student_detail->email_id}}
										</p>
										@endif
									@if(empty($student_detail->enroll_details))
										@else
										<h6 class=" blue-text text-darken-1 bold">Enrollment Details :</h6>
										<p  class="small-font no-margin">
										{{$student_detail->enroll_details}}
										</p>
										@endif

									@if(empty($student_detail->short_code))
										@else
										<h6 class=" blue-text text-darken-1 bold">Center Code :</h6>
										<p  class="small-font no-margin">
										 
										{{$student_detail->short_code}}
										</p>
										@endif


									<h6 class=" blue-text text-darken-1 bold">Fees :</h6>
									 
 
									<div class="padding-left-off small-font no-margin  col s12">
									@if(empty($student_detail->Credits))
										@else
									<p class="no-margin"> <span class="green-text text-darken-1 ">PAID : </span> 
									{{$student_detail->Credits}}
										</p>
										@endif
									</div>
									

									<div class="padding-left-off small-font no-margin  col s12">
									@if(empty($student_detail->Debits))
										@else
									<p class="no-margin"> <span class="green-text text-darken-1 ">UTILIZED : </span> 
									{{$student_detail->Debits}}
										</p>
										@endif
									</div>


								{{-- 	<div class="padding-left-off small-font no-margin  col s12">
									@if(empty($student_detail->Balance))
										@else
									<p class="no-margin"> <span class="green-text text-darken-1 ">Balance : </span> 
									{{$student_detail->Balance}}
										</p>
										@endif
									</div> --}}
									 
								 	 
									 
								<a href="#showFileStatus" onclick="showFileStatus({{$student_detail->member_id}},'{{$student_detail->member_code}}');" class=" statvisibility relative black-text normal-font spacer modal-trigger tooltipped"  data-position="left" data-delay="50" data-tooltip="Click to check file upload status"><i  class="material-icons teal-text text-accent-4 right icon-span ">playlist_add_check</i></a>

								<a class="visibility relative"><i  class="material-icons grey-text right icon-span ">visibility_off</i></a>
							 


								</div>
							</div>
						</div>
					@endforeach
				<!--End of row-->
				
			</div>
		@endif
	</div>
</div>
<div class="center-align white-text fx-12 footer-search animated slideInUp fixed grey darken-2 row">
	<div class="margin-top-off bottom-margin-off col s12 m6 left grid-status-x">
		<div class="col s6 m3">
			<i class="small material-icons relative">supervisor_account</i>
			<span class="label">Total<b class="count spacer">{{$student_count}}</b></span>
		</div>
		<!--div class="margin-top-off bottom-margin-off col s6 m6 left-align">
			<i class="small green-text text-accent-3 material-icons relative">check_box</i>
			<span class="label"><b class="count spacer">No</b>record found</b></span>
		</div-->
	</div>
	<div class="margin-top-off bottom-margin-off col s12 m6 right grid-status-x">
		<div class="margin-top-off bottom-margin-off col s12 m5 offset-m4">
			<input placeholder="Search for a student" onkeyup="searchViewStudents(this.value)" id="student-key" type="text" class="bottom-margin-off search-placeholder validate white">
		</div>
	</div>
</div>
<span class="ticker-close pointer fixed">
	<i class="material-icons white-text fa-3x">expand_more</i>
</span>
@include('partials.navigation')
@include('partials.student')

<!--Modal-->
<div id="showFileStatus" class="modal animated pulse">
    <div class="modal-content">
      <h5 class="blue-text text-accent-3">File Upload Status <span class="count"></span></h5>
        <div class="red accent-1 col s12 white-text padding-1x small-text">
									<i class="material-icons left rev-margin">info_outline</i>
									<strong>Mandatory fields:</strong>&nbsp;
									a) Photo &nbsp;
									b) Age Proof &nbsp;
									c) Id Proof &nbsp;
									d) Educational Qualification &nbsp;
									e) Admission Form

		</div>
      	<ul class="collection">
    	</ul>
    </div>
  </div>

@endsection
@extends('layouts.app')
@section('title') New Student Registraion @stop

@section('content')
<div class="container">
	@include('includes.tabs.student')
	<div class="row top-margin content-wrapper students">
		<h3 class="grey-text text-darken-2 title page-title">New Admission </h3>
		<form  class="form-lax xpt matz" role="form" action="{{url('/post/u/0/student/new')}}" method="post">
			{{ csrf_field() }}
			<ul class="collapsible popout student-form-block" data-collapsible="accordion">
				<div id="staggered-shortcut"></div>
				<li class="first">
					<!--Centre Details-->
					<div class="collapsible-header active grey-text text-darken-1">
						<i class="material-icons grey-text text-darken-1">room</i>Center Selection
					</div>
					<div class="collapsible-body white contact-details active-padding matz-top-x">
						<div class="row margin-left-off margin-right-off">
							<div class="input-field col s12 m6 input-field-2X">
								<i class="material-icons prefix red-text">account_balance</i>
								<select name="centre_code" class="icons @if($errors->has('centre_code')) red-text @endif">
									<option value="" disabled selected>Students Getting Admitted to </option>
									@foreach($centers as $center)
									<option value="{{$center -> id}}" data-icon="http://static.wixstatic.com/media/0be6f0_ae2a9b5ebd054af5ba3c0f0231ac4a52.png" class="left circle" @if($center->id == old('centre_code')) selected @endif>{{$center -> short_code}}</option>
									@endforeach
								</select>
							</div>
						</div>
					</div>
				</li>

				<li>
					<!--Student Personal details-->
					<div class="collapsible-header">
						<i class="material-icons">folder_shared</i>Personal Identity
					</div>
					<div class="collapsible-body personal-info white active-padding matz-top-x">
						<div class="row margin-left-off margin-right-off">
							<div class="input-field col s12 m6 input-field-2X">
								<i class="material-icons prefix red-text">assignment_ind</i>
								<input id="icon_prefix" maxlength="20" name="first_name" type="text"   class="alpha @if($errors->has('first_name')) red-text validate @endif" value="{{old('first_name')}}">
								<label for="icon_prefix" class="grey-text text-darken-1">First Name</label>
							</div>
							<div class="input-field col s12 m6 input-field-2X margin-top-media-x">
								<i class="material-icons prefix grey-text text-lighten-1">assignment_ind</i>
								<input id="icon_prefix" name="mid_name" type="text"  class="alpha validate" value="{{old('mid_name')}}" >
								<label for="icon_prefix" class="grey-text text-darken-1" >Middle Name</label>
							</div>

							<div class="input-field col s12 m6">
								<i class="material-icons prefix red-text">assignment_ind</i>
								<input id="icon_prefix" name="last_name" type="text"  class="alpha validate" value="{{old('last_name')}}">
								<label for="icon_prefix" class="grey-text text-darken-1">Last Name</label>
							</div>

							<div class="input-field col s12 m6">
								<i class="material-icons prefix red-text">today</i>
								<input id="dob" name="dob" type="text" class="datepicker dob pointer" value="{{old('dob')}}">

								<label for="dob" class="active grey-text text-darken-1"> Date of Birth </label>
							</div>

							<div class="input-field gender-type margin-top-off col s12 m6">
								<span class="sad"><i class="material-icons prefix red-text">wc</i></span>
								<p class="header padding-top-down-off  padding-left-off ">
								Gender
								</p>
								<input name="gender" value="male" type="radio" id="Male"  data-value="male" checked="checked" />
								<label for="Male">Male</label>

								<input name="gender" value="female" type="radio" id="Female" data-value="female" @if(old('gender')=="female") checked="checked" @endif />
								<label for="Female">Female</label>

								<input name="gender" value="epicene" type="radio" id="Others" data-value="others" @if(old('gender')=="epicene") checked="checked" @endif/>
								<label for="Others">Epicene</label>
							</div>

							<div class="input-field married-status margin-top-media-2x col s12 m6">
								<span class="sad"><i class="material-icons prefix red-text">camera_front</i></span>
								<p class="header padding-top-down-off  padding-left-off">
									Marital Status
								</p>
								<input name="marital_status" value="unmarried" type="radio" id="Unmarried" checked="checked" data-value="unmarried" @if(old('marital')=="unmarried") checked="checked" @endif/>
								<label for="Unmarried">Unmarried</label>
								<input name="marital_status" value="married" type="radio" id="Married" data-value="married" @if(old('marital')=="married") checked="checked" @endif/>
								<label for="Married">Married</label>
								<input name="marital_status" value="divorcee" type="radio" id="Divorcee" data-value="divorcee" @if(old('marital')=="divorcee") checked="checked" @endif/>
								<label for="Divorcee">Divorcee</label>
							</div>

							<div class="input-field col s12 m6 margin-bottom input-field-2X">
								<span class="sad"><i class="material-icons prefix red-text">bookmark_border</i></span>
								<p class="header padding-top-down-off accent-1 padding-left-off">Category</p>
								<input class="with-gap" value="general" name="cast" type="radio" id="General" checked="checked" @if(old('cast')=="general") checked="checked" @endif/>
								<label for="General">General</label>
								<input class="cast"  value="sc" name="cast" name="" type="radio" id="SC" @if(old('cast')=="sc") checked="checked" @endif/>
								<label for="SC">SC</label>
								<input class="cast" value="st" name="cast" name="" type="radio" id="ST" @if(old('cast')=="st") checked="checked" @endif/>
								<label for="ST">ST</label>
								<input class="cast" value="obc" name="cast" name="" type="radio" id="OBC" @if(old('casts')=="obc") checked="checked" @endif/>
								<label for="OBC">OBC</label>
							</div>

							<div class="input-field col s12 m6 top-margin margin-top-media-2x">
								<i class="material-icons prefix red-text">supervisor_account</i>
								<select name="religion">
									<option value="" disabled selected>Select Your Religion</option>
									<option value="hindu" @if(old('religion')=="hindu") selected="selected" @endif/>Hindu</option>
									<option value="muslim" @if(old('religion')=="muslim") selected="selected" @endif/>Muslim</option>
									<option value="sikh" @if(old('religion')=="sikh") selected="selected" @endif/>Sikh</option>
									<option value="christian"  @if(old('religion')=="christian") selected="selected" @endif/>Christian</option>
									<option value="buddhism"  @if(old('religion')=="buddhism") selected="selected" @endif/>Buddhism</option>
									<option value="jainism" @if(old('religion')=="jainism") selected="selected" @endif/>Jainism</option>
									<option value="others"  @if(old('religion')=="others") selected="selected" @endif/>Others</option>
								</select>

							</div>

							<div class="input-field col s12 m6">
								<i class="material-icons prefix red-text">picture_in_picture</i>
								<select class="icons" name="doc_type">
									<option class="" value="" selected>Select Id Proof Type</option>
									<option value="adhar" data-icon="http://apexcomputersmulashi.com/images/services_icon/aadhar_card_icon.png" class="left circle" @if (Input::old('doc_type') == 'adhar') selected="selected" @endif>Aadhaar Card</option>
									<option value="pan" data-icon="http://www.subkuj.com/wp-content/uploads/2015/05/Pan-Card-Consultants-icon.png" class="left circle" @if (Input::old('doc_type') == 'pan') selected="selected" @endif>Pan Card</option>
									<option value="license" data-icon="https://www.driverlicencecheck.co.uk/images/icons/vehicle_blue.png" class="left circle" @if (Input::old('doc_type') == 'license') selected="selected" @endif>Driving License</option>
									<option value="voter_card" data-icon="http://www.subkuj.com/wp-content/uploads/2015/05/Pan-Card-Consultants-icon.png" class="left circle" @if (Input::old('doc_type') == 'voter_card') selected="selected" @endif>Voter Card</option>
									<option value="voter" data-icon="http://www.iereregionalcenter.com/images/icon-certification.png" class="left circle" @if (Input::old('doc_type') == 'voter') selected="selected" @endif>Ration Card</option>
									<option value="passport" data-icon="https://encrypted-tbn3.gstatic.com/images?q=tbn:ANd9GcR2GXj2_Alb79oJDMLJxFcNNtqcd1GQzo9kKx5cr3LplYLsJYFZUA" class="left circle" @if (Input::old('doc_type') == 'passport') selected="selected" @endif>Passport</option>
									<option value="admit_card" data-icon="http://www.subkuj.com/wp-content/uploads/2015/05/Pan-Card-Consultants-icon.png" class="left circle" @if (Input::old('doc_type') == 'admit_card') selected="selected" @endif>10th Admit Card</option>

								</select>
							</div>

							<div class="input-field col s12 m6 margin-top-media-x">
								<i class="material-icons prefix red-text">subtitles</i>
								<input id="icon_prefix" name="identity_no" type="text" class="validate" value="{{ old('identity_no') }}">
								<label for="icon_prefix" class="grey-text text-darken-1">Identity No.</label>
							</div>

							<div class="input-field col s12 m6 bottom-margin">
								<div class="col s6 m6 no-padding">
									<i class="material-icons prefix red-text">accessible</i>
									<label for="icon_prefix" class="grey-text text-darken-1"> Physical Disability </label>
								</div>
								<div class="switch relative col s6 m6 no-padding">
									<label> No
										<input type="hidden" name="disability_status" value="0">
										<input type="checkbox" name="disability_status" value='1' id="ds_class_x_selector" @if(old('disability_status')) checked @endif >
										<span class="lever"></span> Yes </label>
								</div>
							</div>

							<div class="input-field col s12 m6 no-display ds_class_x_selector animiated fadeInLeft">
								<i class="material-icons prefix red-text">speaker_notes</i>
								<input id="icon_prefix" name="disability_desc" type="text" class="validate" value="{{old('disability_desc')}}">
								<label for="icon_prefix" class="grey-text text-darken-1"> Short description of disability </label>
							</div>

						</div>
					</div>
				</li>

				<li>
					<!--Student Contact Details-->
					<div class="collapsible-header grey-text text-darken-1">
						<i class="material-icons grey-text text-darken-1">perm_phone_msg</i>Communication
					</div>
					<div class="collapsible-body white contact-details active-padding matz-top-x">
						<div class="row margin-left-off margin-right-off">
							<div class="input-field col s12 m6 input-field-2X">
								<i class="material-icons prefix red-text">stay_current_portrait</i>
								<input id="icon_prefix" name="contact_no" type="text" maxlength="10" class="validate numeric" value="{{old('contact_no')}}">
								<label for="icon_prefix" class="grey-text text-darken-1"> Contact No. </label>
							</div>
							<div class="input-field col s12 m6 input-field-2X margin-top-media-x">
								<i class="material-icons prefix grey-text text-lighten-1">email</i>
								<input id="icon_prefix" name="email_id" type="text" class="validate" value="{{old('email_id')}}">
								<label for="email_id" class="grey-text text-darken-1"> Email Address </label>
							</div>

							<div class="input-field col s12 m6">
								<i class="material-icons prefix red-text">map</i>
								<input type="text" id="l_pincode" name="pincode" data-type="directory" class="validate numeric autocomplete filled-registration" value="{{old('pincode')}}" autocomplete="off">
								<input type="hidden" name="l_pincode" value="{{old('l_pincode')}}" />
								<div class="preloader preloader-wrapper absolute small no-display active">
									<div class="spinner-layer spinner-blue-only">
										<div class="circle-clipper left">
											<div class="circle"></div>
										</div>
										<div class="gap-patch">
											<div class="circle"></div>
										</div>
										<div class="circle-clipper right">
											<div class="circle"></div>
										</div>
									</div>
								</div>
								<label for="l_pincode" class="icon_prefix grey-text text-darken-1">Find Pincode</label>
								<ul class="autocomplete-content dropdown-content absolute suggestion-box animated"></ul>
							</div>

							<div class="input-field col s12 m6">
								<i class="material-icons prefix red-text">room</i>
								<input id="icon_prefix" name="l_police_station" type="text" class="alpha validate" value="{{old('l_police_station')}}">
								<label for="icon_prefix" class="icon_prefix grey-text text-darken-1">Police Station</label>
							</div>

							<div class="input-field col s12 m4">
								<i class="material-icons prefix grey-text text-lighten-1">phone</i>
								<input id="icon_prefix" name="alt_contact_no" type="text" class="validate numeric" value="{{old('alt_contact_no')}}">
								<label for="icon_prefix" class="grey-text text-darken-1"> Alternative Number (If Any) </label>
							</div>

							<div class="input-field col s12 m4">
								<i class="material-icons prefix grey-text text-lighten-1">contact_phone</i>
								<input id="icon_prefix" name="landline_no" type="text" class="validate numeric" value="{{old('landline_no')}}">
								<label for="icon_prefix" class="grey-text text-darken-1"> Landline Number (If Any) </label>
							</div>

							<div class="input-field col s12 m4">
								<i class="material-icons prefix red-text">language</i>
								<select name="demo_type">
									<option value="" selected>Select Demographic Type</option>
									<option value="Urban" @if (Input::old('demo_type') == 'Urban') selected="selected" @endif
									>Urban</option>
									<option value="Semi_urban" @if (Input::old('demo_type') == 'Semi_urban') selected="selected" @endif>Semi Urban</option>
									<option value="Rural" @if (Input::old('demo_type') == 'Rural') selected="selected" @endif>Rural</option>

									<option value="Tribal" @if (Input::old('demo_type') == 'Tribal') selected="selected" @endif>Tribal</option>
								</select>
							</div>

							<div class="input-field col s12 m8 bottom-gap margin-bottom-off">
								<i class="material-icons prefix red-text">home</i>
								<textarea id="l_address" name="l_address" class="materialize-textarea" length="500">{{old('l_address')}}</textarea>
								<label for="l_address">Current Address</label>
							</div>
							<div class="input-field col s12 m4 input-field-2X top-gap bottom-gap">
								<input type="hidden" name="clone_address" value="0"/>
								<input type="checkbox" id="clone_address" name="clone_address" value="1" checked />
								<label for="clone_address" class="grey-text text-darken-1">Same for Permanent Address</label>
							</div>
							<div class="input-field col s12 m8 no-display clone_address bottom-gap">
								<textarea id="parm_address" name="parm_address" class="materialize-textarea" length="500"></textarea>
								<label for="parm_address" class="red-text">Permanent Address</label>
							</div>
						</div>
					</div>
				</li>

				<li>
					<!--Education & Work experience-->
					<div class="collapsible-header grey-text text-darken-1">
						<i class="material-icons grey-text text-darken-1">work</i>Education and Occupation
					</div>
					<div class="collapsible-body education-details white active-padding matz-top-x">
						<div class="row">
							<i class="material-icons prefix red-text sanitizer left">lightbulb_outline</i>
							<p class="header padding-top-down-off">
								Languages Known
							</p>
							<div class="col s12 m12">

								@foreach($getLanguageList as $language)
									{{-- */$i = 1;/* --}}
									<div class="input-field col s12 m4">
										<div class="chip grey lighten-4">
											<a class="lang-matz-x btn-floating btn-small waves-effect waves-light blue relative center-align fa-1_5x">{{$language->icon}}</a>

											<input type="checkbox" name="language[{{$language->id}}][]" value="Read" class="filled-in" id="xgylagnuxzae{{$language->id.$language->short_name.$i}}" />
											<label for="xgylagnuxzae{{$language->id.$language->short_name.$i}}"> <i class="material-icons tooltipped" data-position="top" data-delay="50" data-tooltip="Can read">import_contacts</i> </label>

											<input type="checkbox" name="language[{{$language->id}}][]" value="Write" class="filled-in" id="xgylagnuxzae{{$language->id.$language->short_name.($i+1)}}" />
											<label for="xgylagnuxzae{{$language->id.$language->short_name.($i+1)}}"> <i class="material-icons tooltipped" data-position="top" data-delay="50" data-tooltip="Can write">edit</i> </label>

											<input type="checkbox" name="language[{{$language->id}}][]" value="Speak" class="filled-in" id="xgylagnuxzae{{$language->id.$language->short_name.($i+2)}}" />
											<label for="xgylagnuxzae{{$language->id.$language->short_name.($i+2)}}"> <i class="material-icons tooltipped" data-position="top" data-delay="50" data-tooltip="Can speak">record_voice_over</i> </label>
										</div>
									</div>
									{{-- */$i++;/* --}}
								@endforeach
							</div>
							<div class="col s12 m12">
								<div class="input-field col s12 m6 input-field-X margin-top-media-x">
									<i class="material-icons prefix red-text">web_asset</i>	
									<select name="highest_qualification">
										<option value="" disabled selected>Select Your Highest Qualification</option>
										@foreach($degrees as $degree)
											<option value="{{$degree -> id}}" class="left" @if($degree->id == old('highest_qualification')) selected @endif>{{$degree -> name}}</option>
										@endforeach
									</select>
								</div>
								<div class="input-field col s12 m6 input-field-X margin-top-media-x">
								<i class="material-icons prefix red-text">accessibility</i>
									<select name="livelihood_preference">
										<option value="" selected class="grey-text text-lighten-2">Livelihood Preference</option>
										<option value="job" @if (Input::old('livelihood_preference') == 'job') selected="selected" @endif>Job</option>
										<option value="business" @if (Input::old('livelihood_preference') == 'business') selected="selected" @endif>Business</option>
										<option value="freelance" @if (Input::old('livelihood_preference') == 'freelance') selected="selected" @endif>Freelancing / Work From Home</option>
									</select>
								</div>
								<div class="col s12 m12 mobile-toggle">
									<div class="input-field col s12 m6 bottom-margin">
										<div class="col s6 m6 no-padding">
											<label for="icon_prefix" class="grey-text text-darken-1"> Already Employed </label>
										</div>
										<div class="switch relative col s6 m6 no-padding">
											<label> No
												<input type="hidden" name="occupation_status" value="0">
												<input type="checkbox" value="1" name="occupation_status" id="occupation" @if(old('occupation_status')) checked @endif>
												<span class="lever"></span> Yes </label>
										</div>
									</div>

									<div class="input-field col s12 m3 occupation no-display animated">
									<i class="material-icons prefix red-text">streetview</i>
										<select name="current_monthly_earning">
											<option value="" selected class="grey-text text-darken-1">Select Income</option>
											<option value="below-2000" @if (Input::old('current_monthly_earning') == 'below-2000') selected="selected" @endif>Below 2000 </option>
											<option value="2000-3000" @if (Input::old('current_monthly_earning') == '2000-3000') selected="selected" @endif>2000 - 3000</option>
											<option value="3000-4000" @if (Input::old('current_monthly_earning') == '3000-4000') selected="selected" @endif>3000 - 4000</option>
											<option value="above-4000" @if (Input::old('current_monthly_earning') == 'above-4000') selected="selected" @endif>Above 4000</option>
										</select>
									</div>

									<div class="input-field col s12 m3 occupation no-display animated">
										<select name="employment_type">
											<option value="" selected class="grey-text text-darken-1  ">Employment Type</option>
											<option value="business_part_time" @if (Input::old('employment_type') == 'business_part_time') selected="selected" @endif>Business Part Time</option>
											<option value="business_full_time" @if (Input::old('employment_type') == 'business_full_time') selected="selected" @endif>Business Full Time</option>
											<option value="employed_part_time" @if (Input::old('employment_type') == 'employed_part_time') selected="selected" @endif>Employed Part Time</option>
											<option value="employed_full_time" @if (Input::old('employment_type') == 'employed_full_time') selected="selected" @endif>Employed Full Time</option>
										</select>
									</div>

								</div>
								<div class="col s12 m12 mobile-toggle">
									<div class="input-field col s12 m6 bottom-margin ">
										<div class="col s6 m6 no-padding">
											<label for="icon_prefix" class="grey-text text-darken-1"> Computer Knowledge </label>
										</div>
										<div class="switch relative col s6 m6 no-padding">
											<label> No
												<input type="hidden" name="can_operate_computer" value="0">
												<input type="checkbox" value="1" name="can_operate_computer" id="can_operate_computer" @if(old('can_operate_computer')) checked @endif>
												<span class="lever"></span> Yes </label>
										</div>
									</div>

									<div class="input-field col s12 m6 no-display can_operate_computer animated fadeIn">
										<i class="material-icons prefix red-text">edit</i>
										<textarea id="computer_skills" name="technical_knowledge" class="materialize-textarea"></textarea>
										<label for="computer_skills">Write About Your Computer Skills</label>
									</div>
								</div>
								<div class="col s12 m12 mobile-toggle">
									<div class="input-field col s12 m6 bottom-margin">
										<div class="col s6 m6 no-padding">
											<label for="icon_prefix" class="grey-text text-darken-1"> Willing to relocate for job </label>
										</div>
										<div class="switch relative col s6 m6 no-padding">
											<label> No
												<input type="hidden" name="ready_to_relocate" value="0">
												<input type="checkbox" value="1" name="ready_to_relocate" id="ready_to_relocate" @if(old('ready_to_relocate')) checked @endif>
												<span class="lever"></span> Yes </label>
										</div>
									</div>
									<div class="input-field col s12 m6 animated ready_to_relocate no-display">
										<i class="material-icons prefix red-text">transfer_within_a_station</i>
										<select name="relocate">
											<option value="" selected class="grey-text text-darken-1">Select Preference</option>
											<option value="in_state"  @if (Input::old('relocate') == 'in_state') selected="selected" @endif>In State</option>
											<option value="out_of_state" @if (Input::old('relocate') == 'out_of_state') selected="selected" @endif>Out Of State</option>

										</select>
									</div>

								</div>
							</div>
						</div>
					</div>
				</li>

				<li>
					<!--Student Family Details-->
					<div class="collapsible-header grey-text text-darken-1">
						<i class="material-icons grey-text text-darken-1">supervisor_account</i>Family and Income
					</div>
					<div class="collapsible-body white contact-details active-padding matz-top-x">
						<div class="row margin-left-off margin-right-off">
							<div class="input-field col s12 m6 input-field-2X">
								<i class="material-icons prefix red-text">person_pin</i>
								<input id="icon_prefix" name="father_name" type="text" class="alpha validate" value="{{old('father_name')}}">
								<label for="icon_prefix" class=""> Father Name </label>
							</div>
							<div class="input-field col s12 m6 input-field-2X">
								<i class="material-icons prefix red-text">rate_review</i>
								<select name="father_occupation">
									<option value="" selected>Select Father's Occupation</option>
									<option value="service" @if(old('father_occupation')=="service") selected="selected" @endif>Service</option>
									<option value="business" @if(old('father_occupation')=="business") selected="selected" @endif>Business</option>
									<option value="farmer" @if(old('father_occupation')=="farmer") selected="selected" @endif>Farmer</option>
									<option value="retired" @if(old('father_occupation')=="retired") selected="selected" @endif>Retired</option>
									<option value="others" @if(old('father_occupation')=="others") selected="selected" @endif>Others</option>
									<option value="jobless" @if(old('father_occupation')=="jobless") selected="selected" @endif>Jobless</option>
									<option value="decendent" @if(old('father_occupation')=="decendent") selected="selected" @endif>Decendent</option>
									<option value="labour" @if(old('father_occupation')=="labour") selected="selected" @endif>Labour</option>
									<option value="not_to_say" @if(old('father_occupation')=="not_to_say") selected="selected" @endif>Preferred 	Not To Say</option>
								</select>
							</div>
							<div class="input-field col s12 m6">
								<i class="material-icons prefix red-text">person_pin</i>
								<input id="icon_prefix" name="mother_name" type="text" class="alpha validate" value="{{old('mother_name')}}">
								<label for="icon_prefix" > Mother Name </label>
							</div>
							<div class="input-field col s12 m6">
								<i class="material-icons prefix red-text">rate_review</i>
								<select name="mother_occupation">
									<option value="" selected>Select Mother's Occupation</option>
									<option value="service" @if(old('mother_occupation')=="service") selected="selected" @endif>Service</option>
									<option value="business" @if(old('mother_occupation')=="business") selected="selected" @endif>Business</option>
									<option value="homemaker" @if(old('mother_occupation')=="homemaker") selected="selected" @endif>Home Maker</option>
									<option value="others" @if(old('mother_occupation')=="others") selected="selected" @endif>Others</option>
								</select>
							</div>
							<div class="input-field col s12 m6 gender-status-dependency no-display">
								<i class="material-icons prefix grey-text text-lighten-1">contacts</i>
								<input id="icon_prefix" name="husband_name" type="text" class="validate" value="{{old('husband_name')}}">
								<label for="icon_prefix" class="grey-text text-darken-1"> Husband Name </label>
							</div>
							<div class="input-field col s12 m6 gender-status-dependency no-display">
								<select name="husband_occupation">
									<option value="" selected>Select Type</option>
									<option value="service" @if(old('husband_occupation')=="service") selected="selected" @endif>Service</option>
									<option value="business" @if(old('husband_occupation')=="business") selected="selected" @endif>Business</option>
									<option value="farmer" @if(old('husband_occupation')=="farmer") selected="selected" @endif>Farmer</option>
									<option value="retired" @if(old('husband_occupation')=="retired") selected="selected" @endif>Retired</option>
									<option value="others" @if(old('husband_occupation')=="others") selected="selected" @endif>Others</option>
									<option value="jobless" @if(old('husband_occupation')=="jobless") selected="selected" @endif>Jobless</option>
								</select>
								<label class="grey-text text-darken-1">husband's Occupation</label>
							</div>
							<div class="input-field col s12 m6">
								<p class="header padding-top-down-off grey-text text-darken-1 padding-top-off padding-left-off">
									Number of family members
								</p>
								<input type="hidden" name="no_of_members" value="1"/>
								<div class="ranged-value" id="no_of_members" data-value='1'></div>
							</div>
							<div class="input-field col s12 m6">
								<p class="header padding-top-down-off grey-text text-darken-1 padding-top-off padding-left-off">
									Number of earning members
								</p>
								<input type="hidden" name="no_of_earning_members" value="0"/>
								<div class="ranged-value"  id="no_of_earning_members" data-value='0'></div>
							</div>

							<div class="input-field col s12 m6 input-field-2X">
								<i class="material-icons prefix red-text">credit_card</i>
								<select name="family_monthly_earning">
									<option value="" selected class="grey-text text-darken-1" >Monthly Family Income</option>
									<option value="below-2000"  @if(old('family_monthly_earning')=="below-2000") selected="selected" @endif>Below 2000 </option>
									<option value="2000-4000"  @if(old('family_monthly_earning')=="2000-4000") selected="selected" @endif>2000 - 4000</option>
									<option value="4000-8000"  @if(old('family_monthly_earning')=="4000-8000") selected="selected" @endif>4000 - 8000</option>
									<option value="above-8000"   @if(old('family_monthly_earning')=="above-8000") selected="selected" @endif>Above 8000 </option>
								</select>
							</div>

							<div class="input-field col s12 m6 bottom-margin input-field-2X">
								<div class="col s6 m6 no-padding">
									<label for="icon_prefix" class="grey-text text-darken-1"> BPL Card Holder </label>
								</div>
								<div class="switch relative col s6 m6 no-padding">
									<label> No
										<input type="hidden" name="eco_status" value="off">
										<input type="checkbox" name="eco_status" id="bpl_class_x_selector">
										<span class="lever"></span> Yes </label>
								</div>
							</div>

							<div class="input-field col s12 m6 no-display bpl_class_x_selector">
								<i class="material-icons prefix red-text">credit_card</i>
								<input id="icon_prefix" name="bpl_card_no" type="text" class="validate eco_status_no" value="{{old('bpl_card_no')}}">
								<label for="icon_prefix" >BPL Card No.</label>
							</div>


						</div>
					</div>
				</li>
				<li class="last">
					<!--Other Details-->
					<div class="collapsible-header grey-text text-darken-1">
						<i class="material-icons grey-text text-darken-1">recent_actors</i>Other Details
					</div>
					<div class="collapsible-body white other-details active-padding matz-top-x">
						<div class="row margin-left-off margin-right-off">
							<div class="input-field col s12 m6 input-field-2X">
								<i class="material-icons prefix red-text">live_help</i>
								<select class="validate referal_entity" name="come_to_know">
									<option value="" disabled selected>Admitted through</option>
									<option value="Walkin"  @if (Input::old('come_to_know') == 'Walkin') selected @endif>Walk-in Admission</option>
									<option value="Mobilizer" @if (Input::old('come_to_know') == 'Mobilizer') selected @endif>Admitted through Mobilizer</option>
									<option value="Anudip Trainer" @if (Input::old('come_to_know') == 'Anudip Trainer') selected @endif>Admitted through Trainer</option>
									<option value="Anudip Student" @if (Input::old('come_to_know') == 'Anudip Student') selected @endif>Referred by Anudip Student</option>
									<option value="Other Reference" @if (Input::old('come_to_know') == 'Other Reference') selected @endif>Other Reference</option>

								</select>
							</div>

							<div class="input-field col s12 m6 input-field-2X no-display referal_entity_data_pox student_referal_program">
								<i class="material-icons prefix red-text">perm_identity</i>
								<input id="referral_id" name="referral_id" class="validate autocomplete students_id" data-type="lists" type="text">
								<div class="preloader preloader-wrapper absolute small no-display active">
									<div class="spinner-layer spinner-blue-only">
										<div class="circle-clipper left">
											<div class="circle"></div>
										</div>
										<div class="gap-patch">
											<div class="circle"></div>
										</div>
										<div class="circle-clipper right">
											<div class="circle"></div>
										</div>
									</div>
								</div>
								<label for="referral_id" class="grey-text text-darken-1"> Specify Anudip Student's (Reg No.) </label>
								<ul class="autocomplete-content dropdown-content absolute suggestion-box animated"></ul>
							</div>
							<div class="input-field col s12 m6 input-field-2X no-display referal_entity_data_pox other_referal_pick">
								<i class="material-icons prefix red-text">perm_identity</i>
								<input id="referral_name" name="referral_name" type="text" class="validate">
								<label for="referral_name" class="grey-text text-darken-1"> Enter Referral Name </label>
							</div>
						</div>
					</div>
				</li>
			</ul>
			<button class="waves-effect waves-light btn green accent-4 right" type="submit">
				Save Details<i class="material-icons right">done</i>
			</button>
		</form>
	</div>
</div>
@include('partials.navigation')
@include('partials.student')
@endsection

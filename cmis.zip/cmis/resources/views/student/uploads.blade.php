@extends('layouts.app')
@section('title') Upload Documents @stop
@section('content')
<section class="container">
	@include('includes.tabs.student')
	<div class="row top-margin bottom-margin content-wrapper top-gap students">
		<article class="col s12 m9 none auto bottom-gap no-padding">
			<h3 class="grey-text text-darken-2 title page-title">Upload Document</h3>
			<ul class="collapsible popout student-form-block" data-collapsible="accordion">
				<li class="student-search">
					<!--Student registration search-->
					<div class="collapsible-header active">
						<i class="material-icons">search</i>Find A Student
						<div class="left step-marker bold">
							<span class="relative left ripple rippleEffect"></span>
						</div>
					</div>
					<div class="collapsible-body personal-info white active-padding matz-top-x">
						<div class="row margin-left-off margin-right-off">
							<form  class="form-lax xpt matz" role="form" enctype="multipart/form-data" action="{{url('/post/u/0/return/files')}}" method="post">
								{{ csrf_field() }}
								<div class="input-field col s12 m12">
									<i class="material-icons prefix grey-text text-lighten-1">person_pin</i>
									<input autocomplete="off" id="student_registration" data-type="lists" value="@if(Session::has('member_code')){{Session::get('member_code')}}@endif" type="text" class="validate autocomplete students_id">
									<input type="hidden" name="student_registration" value="@if(Session::has('member_id')){{Session::get('member_id')}}@endif">
									<div class="preloader preloader-wrapper absolute small no-display active">
										<div class="spinner-layer spinner-blue-only">
											<div class="circle-clipper left">
												<div class="circle"></div>
											</div>
											<div class="gap-patch">
												<div class="circle"></div>
											</div>
											<div class="circle-clipper right">
												<div class="circle"></div>
											</div>
										</div>
									</div>
									<label for="student_registration" class="grey-text text-lighten-1 active">Search by Registration no.</label>
									<ul class="autocomplete-content dropdown-content absolute suggestion-box animated"></ul>
								</div>
								<div class="grey lighten-4 col s12 red-text text-lighten-2 padding-1x small-text">
									<i class="material-icons left rev-margin">info_outline</i>
									<strong>Mandatory Documents:</strong>&nbsp;
									a) Photo &nbsp;
									b) Age Proof &nbsp;
									c) Id Proof &nbsp;
									d) Educational Qualification &nbsp;
									e) Admission Form

								</div>
								<div class="input-field col s12 m6 top-gap">
									<select class="icons" name="doc_type" >
											<option value="" selected>Select Document Type</option>
										@foreach($fileLists as $key=>$value)
											<option data-value="{{$value->description}}" value="{{$value->id}}" alt="ream" data-icon="http://i.istockimg.com/file_thumbview_approve/51011242/3/stock-illustration-51011242-male-profile-flat-blue-simple-icon-with-long-shadow.jpg" class="left circle">{{$value->category_name}}</option>
										@endforeach
									</select>
									 
								</div>
								<div class="blue lighten-4 col s12 m6 grey-text text-darken-3 small-text padding-1x  top-gap doc_note ">
									<div class="col s1">
									<i class="material-icons left rev-margin deep-orange-text text-accent-4 ">info_outline</i>
									</div>
										 
									<div class="col s11 file-details">	
										You can upload multiple files at a time.
									</div>
								</div>
								<div class="col s12 m12">
									<div class="file-field input-field">
										<div class="btn blue">
											<span>Browse</span>
											<input type="file" name="change_lmx_u750_document_upload[]" accept=".jpg,.png,.pdf">
										</div>
										<div class="file-path-wrapper">
											<input class="file-path validate" type="text" placeholder="You can upload maximum of size 2MB">
										</div>
									</div>
								</div>
								<div class="input-field col s12 m12 margin-top-off">
									<textarea id="description" name="description" class="materialize-textarea" length="500"></textarea>
									<label for="description">Description</label>
								</div>
								<div class="input-field col s7 m4 margin-top-off offset-m8 offset-s5">
									<button class="waves-effect waves-light btn green accent-4 right top-gap" type="submit">
										Upload<i class="material-icons right">cloud_upload</i>
									</button>
								</div>
							</form>
						</div>
					</div>
				</li>
			</ul>
		</article>

		<article class="top-margin">
			<div class="col s12 m9 none auto bottom-gap top-gap">
				@if(Session::has('user_details'))
                    @if(!empty(Session::get('user_details')))
						<h3 class="grey-text text-darken-2 title page-title">Uploaded Files</h3>
						<div class="row ">
						    
						     @foreach(Session::get('user_details') as $upload)
						     	<div class="collection col s12 m6 no-padding no-margin z-depth-1">
							     	@if($upload['t_status'] == 0)
							     		<li class="collection-item blue-text text-lighten-1"><div> {{$upload['t_cat_name']}} <a href="#!" class="secondary-content"><i class="material-icons red-text">clear</i></a></div></li>
							     	@else
										<li class="collection-item blue-text text-lighten-1"><div> {{$upload['t_cat_name']}} <a href="#!" class="secondary-content "><i class="material-icons green-text bold">done</i></a></div></li>
							     	@endif
						     	</div>
						     @endforeach
						</div>
					@else
						<h3 class="red-text text-darken-2 title page-title">No file Uploaded yet.</h3>
					@endif
				@endif
			</div>
		</article>
		{{--  <div class="chip">
		    <img src="{{ URL::asset($value->data) }}" >
		    Jane Doe
		  </div>
		  <div class="chip">
		    <img src="{{ URL::asset($value->data) }}" >
		    Jane Doe
		  </div>
		  <div class="chip">
		    <img src="{{ URL::asset($value->data) }}" >
		    Jane Doe
		  </div> --}}
	</div>
</section>
@include('partials.navigation')
@include('partials.student')
@endsection
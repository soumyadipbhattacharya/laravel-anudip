@extends('layouts.app')
@section('title') Fees Collection @stop
@section('content')

<div class="container">
	@include('includes.tabs.student')
	<div class="row top-margin content-wrapper fees-collection students">
		<div class="col s12 m8 none auto bottom-gap no-padding">
			<h3 class="grey-text text-darken-2 title page-title">Fee Collection</h3>
			<div class="card white darken-1">
				<div class="card-content padding-1x">
					<input type="hidden" value="{{csrf_token()}}" id="meta-token">
					<div class="input-field col m12 s12">
						<i class="material-icons prefix red-text">assignment_ind</i>
						<input @if(!empty($query_result)) readonly onclick="Materialize.toast('You cannot change this value', 4000)" @endif value="@if(!empty($query_result)){{$query_result[0]->member_code}}@endif" id="member_code" class="validate autocomplete students_id" data-type="fees" type="text">
						<input name="member_code" type="hidden" value="@if(!empty($query_result)){{$query_result[0]->id}}@endif">
						<div class="preloader preloader-wrapper absolute small no-display active">
							<div class="spinner-layer spinner-blue-only">
								<div class="circle-clipper left">
									<div class="circle"></div>
								</div>
								<div class="gap-patch">
									<div class="circle"></div>
								</div>
								<div class="circle-clipper right">
									<div class="circle"></div>
								</div>
							</div>
						</div>
						<label for="member_code" class="grey-text text-darken-1">Student CMIS Id</label>
						<ul class="autocomplete-content dropdown-content absolute suggestion-box animated"></ul>
					</div>
					<div class="input-field col m12 s12 hidden total_amount ">
						<i class="fa fa-inr prefix grey-text" aria-hidden="true"></i>
						<input id="total_amount" onclick="Materialize.toast('Disabled! You cannot change this value', 4000)" name="total_amount" type="text" class="validate numeric">
						<span id="total_amount" onclick="Materialize.toast('Disabled! You cannot change this value', 4000)" class="validate margin-amtfield">@if(!empty($query_result)){{$query_result[0]->amount}}@endif </span>
					</div>

					<div class="input-field col m12 s12">

						<i class="fa fa-inr prefix red-text" aria-hidden="true"></i>
						<input autocomplete="off" id="amount" name="amount" type="text" class="validate numeric digit-validation"><span id="erramt"></span><span id="errmsg"></span>
						<label for="amount" class="grey-text text-darken-1">Amount Paying Now</label>
					</div>

					<div class="input-field col m12 s12">
						<i class="material-icons prefix red-text">assignment</i>
						<input id="receipt_no" name="receipt_no" type="text" class="validate">
						<label for="receipt_no" class="grey-text text-darken-1">Fees Receipt No.</label>
					</div>

					<div class="input-field col m12 s12">
						<i class="material-icons prefix red-text">today</i>
						<input type="date" placeholder="Fees Receipt Date" name="receiving_date" id="Datein" class="pointer datepicker grey-text text-lighten-1">
						
					</div>

					<div class="input-field col m12 s12">
						<i class="material-icons prefix red-text">perm_identity</i>
						<input id="received_by" class="validate autocomplete students_id" data-type="staff" type="text">
						<input name="received_by" type="hidden" value="">
						<div class="preloader preloader-wrapper absolute small no-display active">
							<div class="spinner-layer spinner-blue-only">
								<div class="circle-clipper left">
									<div class="circle"></div>
								</div>
								<div class="gap-patch">
									<div class="circle"></div>
								</div>
								<div class="circle-clipper right">
									<div class="circle"></div>
								</div>
							</div>
						</div>
						<label for="received_by" class="grey-text text-darken-1">Fees Collected By (Employee ID)</label>
						<ul class="autocomplete-content dropdown-content absolute suggestion-box animated"></ul>
					</div>

					<div class="right-align media-custom-off">
						<button type="submit" class="waves-effect waves-light btn green accent-4" id="submit-fees">
							Add Fees <i class="fa fa-btn fa-external-link"></i>
						</button>
					</div>
				
				</div>
			</div>
		</div>
	</div>
</div>

@include('partials.navigation')
@include('partials.student')
@endsection
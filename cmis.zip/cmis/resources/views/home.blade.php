@extends('layouts.app')
@section('title')CMIS Dashbaord @stop
@section('content')
<div class="container">
	<div class="row password-reset-check top-margin content-wrapper">
		<h3 class="grey-text text-darken-2 title">My Dashboard</h3>
		<div class="col s6 ">
			<canvas id="studentChart"></canvas>
		</div>
		<div class="col s6 ">
			<canvas id="batchChart"></canvas>
		</div>
		<div class="col s4">
			<div class="col s12 ">
				<div class="card">
					<div class="card-content blue darken-3 white-text">
						<p class="card-stats-title"><i class="mdi-editor-attach-money"></i>Total Fee Collect</p>
						<h4 class="card-stats-number">Rs. 8990.63</h4>
						<p class="card-stats-compare"><i class="mdi-hardware-keyboard-arrow-up"></i> 70% <span class="purple-text text-lighten-5">last month</span>
						</p>
					</div>
					<div class="card-action  ">
						<div  ><canvas id="studentChart" width="286" height="25" style="display: inline-block; width: 286px; height: 25px; vertical-align: top;"></canvas></div>

					</div>
				</div>
			</div>
		</div>
		<div class="col s4">
			<div class="col s12 ">
				<div class="card">
					<div class="card-content blue darken-3 white-text">
						<p class="card-stats-title"><i class="mdi-editor-attach-money"></i>Total Fee Collect</p>
						<h4 class="card-stats-number">Rs. 8990.63</h4>
						<p class="card-stats-compare"><i class="mdi-hardware-keyboard-arrow-up"></i> 70% <span class="purple-text text-lighten-5">last month</span>
						</p>
					</div>
					<div class="card-action ">
						<div  ><canvas id="studentChart" width="286" height="25" style="display: inline-block; width: 286px; height: 25px; vertical-align: top;"></canvas></div>

					</div>
				</div>
			</div>
		</div>

		<div class="col s4">
			<div class="col s12 ">
				<div class="card">
					<div class="card-content blue darken-3 white-text">
						<p class="card-stats-title"><i class="mdi-editor-attach-money"></i>Total Fee Collect</p>
						<h4 class="card-stats-number">Rs. 8990.63</h4>
						<p class="card-stats-compare"><i class="mdi-hardware-keyboard-arrow-up"></i> 70% <span class="purple-text text-lighten-5">last month</span>
						</p>
					</div>
					<div class="card-action ">
						<div  ><canvas id="studentChart" width="286" height="25" style="display: inline-block; width: 286px; height: 25px; vertical-align: top;"></canvas></div>

					</div>
				</div>
			</div>
		</div>
	</div>
</div>
@endsection

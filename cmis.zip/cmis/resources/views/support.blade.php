@extends('layouts.app')
@section('title') Get Support @stop
@section('content')

<div class="container">
	<div class="row password-reset-check top-margin content-wrapper">
		<div class="col s12 m7 none auto no-padding">
			<h3 class="grey-text text-darken-2 title">Technical Support</h3>
			<div class="card white darken-1">
				<div class="card-content">
					<form class="form-horizontal support-form" role="form" method="post" action="{{url('/support')}}" enctype="multipart/form-data">
						{{ csrf_field() }}
						@if(!Auth::user())
							<div class="input-field col s12">
								<i class="material-icons prefix grey-text">account_circle</i>
								<input id="fname" name="fname" type="text" class="validate" value="{{old('fname') }}">
								<label for="first_name" class="grey-text text-darken-2">Your Full Name</label>
							</div>
	
							<div class="input-field col s12">
								<i class="material-icons prefix grey-text">email</i>
								<input id="email" name="email" type="email" class="validate" value="{{old('email') }}">
								<label for="email" data-error="wrong" data-success="right" class="grey-text text-darken-2">Your Email Address</label>
							</div>
						@endif
						<div class="input-field col s12">
							<i class="material-icons prefix grey-text darken-2-text">receipt</i>
							<input id="title" name="title" type="text" class="validate" maxlength="50" value="{{old('title') }}">
							<label for="first_name" class="grey-text text-darken-2">Problem Title</label>
						</div>

						<div class="input-field col s12">
							<i class="material-icons prefix grey-text darken-2-text">mode_edit</i>
							<textarea id="desc" name="desc" class="materialize-textarea">{{old('desc') }}</textarea>
							<label for="icon_prefix2 " class="grey-text text-darken-2">Problem Description</label>
						</div>

						<div class="file-field input-field col s12">
							<h6>Attachments</h6>
							<p class="grey-text text-darken-2 small-text">
								ALLOWABLE FILE TYPES - BMP, JPG, JPEG, GIF, PNG, PDF, DOC, DOCX, ODT UP TO 2MB
							</p>
							<div class="btn blue">
								<span>File Upload</span>
								<input type="file" id="image" name="image" >
							</div>
							<div class="file-path-wrapper">
								<input class="file-path validate" type="text" >
							</div>
						</div>
						<div class=" col s12">
						@if(!Auth::user())
							{!! app('captcha')->display(); !!}
						@endif
						</div>
						
						<button type="submit" class="@if(Auth::user()) margin-top-off @endif waves-effect waves-light btn green accent-4">
				           	Submit Query <i class="fa fa-btn fa-external-link"></i> 
				         </button>
					</form>
				</div>
			</div>
		</div>
	</div>
</div>
@endsection

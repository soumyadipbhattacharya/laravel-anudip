@extends('layouts.app')
@section('title') New Attendance @stop
@section('content')

<div class="container">
	<div class="row top-margin content-wrapper schedule bottom-margin">
		<div class="col s12 m12 l8 none auto bottom-gap no-padding">
			<h3 class="grey-text text-darken-2 title page-title">Add Attendance</h3>
			<form class="form-horizontal form-wrapper" role="form" method="post" action="{{url('/post/u/0/attendance/saveAttendance')}}" enctype="multipart/form-data">
				{{csrf_field()}}
				<ul class="collapsible" data-collapsible="expandable">
					<li>
						<div class="collapsible-header padding-top-1X bold active grey-text text-darken-1">
							<i class="material-icons orange-text">today</i>Step 1 - Select Batch
						</div>
						<div class="collapsible-body padding-1x white black-text text-darken-2">
							{{ csrf_field() }}
							<div class="input-field col s12">
								<i class="material-icons prefix grey-text">playlist_add</i>
								<select name="batch_id" id="batch_id" onChange="getStudentData(this.value,this.id)">
									<option value="" selected>Choose A Batch</option>
									@foreach($get_centers as $ckey => $cvalue)
									<optgroup label="{{$cvalue->short_code}}">
										@foreach($get_batches as $bkey => $bvalue)
										@if($bvalue->center_id == $cvalue->id)
										<option value="{{$bvalue->id}}">{{$bvalue->batch_code}}</option>
										@endif
										@endforeach
									</optgroup>
									@endforeach
								</select>
								 
							</div>

							<div class="input-field col m12 s12">
								<i class="material-icons prefix grey-text">today</i>
								<input type="text" value="<?php echo date('d/m/Y'); ?>" name="date" class="attenlimit pointer datepicker grey-text text-darken-1" id="start_date">
								<label for="start_date" class="grey-text text-lighten-1">Class Date</label>
							</div>

							<div class="input-field col m6 s6 input-field-2X">
								<i class="chip-icon material-icons prefix grey-text">query_builder</i>
								<input autocomplete="off" type="text" name="start_time" value="<?php echo date('H:i'); ?>" class="clockpicker" data-placement="top" data-align="top" data-autoclose="true" class="validate" id="start_time">
								<label for="start_time" class="grey-text text-lighten-1">Pick Start Time</label>
							</div>

							<div class="input-field col m6 s6 input-field-2X">
								<i class="chip-icon material-icons prefix grey-text">snooze</i>
								<input autocomplete="off" type="text" name="end_time" class="clockpicker" data-placement="left" data-align="right" data-autoclose="true" value="" class="validate" id="end_time">
								<label for="end_time" class="grey-text text-lighten-1">Pick End Time</label>
							</div>
						</div>
					</li>
					<li>
						<div class="collapsible-header active grey-text text-darken-1 bold">
							<i class="material-icons orange-text">query_builder</i>Step 2 - Fillup Attendance
						</div>

						<div class="collapsible-body padding-1x white black-text text-darken-2">
							<div class="col s12 m12">

								<div class="switch student-status col s6 m6">
									<label class="black-text text-accent-3">All Absent
									<input type="checkbox" disabled id="attendance_switch">
									<span class="lever"></span>Present </label>
								</div>

								<div class="col s6 m6 center-align">
									Total Attendance
									<span class="fa-1_5x badge red-text text-accent-2 attain right relative bold" data-badge-caption="0">
										<i class="material-icons show-attain green-text text-accent-4">done_all</i>
									</span>
								</div>

							</div>

							<div class="input-field col s12 relative bottom-gap">
								<div id="attendance-wrapper" class="chip hidden student-selected day-selected no-border no-radius col s10 m12 "></div>
							</div>

							<div class="right-align padding-1x relative">
								<button type="submit" class="top-gap waves-effect waves-light btn green accent-4 input-field-2X">
									Save Details <i class="fa fa-btn fa-external-link"></i>
								</button>
							</div>
					</li>
				</ul>
			</form>
		</div>
	</div>
</div>

@include('partials.attendance')
@endsection

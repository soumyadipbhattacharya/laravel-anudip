@include('layouts.header')
<body @if(Route::current()->getName() == 'dropin' || Request::path() == 'login') class="dropin-bg" @endif>
	@include('includes.messages')
	@if (Request::path() != '/' && Request::path() != 'login')
	@include('includes.appbar')
	@endif
	@yield('content')
@include('layouts.footer')

@extends('layouts.app')
@section('title')Tech Team @stop
@section('content')
<div class="banner-wrapper layout-top absolute z-index-off">
	<img class="width-100" alt="Tamaghna Banerjee" src="{{ URL::asset('images/about_team.png')}}">
</div>
<div class="container">
	<div class="row top-margin-2x content-wrapper bottom-margin-2x meet-team">
		<div class="col m12 s12 white box-shadow padding-1x">
			<h3 class="blue-text title page-title center-align">Meet the team!</h3>
			<hr class="custom no-border"/>
			<p class="flow-text center-align padding-1x">
				Anudip Tech Team is built by a tight knit team of data nerds coding out of Kolkata.
				Any way we can make our users sleep better at night makes us happy.
			</p>
			<div class="col m12 s12 grey-text padding-1x">
				<!--row amit-->
				<div class="col s12 m6">
					<div class="card horizontal z-depth-0 ">
						<div class="card-image padding-1x center-align">
							<img alt="Amit Kumar gupta" class="about-img border--normal round" src="{{ URL::asset('images/team/amit.png')}}">
							<p class="top-gap">
								<a target="_blank" href="https://www.facebook.com/amitgupta.ti11">
								<i class="fa fa-facebook-official blue-text text-accent-1 fa-1_5x" aria-hidden="true"></i>
								</a>
								<a target="_blank" href="https://www.linkedin.com/in/amit-gupta-4747576a">
								<i class="fa fa-linkedin-square blue-text fa-1_5x text-accent-2" aria-hidden="true"></i>
								</a>
								<a target="_blank" href="https://github.com/amitgupta111088">
									<i class="fa fa-github red-text text-accent-1 fa-1_5x" aria-hidden="true"></i>
								</a>
							</p>
						</div>
						<div class="card-stacked">
							<div class="card-content animated slideInLeft">
								<h5 class="heading name normal-font">Amit Kr Gupta </h5>
								<span class="grey-text text-lighten-1">Backend DevOps</span>
								<p class="top-gap grey-text text-darken-1">Before software can be reusable it first has to be usable.</p>
							</div>
						</div>
					</div>
				</div>
				<!--End of row-->

				<!--row nilanjan-->
				<div class="col s12 m6">
					<div class="card horizontal z-depth-0">
						<div class="card-image padding-1x center-align">
							<img alt="Nilanjan Ganguly" class="about-img border--normal round" src="{{ URL::asset('images/team/nilanjan.jpg')}}">
							<p class="top-gap">
								<a target="_blank" href="https://www.facebook.com/nilanjan.ganguly2">
								<i class="fa fa-facebook-official blue-text text-accent-1 fa-1_5x" aria-hidden="true"></i>
								</a>
								<a target="_blank" href="https://in.linkedin.com/in/nilanjan-ganguly-614a5a3a">
								<i class="fa fa-linkedin-square blue-text fa-1_5x text-accent-2" aria-hidden="true"></i>
								</a>
								<i class="fa fa-github red-text text-accent-1 fa-1_5x" aria-hidden="true"></i>
							</p>
						</div>
						<div class="card-stacked">
							<div class="card-content  animated slideInRight">
								<h5 class="heading name normal-font">Nilanjan Ganguly</h5>
								<span class="grey-text text-lighten-1">Backend DevOps</span>
								<p class="top-gap grey-text text-darken-1">
									Learn and help out others in more passionate way of coding is my emualation.
								</p>
							</div>
						</div>
					</div>
				</div>
				<!--End of row-->
				<!--row subhojit-->
				<div class="col s12 m6">
					<div class="card horizontal z-depth-0  ">
						<div class="card-image padding-1x center-align">
							<img alt="Subhojit Ghosh" class="about-img border--normal round" src="{{ URL::asset('images/team/subhojit.jpeg')}}">
							<p class="top-gap">
								<a target="_blank" href="https://www.facebook.com/deviljit">
								<i class="fa fa-facebook-official blue-text text-accent-1 fa-1_5x" aria-hidden="true"></i>
								</a>
								<a target="_blank" href="https://in.linkedin.com/in/subhojitghosh">
								<i class="fa fa-linkedin-square blue-text fa-1_5x text-accent-2" aria-hidden="true"></i>
								<i class="fa fa-github red-text text-accent-1 fa-1_5x" aria-hidden="true"></i>
							</p>
						</div>
						<div class="card-stacked">
							<div class="card-content animated slideInLeft">
								<h5 class="heading name normal-font">Subhojit Ghosh </h5>
								<span class="grey-text text-lighten-1">UI/UX DevOps</span>
								<p class="top-gap grey-text text-darken-1">My goal is to listen, observe, understand, sympathize, empathize, synthesize, and glean insights that enable me to make the invisible visible.</p>
							</div>
						</div>
					</div>
				</div>
				<!--End of row-->
				<!--row tamaghna-->
				<div class="col s12 m6">
					<div class="card horizontal z-depth-0  ">
						<div class="card-image padding-1x center-align">
							<img class="about-img border--normal round" alt="Tamaghna Banerjee" src="{{ URL::asset('images/team/tamaghna.jpg')}}">
							<p class="top-gap">
							<a target="_blank" href="https://www.facebook.com/tamaghna.banerjee.33">
							<i class="fa fa-facebook-official blue-text text-accent-1 fa-1_5x" aria-hidden="true"></i>
							</a>
							<a target="_blank" href="https://in.linkedin.com/in/tamaghna-banerjee-05ba26104">
								<i class="fa fa-linkedin-square blue-text fa-1_5x text-accent-2" aria-hidden="true"></i>
							</a>
							<a target="_blank" href="https://github.com/tamaghna91">
								<i class="fa fa-github red-text text-accent-1 fa-1_5x" aria-hidden="true"></i>
							</a>
							</p>
						</div>
						<div class="card-stacked">
							<div class="card-content animated slideInRight">
								<h5 class="heading name normal-font">Tamaghna Banerjee</h5>
								<span class="grey-text text-lighten-1">UI/UX Geek</span>
								<p class="top-gap grey-text text-darken-1">Opensource Evangelist. Innovation with design and aspire other folks to success. Contributions and Community Involvement.</p>
							</div>
						</div>
					</div>
				</div>
				<!--End of row-->

			</div>
		</div>
	</div>
</div>
@endsection

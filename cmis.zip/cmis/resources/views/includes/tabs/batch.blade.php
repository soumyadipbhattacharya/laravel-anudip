<div class="batch-navigation top-app-navigation relative">
      <ul class="tabs blue">
        <li class="tab col s4"><a target="_self" class="white-text" href="{{url('/get/u/0/batch/new')}}">New Batch</a></li>
        <li class="tab col s4"><a target="_self" class="white-text" href="{{url('/get/u/0/batch/view')}}">View Batches</a></li>
        <li class="tab col s4"><a target="_self" class="white-text" href="{{url('/get/u/0/batch/enrollment')}}">Enroll Students</a></li>
        <li class="tab col s4"><a target="_self" class="white-text" href="{{url('/get/u/0/batch/schedule')}}">Schedule A Batch</a></li>
      </ul>
  </div>

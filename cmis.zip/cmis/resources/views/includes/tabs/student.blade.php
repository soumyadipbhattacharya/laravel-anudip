<div class="student-navigation top-app-navigation relative">
    <div class="col s12 auto none">
      <ul class="tabs blue">
        <li class="tab col s4"><a target="_self" class="white-text" href="{{url('/get/u/0/student/new')}}">New Student</a></li>
        <li class="tab col s4"><a target="_self" class="white-text" href="{{url('/get/u/0/student/view')}}">View Students</a></li>
        <li class="tab col s4"><a target="_self" class="white-text" href="{{url('/get/u/0/fees/new')}}">Collect Fees</a></li>
        <li class="tab col s4"><a target="_self" class="white-text" href="{{url('/get/u/0/uploads/new')}}">Upload Documents</a></li>
      </ul>
    </div>
  </div>

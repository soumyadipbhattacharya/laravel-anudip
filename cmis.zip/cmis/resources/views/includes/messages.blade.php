<!--Ajax messages-->
<div class="success ajax-response no-display center-align white-text animated" class="green accent-4"></div>
<div class="error ajax-response no-display center-align white-text animated" class="red accent-4"></div>


@if (Session::has('success'))
<div class="success message success-message center-align white-text animated slideInDown" class="green accent-4">
	<i class="material-icons relative">done</i>
	<b>{{ Session::get('success') }}</b>
</div>
@endif
	
@if (Session::has('danger'))
<div class="error message success-message center-align white-text animated slideInDown" class="red accent-4">
	<i class="material-icons relative">error</i>
	<b>{{ Session::get('danger') }}</b>
</div>
@endif

@if (Session::has('warning'))
<div class="amber message success-message center-align white-text animated slideInDown" class="amber accent-4">
	<i class="material-icons relative">warning</i>
	<b>{{ Session::get('warning') }}</b>
</div>
@endif

@if (isset($errors) && count($errors) > 0)
<div class="error message error-message white-text animated bounceInUp fixed" class="orange darken-4">
	<ul>
		@foreach ($errors->all() as $error)
		<li>
			<i class="fa fa-exclamation-triangle" aria-hidden="true"></i><b> {{ $error }} </b>
		</li>
		@endforeach
	</ul>
</div>
@endif

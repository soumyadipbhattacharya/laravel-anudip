<header class="col s12 m4 l2 blue z-depth-1 pace-loader top-app-bar">
	<aside class="appbar">
		@if(Auth::check())
			<ul id="slide-out" class="side-nav">
				<li>
					<div class="userView">
					<img class="background width-100" src="{{ asset('images/account-bg.jpg') }}">
					<a href="{{url('/u/0/account')}}"><img class="circle" src="{{ asset($getMemberinfo[0]->data) }}"/></a>
					<a href="#!name"><span class="white-text name">{{ ucwords($getMemberinfo[0]->first_name) }} {{ ucwords($getMemberinfo[0]->middle_name) }} {{ ucwords($getMemberinfo[0]->last_name) }}</span></a>
					<a href="#!email"><span class="white-text email">{{$getMemberinfo[0]->email_id}}</span></a>
					</div>
				</li>
				<li><a href="{{url('/u/0/home')}}"><i class="material-icons">insert_chart</i>My Dashboard</a></li>
				<li><a href="{{url('/get/u/0/student/new')}}"><i class="material-icons">supervisor_account</i>Students</a></li>
				<li><a href="{{url('/get/u/0/batch/new')}}"><i class="material-icons">today</i>Batches</a></li>
				<li><a href="{{url('/get/u/0/attendance/new')}}"><i class="material-icons">query_builder</i>Attendance</a></li>
				<div class="sidebar-footer absolute">
					<li><a class="subheader">&copy; Anudip Foundation for Social Welfare</a></li>
				</div>
			</ul>

			<a href="#" data-activates="slide-out" class="white-text relative hamburger button-collapse">
				<i class="material-icons fa-2x relative">menu</i>
			</a>
			<a class="app-title white-text relative auth-title" href="{{url('/u/0/home')}}">CMIS</a>

			<a href="{{url('support')}}" class="white-text right relative support hide-on-small-only">Get Support</a>
			<a class="dropdown-button relative right waves-effect waves-light" href="#!" data-activates="appbar-menu-slidein">
				<i class="material-icons fa-3x center-align white-text relative pointer">more_vert</i>
			</a>
			<ul id="appbar-menu-slidein" class="dropdown-content animated flipInY">
				<li>
					<a href="{{url('u/0/account')}}" class="grey-text text-darken-3">
						<i class="material-icons grey-text text-lighten-1 left">perm_identity</i>
						My Account
					</a>
				</li>
				<li>
					<a href="{{url('/u/0/change/password')}}" class="grey-text text-darken-3">
						<i class="material-icons grey-text text-lighten-1 left">vpn_key</i>
						Change Password
					</a>
				</li>
				<li class="hide-on-med-and-up">
					<a href="{{url('support')}}" class="grey-text text-darken-3">
						<i class="material-icons grey-text text-lighten-1 left">dialer_sip</i>
						Get Support
					</a>
				</li>
				<li class="divider"></li>
				<li>
					<a href="{{ url('/logout') }}" class="grey-text text-darken-3">
						<i class="material-icons grey-text text-lighten-1 left">settings_power</i>
						Log Off
					</a>
				</li>
			</ul>
		@else
			<a class="white-text relative hamburger" href="{{URL('/')}}">
				<span class="app-title">CMIS</span>
			</a>
		@endif
	</aside>
</header>

<!--Animated loader-->
<div class="loader white big hidden">
	<div class="preloader-wrapper big active">
		<div class="spinner-layer spinner-blue-only">
			<div class="circle-clipper left">
				<div class="circle"></div>
			</div>
			<div class="gap-patch">
				<div class="circle"></div>
			</div>
			<div class="circle-clipper right">
				<div class="circle"></div>
			</div>
		</div>
	</div>
</div>

<div class="white big active load-exponent fixed center-align">
	<img class="relative" src="{{URL('images/loader.gif')}}" />
	<h5 class="title normal load-caption relative fa-3x animated pulse">Working...</h5>
</div>

<!--div class="load-exponent white hidden fixed center-align">
	<img class="relative" src="{{URL('images/loader1.gif')}}" />
</div-->

@include('includes.breadcrumbs')

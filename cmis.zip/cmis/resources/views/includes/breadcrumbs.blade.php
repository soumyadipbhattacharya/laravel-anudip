<div class="relative breadcrumb--wrapper left">
	<?php $bread = Breadcrumbs::generate(); ?>
	@if ($bread)
		@foreach ($bread as $breadcrumb)
			@if ($breadcrumb->url && !$breadcrumb->last)
			<a href="{{ $breadcrumb->url }}" class="grey-text text-darken-1 breadcrumb">			{{$breadcrumb->title }}
			</a>
			@else
				<a class="grey-text bold text-darken-1 breadcrumb active">
					{{ $breadcrumb->title }}
				</a>
			@endif
		@endforeach
	@endif
</div>
<script type="text/javascript">

var student_record_count = 0;

//get students on select batch
function getStudentData(value,id){
	$('#attendance-wrapper').show();
	$('#attendance-wrapper').empty();
	$('#attendance_switch').prop("checked",false);
	$.ajax({
		type: "GET",
		url: {!! json_encode(url('/get/u/0/attendance/getBatchStudents')) !!},
		data: {
			'batch_code' : value
		},
		dataType : "json",
		beforeSend: function() {
			$(".loader").fadeIn("slow");
		},
		success: function(json){
			$(".loader").fadeOut("slow");
			if(json.length == 0){
				$(".attain i").removeClass("green-text");
				$(".attain").attr("data-badge-caption",0);
				$('#attendance-wrapper').addClass("center-align").html("<h5 class='red-text'>No Data Found</h5>");
				$('#attendance_switch').prop("disabled",true);
			}
			else{
				$('#attendance-wrapper').removeClass("center-align");
				$(".attain i").addClass("green-text");
				$(".attain").attr("data-badge-caption",json.length);
				student_record_count = json.length;
				$('#attendance_switch').prop("disabled",false);
				$('#attendance_switch').prop("checked",true);
				$.each(json, function(key, val) {
					var url = "<?php echo url(''); ?>/"+val.dp;
					$('#attendance-wrapper').append($('<input type="hidden" name="student_list['+val.m_id+']" value="off"><input checked onclick="checkCountStudents(this)" type="checkbox" id="student_list'+key+'" name="student_list['+val.m_id+']"/><label for="student_list'+key+'" class="bottom-gap tooltipped round waves-effect waves-light center-align" data-tooltip="'+val.fname+val.lname+val.m_code+'"><img src="'+url+'"/></label>'));
					//calling tooltip
					tooltip();
				});
			}
		}
	});
}

//checking attendance values
function checkCountStudents(param){
	//console.log(param);
	var count = parseInt($(".attain").attr("data-badge-caption"));
	if($(param).prop('checked')){
		count += 1;
		$(param).prop('checked',true);
	}
	else{
		count -= 1;
		$(param).prop('checked',false);
	}
	//console.log(student_record_count);
	if(count == 0){
		$(".attain i").removeClass("green-text");
		$('#attendance_switch').prop("checked",false);
	}
	else if(count > 0){
		$(".attain i").addClass("green-text");
		$('#attendance_switch').prop("checked",true);
	}
	$(".attain").attr("data-badge-caption",count);
}

$(document).ready(function(){
	$('#attendance_switch').click(function(){
		var count = parseInt($(".attain").attr("data-badge-caption"));
		if($(this).prop('checked')){
			$('#attendance-wrapper input[type="checkbox"]').each(function(i){
				if($(this).prop('checked') == false){
					count++;
				}
				$(this).prop('checked',true);
				//console.log(count);
			});
			$(".attain i").addClass("green-text");
		}
		else{
			$('#attendance-wrapper input[type="checkbox"]').each(function(i){
				if($(this).prop('checked') == true){
					count--;
				}
				$(this).prop('checked',false);
				//console.log(count);
			});
			$(".attain i").removeClass("green-text");
		}
		$(".attain").attr("data-badge-caption",count)
	});
});

</script>

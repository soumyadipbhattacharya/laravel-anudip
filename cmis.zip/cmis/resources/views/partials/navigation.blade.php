<script type="text/javascript">
	$(function() {
    //check of top navigtion is active
    if($(".top-app-navigation").is(":visible")){
     $(".top-app-bar").addClass("active");
     $(".content-wrapper").addClass("active");
    }
    
    //set active navigation
    var url = window.location.pathname,
    urlRegExp = new RegExp(url.replace(/\/$/, '') + "$");
    $('.top-app-navigation ul li a').each(function () {
      if (urlRegExp.test(this.href.replace(/\/$/, ''))) {
        $(this).addClass('active');
        $(this).parent().siblings().find('a').removeClass('active');
      }
    });   
  });
</script>
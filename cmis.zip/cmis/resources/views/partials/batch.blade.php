<script type="text/javascript">
	function getDependentValue(value, type, next_id) {
		if (next_id != "") {
			var center_id = $("#batchx_center_id").val();
			$program_id = $("#batchx_program_id").val();			
			$.ajax({
				type: "GET",
				url: {!! json_encode(url('/get/u/0/dependent/dropdown/list')) !!}, 
				data: {
					'value' : value,
					'type' : type,
					'center_id' : center_id,
					'program_id' : $program_id
				},
				dataType : "json",
				beforeSend: function() {
					$(".loader").fadeIn("slow");
				}, success: function(json) {
						//console.log(json);
						$('#' + next_id).empty();
						$(".loader").fadeOut("slow");
						$(".select-wrapper").siblings("label").removeClass("blue-text");
						if (json.length == 0) {
							$('#' + next_id).append($("<option value=''>No record found</option>"));
						} else {
							$('#' + next_id).removeAttr('disabled');
							$('#' + next_id).parent(".select-wrapper").siblings("label").addClass("blue-text");
							$('#'+ next_id).append($("<option></option>").text("Choose An Option"));
						
							if(next_id == "show_trainer_id"){
								// console.log("Batch_id ="+value);
								$.each(json, function(key, value) {
									$('#' + next_id).append($("<option></option>").attr("value", value.id).text(value.first_name+' '+value.last_name));
								});
								getBatchDayTime(value);
							}
							else{
								$.each(json, function(key, value) {
									$('#' + next_id).append($("<option></option>").attr("value", value.id).text(value.name));
								});
							}
							
						}
						$("#batchx_program_id option:first").attr('disabled','disabled');
						$("#batchx_trainer_id option:first").attr('disabled','disabled');
						$("#batchx_module_id option:first").attr('disabled','disabled');
						$('#' + next_id).material_select();
					}
				});
		}
	}
	$(document).ready(function() {
			//for enrollment
			$("#getBatchesList").change(function() {
				var batch_id = $(this).val();
				var Base64={_keyStr:"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=",encode:function(e){var t="";var n,r,i,s,o,u,a;var f=0;e=Base64._utf8_encode(e);while(f<e.length){n=e.charCodeAt(f++);r=e.charCodeAt(f++);i=e.charCodeAt(f++);s=n>>2;o=(n&3)<<4|r>>4;u=(r&15)<<2|i>>6;a=i&63;if(isNaN(r)){u=a=64}else if(isNaN(i)){a=64}t=t+this._keyStr.charAt(s)+this._keyStr.charAt(o)+this._keyStr.charAt(u)+this._keyStr.charAt(a)}return t},decode:function(e){var t="";var n,r,i;var s,o,u,a;var f=0;e=e.replace(/[^A-Za-z0-9+/=]/g,"");while(f<e.length){s=this._keyStr.indexOf(e.charAt(f++));o=this._keyStr.indexOf(e.charAt(f++));u=this._keyStr.indexOf(e.charAt(f++));a=this._keyStr.indexOf(e.charAt(f++));n=s<<2|o>>4;r=(o&15)<<4|u>>2;i=(u&3)<<6|a;t=t+String.fromCharCode(n);if(u!=64){t=t+String.fromCharCode(r)}if(a!=64){t=t+String.fromCharCode(i)}}t=Base64._utf8_decode(t);return t},_utf8_encode:function(e){e=e.replace(/rn/g,"n");var t="";for(var n=0;n<e.length;n++){var r=e.charCodeAt(n);if(r<128){t+=String.fromCharCode(r)}else if(r>127&&r<2048){t+=String.fromCharCode(r>>6|192);t+=String.fromCharCode(r&63|128)}else{t+=String.fromCharCode(r>>12|224);t+=String.fromCharCode(r>>6&63|128);t+=String.fromCharCode(r&63|128)}}return t},_utf8_decode:function(e){var t="";var n=0;var r=c1=c2=0;while(n<e.length){r=e.charCodeAt(n);if(r<128){t+=String.fromCharCode(r);n++}else if(r>191&&r<224){c2=e.charCodeAt(n+1);t+=String.fromCharCode((r&31)<<6|c2&63);n+=2}else{c2=e.charCodeAt(n+1);c3=e.charCodeAt(n+2);t+=String.fromCharCode((r&15)<<12|(c2&63)<<6|c3&63);n+=3}}return t}}
				batch_id = Base64.encode(batch_id);
				window.location = "<?php echo url(''); ?>/get/u/0/batch/enrollment/"+batch_id;

			});

		});


//to get Batch Day and Time
	function getBatchDayTime(batch_id) {
		var b_id= batch_id;
		$("#show-batch-trainer-details").addClass("no-display");
		$.ajax({
				url: {!! json_encode(url('/get/u/0/batch/getBatchDayTime')) !!},
				type:"GET",
				data:{
					'batch_id': b_id
				},
				dataType: "json",
				success: function(json){
					console.log(json);
					$("#show-batch-trainer-details .info-wrapper").empty();
					$("#show-batch-trainer-details").removeClass("no-display");
					$.each(json, function(key, value) {
						$(".info-wrapper").append($("<div class='top-gap icon-info chip grey accent-1 white-text'><i class='icon-info material-icons white-text relative'>perm_identity</i>"+value.fname+' '+value.lname+' | '+value.day+', '+value.t_from+' - '+value.t_to+"<i class='icon-info close material-icons red-text text-accent-1 bold' onclick='deleteSchedule(\""+value.id+"\")'>close</i></div>"));
					});
				}
			});
	}
	
	
	//to search students
	function searchViewBatches(keyword) {
		if (keyword != "") {
			$('.view-batches .collapsible li').hide();
			$('.view-batches .collapsible li').each(function() {
				if ($(this).find(".collapsible-header ").text().toUpperCase().indexOf(keyword.toUpperCase()) != -1 || $(this).find(".collapsible-body").text().toUpperCase().indexOf(keyword.toUpperCase()) != -1) {
					$(this).show();
				}
			});
		} else {
			$('.view-batches .collapsible li').show();
		}
	}

	//Save Batch schedule day/times
	$(".more.link").click(function(){
		$("#show-batch-trainer-details .info-wrapper").empty();
		$("#show-batch-trainer-details").addClass("no-display");
		var batch_id = $("#get_batch_trainer_id").val();
		var trainer_id = $("#show_trainer_id").val();
		var selected_day = $("input[name='day_selected[]']:checked").val();
		var start_time = $("#start_time").val();
		var end_time = $("#end_time").val();
		if(batch_id == null || trainer_id == null || start_time == null || end_time == null || selected_day == null || selected_day == undefined){
			Materialize.toast('You seem to have missed some fields!', 3000);
		}
		else{
			$("#show-batch-trainer-details").removeClass("no-display");
			var day_checked_data = new Array();
			$("input[name='day_selected[]']:checked").each(function(i) {
				day_checked_data.push($(this).val());
				$(this).prop('checked',false);
			});
			$.ajax({
				url: {!! json_encode(url('/post/u/0/batch/savedaytime')) !!},
				type:"POST",
				data:{
					'batch_days': day_checked_data,
					'batch_id': batch_id,
					'trainer_id': trainer_id,
					'start_time': start_time,
					'end_time': end_time,
					'_token': $("input[name='_token']").val()
				},
				dataType: "json",
				beforeSend: function() {
					$(".loader").fadeIn("slow");
				}, success: function(json){
					//console.log(json);
					$(".loader").fadeOut("slow");
					$.each(json, function(key, value) {
						$(".info-wrapper").append($("<div class='top-gap icon-info chip grey accent-1 white-text'><i class='icon-info material-icons white-text relative'>perm_identity</i>"+value.fname+' '+value.lname+' | '+value.day+', '+value.t_from+' - '+value.t_to+"<i class='icon-info close material-icons red-text text-accent-1 bold' onclick='deleteSchedule(\""+value.id+"\")'>close</i></div>"));
					});
				}
			});
		}
	});

	//delete batch_schedule id
	function deleteSchedule(id){
		console.log($(".info-wrapper").children().length);
		if($(".info-wrapper").children().length == 1){
			$("#show-batch-trainer-details").addClass("no-display");
		}
		if (id != "") {
			$.ajax({
				url: {!! json_encode(url('/post/u/0/batch/deletedaytime')) !!},
				type: "POST",
				data: {
					'batch_day_id': id,
					'_token': $("input[name='_token']").val()
				},
				dataType: "json",
				beforeSend: function() {
					$(".loader").fadeIn("slow");
				}, success: function(json){
					$(".loader").fadeOut("slow");
					if(!json){
						Materialize.toast('Some error occured. Try Again!', 3000);
					}
					else{
						$(this).parent(".icon-info.chip").remove();
					}
				}
			});
		}
	}

	//Modal list of enrolled students
	function showList(b_id){
		$("#show-enrolled-students").closeModal();
		$("#show-enrolled-students ul.collection").empty();
		if(b_id != "" || parseInt(b_id) > 0){
			$.ajax({
				url: {!! json_encode(url('/get/u/0/batch/showEnrolledStudentList')) !!},
				type: "GET",
				data: {
					'batch_id': b_id
				},
				dataType: "json",
				beforeSend: function() {
					//$(".load-exponent").fadeIn("slow");
				},success: function(json){
					//$(".load-exponent").fadeOut("slow");
					if(json.length == 0){
						Materialize.toast('No enrolled record found. Enroll to see the lirst!', 5000);
					}
					else{
						$("#show-enrolled-students").openModal();
						$("#show-enrolled-students span.count").text("(" + json.length+ " record(s) found)");
						$.each(json, function(key, value) {
							var url = "<?php echo url(''); ?>/"+value.data;
							$("#show-enrolled-students ul.collection").append($('<li class="collection-item avatar blue-text"><img src="'+url+'" alt="'+value.first_name+'" class="circle"><h6 class="black-text text-darken-1 margin-top-off">'+value.first_name+' '+value.last_name+' <span class="title red-text" style="font-size:18px !important;font-weight:300">('+value.member_code+')</span></h6><h6 class="grey-text text-darken-1"><i class=" material-icons modalicon">email</i><a href="mailto:'+value.email_id+'"target="_blank">'+value.email_id+'</a><h6 class="grey-text text-darken-1"><i class="material-icons modalicon">phone</i>'+value.mobile_no+'</h6></li>'));
						});
					}
				}
			});
		}
		else{
			Materialize.toast('Some error occured, try again later!', 5000);
		}
	}
	$('div.doc_note:empty').hide();

	$('#batchx_center_id').change(function () {
    $('input:text').removeAttr('selected');
});
</script>

<script type="text/javascript" src="{{ URL::asset('scripts/min/freshslider.min.js') }}"></script>
<script type="text/javascript">
	$(document).ready(function() {

	//scrollfire
	var options = [{
	selector : '#staggered-shortcut',
	offset : 500,
	callback : function(el) {
	Materialize.toast("Red marked fields are mandatory. Use shift + spacebar to move next tab!", 10000);
	}
	}];
	Materialize.scrollFire(options);

	//switch button toggle block
	if ($("input[type='checkbox']").prop('checked') && $(".input-field").hasClass($("input[type='checkbox']").attr('id'))) {
	$(".input-field." + $("input[type='checkbox']").attr('id')).toggleClass("no-display");
	}
	$("input[type='checkbox']").click(function() {
	if ($(".input-field").hasClass($(this).attr('id'))) {
	$(".input-field." + $(this).attr('id')).children().val('');
	$(".input-field." + $(this).attr('id')).toggleClass("no-display");
	}
	});

	//DOM manipulation
	var gender_type = null;
	var married_status = null;

	$(".gender-type input[type='radio']").bind('click', function() {
	gender_type = $(this).data("value");
	$(".gender-status-dependency").addClass("no-display");
	if (gender_type == "female" && married_status == "married") {
	$(".gender-status-dependency").removeClass("no-display");
	}
	});
	$(".married-status input[type='radio']").bind('click', function() {
	married_status = $(this).data("value");
	$(".gender-status-dependency").addClass("no-display");
	if (gender_type == "female" && married_status == "married") {
	$(".gender-status-dependency").removeClass("no-display");
	}
	});

	$("select.referal_entity").on("change", function() {
	var entity_type = $(this).val();
	$(".referal_entity_data_pox").children().val('');
	$(".other-details .referal_entity_data_pox").addClass("no-display");
	if (entity_type == "Anudip Student") {
	$(".student_referal_program").removeClass("no-display");
	} else if(entity_type == "Other Reference") {
	$(".other_referal_pick").removeClass("no-display");
	}
	});

	$("body").on('click', function() {
	$("ul.suggestion-box").hide();
	$(".preloader").addClass("no-display");
	});

	//ajax post request - fees insertion
	$("button#submit-fees").click(function() {
	var x = $("input[name='amount']").val();
	$.ajax({
	type: "POST",
	url: {!! json_encode(url('post/u/0/fees/new')) !!},
	data: {
	'_token' : $("#meta-token").val(),
	'member_code' : $("input[name='member_code']").val(),
	'amount' : $("input[name='amount']").val(),
	'receipt_no' : $("input[name='receipt_no']").val(),
	'receiving_date' : $("input[name='receiving_date']").val(),
	'received_by' : $("input[name='received_by']").val()
	},
	dataType : "json",
	success : function(json) {
	if(!json) {
	$('.error.ajax-response').text("You might have missed something. Try again later.").removeClass("no-display").addClass("slideInDown");
	setTimeout(function() {
	$('.error.ajax-response').removeClass("slideInDown").slideUp("normal");
	}, 5000 );
	}
	else{
	$(".fees-collection input").removeClass("valid").val('');
	$('.success.ajax-response').text("New fees saved successfully. :)").removeClass("no-display").addClass("slideInDown");
	setTimeout(function() {
	$('.success.ajax-response').removeClass("slideInDown").slideUp("normal");
	}, 5000 );
	}
	$("html, body").animate({ scrollTop: 0 }, "slow");
	window.setTimeout(function(){location.reload()},2000);
	}
	});
	});

	//ajax request - registration details
	$("input.autocomplete.filled-registration").keyup(function() {
	if ($(this).val().length > 3) {
	var element = $(this).attr('id');
	$("input[name=" + element + "]").attr('value', '');
	$('ul.suggestion-box').empty();
	var type = $(this).data('type');
	$.ajax({
	type: "GET",
	url: {!! json_encode(url('/get/u/0/search/keyword/getlists')) !!},
	 data:'keyword='+$(this).val()+'&type='+type,
	dataType : "json",
	beforeSend: function() {
	$("#" + element).next(".preloader").removeClass("no-display");
	}, success: function(json) {
	//console.log(json);
	if (json.length == 0) {
	$("#" + element).siblings("ul.suggestion-box").append($("<li><span><span class='highlight'>No data found</span></span></li>"));
	} else {
	$('ul.suggestion-box').empty();
	$("#" + element).siblings("ul.suggestion-box").fadeIn("slow");
	$.each(json, function(key, value) {
	$("#" + element).siblings("ul.suggestion-box").append($("<li onClick=\"selectAutoCompleteValue('" + null + "','" + value.id + "','" + element + "','" + value.pincode + "')\"><span><span class='highlight'>" + value.pincode + "-" + value.division_name + "-" + value.officename + "</span></span></li>"));
	});
	}
	}
	});
	}
	});

	//ajax request to fetch student id
	$("input.autocomplete.students_id").keyup(function() {
	if ($(this).val().length > 1) {
		var element = $(this).attr('id');
		var type = $(this).data('type');
		//$("input[name=" + element + "]").attr('value', '');
	if(type == "fees"){
		$("input[name='member_code'").val('');
	}
	$('ul.suggestion-box').empty();
	var st_id = $("input[name='member_code']").val();
	if(type == "fees" && st_id.length == 0){
		$("input[name='received_by']").val('');
		$('#received_by').attr('disabled',true);
		
	}	
	$.ajax({
	type: "GET",
	url: {!! json_encode(url('/get/u/0/search/keyword/getstudentlist')) !!},
	data: 'st_id='+st_id+'&keyword='+$(this).val()+'&type='+type,
	dataType : "json",
	beforeSend: function() {
	if(st_id == null){
	Materialize.toast('Please specify student id', 3000);
	}
	$("#" + element).next(".preloader").removeClass("no-display");
	}, success: function(json) {
	console.log(json);
	console.log(element);

	if (json=="") {
	$("#" + element).siblings("ul.suggestion-box").fadeIn("slow");
	$("#" + element).siblings("ul.suggestion-box").append($("<li><span><span class='highlight'>No data found</span></span></li>"));
	} else {
	$('ul.suggestion-box').empty();
	$("#" + element).siblings("ul.suggestion-box").fadeIn("slow");
	if (type == "fees") {
		$.each(json, function(key, value) {
		var url = "<?php echo url(''); ?>/"+value.data;
		var total_cr_amount = value.total_Cr_amount;
			if(total_cr_amount == undefined){
				total_cr_amount = 0;
			}
		var total_db_amount = value.total_Db_amount;
			if(total_db_amount == undefined){
				total_db_amount = 0;
			}
		var balance = total_cr_amount - total_db_amount;
		var final_content = "<b>CR: </b>" + total_cr_amount + ",  <b>DR: </b>" + total_db_amount + ",  <b>Balance: </b>" + balance;
			$("#" + element).siblings("ul.suggestion-box").append($("<li onClick=\"selectAutoCompleteValue('" + final_content + "','" + value.id + "','" + element + "','" + value.member_code + "')\"><span class='label-wrapper'><img class='round left' src='" +url+ "'><span class='highlight'>" + value.member_code + " - " + value.first_name + " " + value.last_name+"</span></span></li>"));
		});
		}
		else {
		$.each(json, function(key, value) {
		var url = "<?php echo url(''); ?>/"+value.data;
		$("#" + element).siblings("ul.suggestion-box").append($("<li onClick=\"selectAutoCompleteValue('" + null + "','" + value.member_id + "','" + element + "','" + value.member_code + "')\"><span class='label-wrapper'><img class='round left' src='"  +url+ "'><span class='highlight'>" + value.member_code + " - " + value.first_name + " " + value.last_name+ "</span></img></span></li>"));
		});
		}
		}
		}
		});
		}
		});

		$(".ticker-close").click(function() {
		//console.log($(this).find("i").text());
		if ($(this).find("i").text() == "expand_less") {
		$(this).find("i").text("expand_more");
		} else {
		$(this).find("i").text("expand_less");
		}
		$(this).find("i").toggleClass("blue-text text-darken-1");
		$(".footer-search").toggleClass("slideOutDown");
		});

		var get_value = $("#no_of_members").data("value");

		var s3 = $("#no_of_members").freshslider({
		step : 1,
		min: 1,
		max: 20,
		value : get_value,
		onchange:function(low, high){
		$("input[name='no_of_members']").attr('value',$("#no_of_members").text());
		//console.log($("#no_of_members").text());
		}
		});

		var get_value = $("#no_of_earning_members").data("value");
		var s3 = $("#no_of_earning_members").freshslider({
		step : 1,
		min: 1,
		max: 20,
		value : get_value,
		onchange:function(low, high){
		$("input[name='no_of_earning_members']").attr('value',$("#no_of_earning_members").text());
		//console.log($("#no_of_members").text());
		}
		});

		//Remove multiple attr, if image type.Get meta data of upload list
		$("select[name='doc_type']").on('change',function(){
			$(".file-details").empty();
			$(".file-details").text($('option:selected', this).attr('data-value'));			
			$(".file-field input[name='change_lmx_u750_document_upload[]']").attr('multiple','multiple');
			if($(this).val() == "1"){
				$(".file-field input[name='change_lmx_u750_document_upload[]']").removeAttr('multiple');
			}
		}); 

		//Fees collection page
		//$('#received_by').attr('disabled',true);

		$(".alpha").keypress(function(event){
		 var inputValue = event.which;
			 // allow letters and whitespaces only.
			 if(!(inputValue >= 65) && (inputValue != 32 && inputValue != 8 && inputValue != 0)) {
				 return false;
			 }
	 });
		
		$(".view_type_icon.toggle").click(function(){
			$(".view_type_icon.toggle").removeClass("active");
			$(this).addClass("active");
		});
		
	});

$(document).bind('keypress', function(event) {
		//var key = e.which;
		if (event.which === 32 && event.shiftKey) {
			$("ul.collapsible li").removeClass("prev");
			if ($('ul.collapsible li').hasClass("last active")) {
				$("ul.collapsible li.first").children(".collapsible-header").trigger("click");
			} else {
				$("ul.collapsible li").each(function() {
					if ($(this).hasClass("active")) {
						$(this).addClass("prev");
						$(this).children(".collapsible-header").trigger("click");
					}
				});
				$("ul li.prev").next().children(".collapsible-header").trigger("click");
			}
		}
	});


	//Modal list of student's file status
	function showFileStatus(member_id,member_code){
		$(".loader").fadeIn("slow");
		$("#showFileStatus").closeModal();
		$("#showFileStatus ul.collection").empty();
		if(member_id != "" || parseInt(member_id) > 0){
			$.ajax({
				url: {!! json_encode(url('/get/u/0/getDocumentList')) !!},
				type: "GET",
				data: {
					'member_id': member_id
				},
				dataType: "json",
				beforeSend: function() {
				},success: function(json){
					$(".loader").fadeOut("slow");
					if(json.length == 0){
						Materialize.toast('No record found. Problem in showing record!', 5000);
					}
					else{
						$("#showFileStatus").openModal();
						$("#showFileStatus span.count").text("(" + json.length+ " records found for member "+ member_code +")");
						$.each(json, function(key, value) {
							if(value.t_status == 1){
								var icon = '<i class="small material-icons green-text text-accent-3 tooltipped">done</i>';
							}
							else{
								var icon = '<i class="small material-icons orange-text text-accent-2">warning</i>';
							}
							$("#showFileStatus ul.collection").append($('<li class="collection-item"><h6 class="black-text text-darken-2">'+value.t_cat_name+'<span class="right relative status">'+icon+'</span></h6></li>'));
						});
					}
				}
			});
		}
		else{
			Materialize.toast('Are you screaming at me!', 5000);
		}
	}

		//to search students
		function searchViewStudents(keyword) {
			if (keyword != "") {
				$('.view-students .card-grid').hide();
				$('.view-students ul.collection li').hide();
				$('.view-students .card-grid').each(function() {
					if ($(this).text().toUpperCase().indexOf(keyword.toUpperCase()) != -1 || $(this).find(".24x-member-long-code-x").text().toUpperCase().indexOf(keyword.toUpperCase()) != -1) {
						$(this).show();
					}
				});
				$('.view-students ul.collection li').each(function() {
					if ($(this).text().toUpperCase().indexOf(keyword.toUpperCase()) != -1 || $(this).find(".24x-member-long-code-x").text().toUpperCase().indexOf(keyword.toUpperCase()) != -1) {
						$(this).show();
					}
				});
			} else {
				$('.view-students .card-grid').show();
				$('.view-students ul.collection li').show();
			}
		}

		//function to trigger autocomplete
		function selectAutoCompleteValue(total='',id=null,element, val) {
			//setting false if value found on student_id
			$('#received_by').attr('disabled',false);
			if (total == "undefined" && element == "member_code") {
				$("span#total_amount").removeAttr("disabled").prop("readonly", true);
				$("label[for='total_amount']").focus();
				$("span#total_amount").attr('value', '0').addClass("red-text");
			}
			else if(total != "" && element == "member_code"){
				$("div.total_amount").removeClass("hidden");
				$("span#total_amount").removeAttr("disabled").prop("readonly", true);
				$("label[for='total_amount']").focus();
				$("span#total_amount").html(total);
			}

			$("input[name=" + element + "]").attr('value', id);
			$("#" + element).val(val);
			$(".suggestion-box").fadeOut("fast");
			$("#" + element).next(".preloader").addClass("no-display");
		}

		//Accept only alphabet
		function onlyAlpha(e, t) {
			try {
				if (window.event) {
					var charCode = window.event.keyCode;
				}
				else if (e) {
					var charCode = e.which;
				}
				else { return true; }
				if ((charCode > 64 && charCode < 91) || (charCode > 96 && charCode < 123))
					return true;
				else
					return false;
			}
			catch (err) {
				alert(err.Description);
			}
		}


		//Limit amount paying
		function validateRange(ele) {    
		    var val = ele.val();
		    if( parseInt(val,10) < 0 || parseInt(val,10) > 49999){
		       
		        $("#errmsg").html("Enter Amount Below 50,000").show().fadeOut(4000);
		        $('#amount').val("");
			return false;
		    } 

		}
		$('.digit-validation').keyup(function(event){
		    validateRange($(this));
		});
	</script>

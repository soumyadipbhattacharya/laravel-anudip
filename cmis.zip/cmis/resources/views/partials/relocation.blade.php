<!-- <script type="text/javascript" src="{{ URL::asset('scripts/min/freshslider.min.js') }}"></script> -->
<script type="text/javascript">
	$(document).ready(function() {
		
		$(".assign_form_and_list").hide();
		$(".card-action").hide();
		//ajax request to fetch member id
		$("input.autocomplete.member_id").keyup(function() {
			if ($(this).val().length > 1) {
				var element = $(this).attr('id');
				var type = $(this).data('type');
				// alert(element+"--"+type);
				if(type == "hrmovement"){
					$("input[name='member_code'").val('');
				}
				$('ul.suggestion-box').empty();
				var st_id = $("input[name='member_code']").val();
				//alert(st_id+"--"+$(this).val());
				$.ajax({
					type: "GET",
					url: {!! json_encode(url('/get/u/0/search/keyword/getmemberlist')) !!},
					data: 'st_id='+st_id+'&keyword='+$(this).val()+'&type='+type,
					dataType : "json",
					beforeSend: function() {
						if(st_id == null){
							Materialize.toast('Please specify Member id', 3000);
						}
					}, success: function(json) {
						// console.log(json);
						if (json=="") {
							$("#" + element).siblings("ul.suggestion-box").fadeIn("slow");
							$("#" + element).siblings("ul.suggestion-box").append($("<li><span><span class='highlight'>No data found</span></span></li>"));
						} 
						else {
							$('ul.suggestion-box').empty();
							$("#" + element).siblings("ul.suggestion-box").fadeIn("slow");
							$.each(json, function(key, value) {
								var url = "<?php echo url(''); ?>/"+value.data;
								$("#" + element).siblings("ul.suggestion-box").append($("<li onClick=\"selectAutoCompleteValue('"+value.first_name+" "+value.last_name+"', '"+ value.email_id +"', '"+ value.mobile_no +"', '"+ url +"', '" + value.id + "','" + element + "','" + value.member_code + "', '"+ value.user_id +"')\"><span class='label-wrapper'><img class='round left' src='"  +url+ "'><span class='highlight'>" + value.member_code + " - " + value.first_name + " " + value.last_name+ "</span></img></span></li>"));
							});
							
						}
					}
				});
			}else{
				$(".card-action").fadeOut("slow");
				$(".assign_form_and_list").fadeOut("slow");
			}
		});	
	});
	
	//function to trigger autocomplete
	function selectAutoCompleteValue(fullname, email, mobile_no, url, id=null,element, val, user_id) {
		//alert(id+"--"+element+"--"+val);
		$("input[name=" + element + "]").attr('value', id);
		$("#" + element).val(val);
		$('.avtar img').attr("src",url);
		$(".suggestion-box").fadeOut("fast");
		$('.defaultName').text(fullname);
		$('.defaultId').text(val);
		$('.defaultEmail').text(email);
		$('.defaultPhone').text(mobile_no);
		$("#user_id").val(user_id);
		$(".card-action").fadeIn("slow");
		$.ajax({
			type: "GET",
			url: {!! json_encode(url('/get/u/0/search/keyword/getMemberRoles')) !!},
			data: 'member_id='+id,
			dataType : "json",
			success: function(data) {
				if (data=="") {
					$(".assign_form_and_list").fadeIn("slow");
					$('#roleData').empty();
					$("#roleHead").siblings("#roleData").append($("<tr><td colspan='3'>No data Found</td></tr>"));
				} 
				else {
					$('#roleData').empty();
					$.each(data, function(key, value) {
						// console.log(value);
						$("#user_id").val(value.user_id);
						$("#member_id").val(value.member_id);
						$(".assign_form_and_list").fadeIn("slow");
						var creation_date = value.created_at.substring(0,10);
						$("#roleHead").siblings("#roleData").append($('<tr><td>'+ value.short_code +'</td><td>'+ value.program_name +'</td><td>'+ value.name.toUpperCase() +'</td><td>'+ creation_date +'</td><td><a href="#" onclick="removeUserRole('+value.center_id+','+value.user_id+','+value.role_id+','+value.prog_id+')"><i class="material-icons tooltipped" data-position="right" data-delay="50" data-tooltip="Click to remove from list" >clear</i></a></td></tr>'));
					});
					
				}
			}
		});
	}
	
	$("body").on('click', function() {
		$("ul.suggestion-box").hide();
	});

    function getCenterList(program_id) {
       var p_id = program_id.value;
       $.ajax({
			type: "GET",
			url: {!! json_encode(url('/get/u/0/search/keyword/getCenterListByProgram')) !!},
			data: 'program_id='+p_id,
			dataType : "json",
			beforeSend: function() {
				$(".loader").fadeIn("slow");
			}, success: function(json) {
						$('#center_lists').empty();
						$(".loader").fadeOut("slow");
						if (json.length == 0) {
							alert("here");
							$('#center_lists').append($("<option value='' disabled>No record found</option>"));
						} else {
							$('#center_lists').attr('disabled',false);
							$('#center_lists').parent(".select-wrapper").siblings("label").addClass("blue-text");
							$('#center_lists').append($("<option></option>").attr({value:'',disabled:true}).text("Choose centers"));
							$.each(json, function(key, value) {
								$('#center_lists').append($("<option></option>").attr("value", value.id).text(value.short_code));
							});
						}
						$('#center_lists').material_select();
					}
		});
    }
    
    //Ajax - on save assign user roles
    function assignUser() {
        var c_ids = [];
        $.each($("#center_lists option:selected"), function(){            
            c_ids.push($(this).val());
        });
            $.ajax({
				type: "POST",
				url: {!! json_encode(url('/post/u/0/save/role')) !!},
				data: {
						'program_id' : $("#program_id").val(),
						'center_ids[]' : c_ids,
						'role_id' : $("#role_id").val(),
						'_token' : $("input[name='token']").val(),
						'user_id' : $("#user_id").val(),
						'from_date' : $(".assign_from_date").val()
						
				},
				dataType : "json",
				beforeSend: function() {
					$(".loader").fadeIn("slow");
				}, success: function(json) {
					$(".loader").fadeOut("slow");
					console.log(json);
					if(json.length==0){
						Materialize.toast('No record found!', 5000);
					}else if(json == "noCenter"){
						Materialize.toast('Please Select the Center!', 5000);
					} else if(json == "noRole"){
						Materialize.toast('Please Select the Role!', 5000);
					} else if(json == "noProgram"){
						Materialize.toast('Please Select at least one Program!', 5000);
					}
					else{
						$('#roleData').empty();
						$.each(json, function(key, value) {
							var creation_date = value.created_at.substring(0,10);
							$("#roleHead").siblings("#roleData").append($('<tr><td>'+ value.short_code +'</td><td>'+ value.program_name +'</td><td>'+ value.name.toUpperCase() +'</td><td>'+ creation_date +'</td><td><a href="#" onclick="removeUserRole('+value.center_id+','+value.user_id+','+value.role_id+','+value.prog_id+')"><i class="material-icons tooltipped" data-position="right" data-delay="50" data-tooltip="Click to remove from list" >clear</i></a></td></tr>'));
						});
					}
				}
			});
    }
    //Ajax - on save assign user roles
    function removeUserRole(center_id,user_id,role_id,program_id) {
    	//alert(center_id+"--"+user_id+"--"+role_id+"--"+program_id);
        $.ajax({
			type: "POST",
			url: {!! json_encode(url('/post/u/0/remove/role')) !!},
			data: {
					'center_id' : center_id,
					'user_id' : user_id,
					'role_id' : role_id,
					'_token' : $("input[name='token']").val(),
					'program_id' : program_id
			},
			dataType : "json",
			beforeSend: function() {
				$(".loader").fadeIn("slow");
			}, success: function(json) {
				$(".loader").fadeOut("slow");
				if(!json){
					Materialize.toast('No enrolled record found. Enroll to see the first!', 5000);
				}
				else{
					$('#roleData').empty();
					$.each(json, function(key, value) {
						var creation_date = value.created_at.substring(0,10);
						$("#roleHead").siblings("#roleData").append($('<tr><td>'+ value.short_code +'</td><td>'+ value.program_name +'</td><td>'+ value.name.toUpperCase() +'</td><td>'+ creation_date +'</td><td><a href="#" onclick="removeUserRole('+value.center_id+','+value.user_id+','+value.role_id+','+value.prog_id+')"><i class="material-icons tooltipped" data-position="right" data-delay="50" data-tooltip="Click to remove from list" >clear</i></a></td></tr>'));
					});
				}
			}
		});
    }
    
    
</script>
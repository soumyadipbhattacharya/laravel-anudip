<?php

namespace App\Providers;
use DB;
use Auth;
use Session;
use Illuminate\Contracts\Auth\Guard as Guard;
use Illuminate\Contracts\Auth\Access\Gate as GateContract;
use Illuminate\Foundation\Support\Providers\AuthServiceProvider as ServiceProvider;

class AuthServiceProvider extends ServiceProvider
{
    /**
     * The policy mappings for the application.
     *
     * @var array
     */
    protected $policies = [
        'App\Model' => 'App\Policies\ModelPolicy',
    ];

    /**
     * Register any application authentication / authorization services.
     *
     * @param  \Illuminate\Contracts\Auth\Access\Gate  $gate
     * @return void
     */
    public function boot(GateContract $gate,Guard $auth){
       	 	$this->registerPolicies($gate);
			view()->composer(['includes.appbar', 'auth.account'], function($view) use ($auth){
			if(!is_null($auth->user())){
				
				//get Member details
				$getMemberinfo = array();
	            $getMemberinfo = DB::table('members as m')
					               		->where('u.id',Auth::user()->id)
										->where('ft.status',TRUE)
										->join('users as u','u.member_id','=','m.id')
										->leftJoin('file_uploads_tr as ft','m.id','=','ft.member_id')
										->leftJoin('employee_tr as et','m.id','=','et.member_id')
                                        ->leftJoin('departments as dp','et.department_id','=','dp.id')
                                        ->leftJoin('designations as ds','et.designation_id','=','ds.id')
										->get(['u.*','ft.*','et.*','m.id as m_id','m.*','ds.name as designation','dp.name as department','m.updated_at as modified_at']);
                
				if(!empty($getMemberinfo)){
	                $modified_at = AuthServiceProvider::time_elapsed_string($getMemberinfo[0]->modified_at);
	                $getMemberinfo[0]->modified_at = $modified_at;
					Session::set('session_m_id', $getMemberinfo[0]->m_id);
					
				}

                //reporting info
                $reporting_name = array();
                if(!empty($getMemberinfo[0]->reporting_member_id)){
                $reporting_name = DB::table('members as m')
                                ->where('m.id',$getMemberinfo[0]->reporting_member_id)
                                ->get(['m.*']);
                }

                //last login info
                $last_login_info = array();
                $last_login_info = DB::table('event_logs as ev')
                                    ->where('ev.created_by',Auth::user()->id)
                                    ->where('event_details','collecting user id')
                                    ->where('event_status',TRUE)
                                    ->where('event_name','Authentication Success')
                                    ->orderBy('created_at','desc')
                                    ->take(1)
                                    ->get();

                if(!empty($last_login_info)){
	                $last_login = AuthServiceProvider::time_elapsed_string($last_login_info[0]->created_at);
		            $last_login_info[0]->last_login_info = $last_login;
				}
				
                //last password change info
                $last_password_change_info = array();
                $last_password_change_info = DB::table('event_logs as ev')
                                            ->where('ev.created_by',Auth::user()->id)
                                            ->where('event_name','Change Password')
                                            ->orWhere('event_name','Password Reset Action')
                                            ->where('event_status',TRUE)
                                            ->orderBy('created_at','desc')
                                            ->take(1)
                                            ->get();

				if(!empty($last_password_change_info)){
                	$last_password_change = AuthServiceProvider::time_elapsed_string($last_password_change_info[0]->updated_at);
                	$last_password_change_info[0]->last_password_change_info = $last_password_change;
				}

                $view->with(compact('getMemberinfo','reporting_name','last_login_info','last_password_change_info')); 
                // does what we expect in view
			}
        });
    }


    /**
     * Return raw timestamp in "time ago" format.
     *
     * @param  string $ptime
     * @return Response
    */
    public function time_elapsed_string($ptime){

        $etime = time() - strtotime($ptime);
        if ($etime < 30)
        {
            return 'Just Now';
        }
        $a = array( 365 * 24 * 60 * 60  =>  'year',
                     30 * 24 * 60 * 60  =>  'month',
                          24 * 60 * 60  =>  'day',
                               60 * 60  =>  'hour',
                                    60  =>  'minute',
                                     1  =>  'second'
                    );
        $a_plural = array( 'year'   => 'years',
                           'month'  => 'months',
                           'day'    => 'days',
                           'hour'   => 'hours',
                           'minute' => 'minutes',
                           'second' => 'seconds'
                    );
        foreach ($a as $secs => $str)
        {
            $d = $etime / $secs;
            if ($d >= 1)
            {
                $r = round($d);
                return $r . ' ' . ($r > 1 ? $a_plural[$str] : $str) . ' ago';
            }
        }
    }
}

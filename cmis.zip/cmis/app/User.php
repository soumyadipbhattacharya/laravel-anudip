<?php

namespace App;

use Illuminate\Foundation\Auth\User as Authenticatable;
use DB;
use Auth;

class User extends Authenticatable
{
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'name', 'email', 'password',
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'password', 'remember_token',
    ];

    public function accessAM(){

        $roles = DB::table('users_roles')
                    ->leftJoin('roles','roles.id','=','users_roles.role_id')
                    ->where('user_id', Auth::user()->id)
                    ->get(['roles.name']);

        //dd($roles);

        foreach ($roles as $role) {
            $r = $role->name;

            if($r == 'area_manager'){
                
                return true;
            }
            
        }       
            return false;
    }

    public function accessCM(){

        $roles = DB::table('users_roles')
                    ->leftJoin('roles','roles.id','=','users_roles.role_id')
                    ->where('user_id', Auth::user()->id)
                    ->get(['roles.name']);

        //dd($roles);

        foreach ($roles as $role) {
            $r = $role->name;

            if($r == 'center_manager'){
                
                return true;
            }
            
        }       
            return false;
    }

    public function accessCounselor(){

        $roles = DB::table('users_roles')
                    ->leftJoin('roles','roles.id','=','users_roles.role_id')
                    ->where('user_id', Auth::user()->id)
                    ->get(['roles.name']);

        //dd($roles);

        foreach ($roles as $role) {
            $r = $role->name;

            if($r == 'counselor'){
                
                return true;
            }
            
        }       
            return false;
    }

    public function accessMO(){

        $roles = DB::table('users_roles')
                    ->leftJoin('roles','roles.id','=','users_roles.role_id')
                    ->where('user_id', Auth::user()->id)
                    ->get(['roles.name']);

        //dd($roles);

        foreach ($roles as $role) {
            $r = $role->name;

            if($r == 'mob_officer'){
                
                return true;
            }
            
        }       
            return false;
    }

    public function accessPM(){

        $roles = DB::table('users_roles')
                    ->leftJoin('roles','roles.id','=','users_roles.role_id')
                    ->where('user_id', Auth::user()->id)
                    ->get(['roles.name']);

        //dd($roles);

        foreach ($roles as $role) {
            $r = $role->name;

            if($r == 'program_manager'){
                
                return true;
            }
            
        }       
            return false;
    }

    public function accessTrainer(){

        $roles = DB::table('users_roles')
                    ->leftJoin('roles','roles.id','=','users_roles.role_id')
                    ->where('user_id', Auth::user()->id)
                    ->get(['roles.name']);

        //dd($roles);

        foreach ($roles as $role) {
            $r = $role->name;

            if($r == 'trainer'){
                
                return true;
            }
            
        }       
            return false;
    }
}

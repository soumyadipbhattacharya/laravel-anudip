<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the controller to call when that URI is requested.
|
*/

/*Cron Routes */
#Route::get('/cron/mail/welcome', ['as' => 'cronJob', 'uses' => 'CronUtilityController@welcomeMail']);
Route::get('/cron/mail/report', ['as' => 'cronJob', 'uses' => 'CronUtilityController@mailReport']);
#Route::get('/cron/mail/error', ['as' => 'cronJob', 'uses' => 'CronUtilityController@errorReporting']);

//dropin
Route::get('/', ['as' => 'dropin', 'uses' => 'WelcomeController@index']);

//middleware->auth
Route::group(['middleware' => ['auth']], function () {

	Route::get('/u/0/account', ['as' => 'auth.account', 'uses' => 'UserController@index']);
	Route::get('logout', ['as' => 'auth.logout', 'uses' => 'Auth\AuthController@logout']);
	
	//to dashboard
	Route::get('/u/0/home', ['as' => 'dashboard', 'uses' => 'HomeController@index']);

	//password route
	Route::get('/u/0/change/password', ['as' => 'change.password', 'uses' => 'Auth\PasswordController@showChangePasswordForm']);
	Route::post('/u/0/change/password', ['as' => 'change.password.post', 'uses' => 'Auth\PasswordController@postChangePassword']);

	//student releated
	Route::get('/get/u/0/student/new', ['as' => 'student.registration', 'middleware' => 'trainer','uses' => 'StudentController@showStudentRegistrationForm']);
	Route::post('/post/u/0/student/new', ['as' => 'student.registration', 'uses' => 'StudentController@studentRegistration']);
	Route::get('/get/u/0/uploads/new', ['as' => 'student.uploads', 'uses' => 'StudentController@showUploadsForm']);
	Route::get('/get/u/0/fees/new/{id?}', ['as' => 'student.fees', 'uses' => 'StudentController@showFeesForm']);
	Route::get('/get/u/0/student/view/{param?}/{token?}', ['as' => 'student.view', 'uses' => 'StudentController@showStudentDetails']);
	Route::post('/post/u/0/fees/new', ['as' => 'student.fees', 'uses' => 'StudentController@studentFeesCollection']);	
	Route::get('get/u/0/search/keyword/getlists', ['as' => 'autocomplete.search', 'uses' => 'UtilityController@getSearchLists']);
	Route::get('get/u/0/search/keyword/getmemberlist', ['uses' => 'RelocationController@getmemberlist']);
	Route::get('get/u/0/search/keyword/getMemberRoles', ['uses' => 'RelocationController@getMemberRoles']);
	Route::get('get/u/0/search/keyword/getProgramListByCenter', ['uses' => 'RelocationController@getProgramListByCenter']);
	Route::get('get/u/0/search/keyword/getCenterListByProgram', ['uses' => 'RelocationController@getCenterListByProgram']);
	Route::get('get/u/0/search/keyword/getstudentlist', ['as' => 'autocomplete.student.search', 'uses' => 'StudentController@getStudentList']);
	Route::get('get/u/0/getDocumentList', ['as' => 'autocomplete.student.search', 'uses' => 'StudentController@getDocumentList']);
	
	//files upload
	Route::post('/post/u/0/return/files', ['as' => 'student.files', 'uses' => 'FileController@getStudentFilesList']);
	
	//batch releated
	Route::get('/get/u/0/batch/new', ['as' => 'batch.new', 'uses' => 'BatchController@index']);
	Route::get('/get/u/0/batch/view', ['as' => 'batch.view', 'uses' => 'BatchController@showBatchesList']);
	Route::get('get/u/0/batch/enrollment/{token?}', ['as' => 'batch.enrollment', 'uses' => 'BatchController@batchEnrollmentDetails']);
	Route::get('/get/u/0/batch/enrollment', ['as' => 'batch.enrollment', 'uses' => 'BatchController@batchEnrollmentDetails']);
	Route::get('get/u/0/dependent/dropdown/list', ['as' => 'batch.dependency', 'uses' => 'BatchController@getDependencyList']);
	Route::get('/get/u/0/batch/schedule', ['as' => 'batch.schedule', 'uses' => 'BatchController@showBatchScheduleForm']);
	Route::post('/post/u/0/batch/schedule', ['as' => 'batch.schedule', 'uses' => 'BatchController@startBatch']);
	Route::post('post/u/0/batch/savedaytime', ['as' => 'batch.schedule', 'uses' => 'BatchController@saveBatchDateTime']);
	Route::post('post/u/0/batch/deletedaytime', ['as' => 'batch.schedule', 'uses' => 'BatchController@deleteSheduledBatch']);
	Route::post('/post/u/0/batch/enrollment', ['as' => 'batch.post', 'uses' => 'BatchController@saveBatchEnrollmentDetails']);
	Route::post('/post/u/0/batch/new', ['as' => 'batch.post', 'uses' => 'BatchController@saveBatchDetails']);
	Route::get('/get/u/0/batch/showEnrolledStudentList', ['as' => 'batch.post', 'uses' => 'BatchController@showEnrolledStudentList']);
	Route::get('/get/u/0/batch/getBatchDayTime', ['as' => 'batch.post', 'uses' => 'BatchController@getBatchDayTime']);

	//Attendance related
	Route::get('/get/u/0/attendance/new', ['as' => 'attendance.new', 'uses' => 'AttendanceController@showAttendanceform']);
	Route::get('/get/u/0/attendance/getBatchStudents', ['as' => 'attendance.new', 'uses' => 'AttendanceController@getBatchStudents']);
	Route::post('/post/u/0/attendance/saveAttendance', ['as' => 'attendance.new', 'uses' => 'AttendanceController@saveAttendance']);
	
	// //Human Resource Movement
	// Route::get('/get/u/0/relocation/assignUser', ['as' => 'relocation.assignUser', 'uses' => 'RelocationController@userRoles']);
	// Route::post('post/u/0/save/role', ['uses' => 'RelocationController@assignUserRole']);
	// Route::post('post/u/0/remove/role', ['uses' => 'RelocationController@removeUserRole']);


	// //Promotion
	// Route::get('/get/u/0/promotion/assignUser', ['as' => 'promotion.assignUser', 'uses' => 'RelocationController@userRolesForPromotion']);
});

Route::get('login', ['as' => 'auth.login', 'uses' => 'Auth\AuthController@showLoginForm']);
Route::post('login', ['as' => 'auth.login', 'uses' => 'Auth\AuthController@login']);

// Registration Routes...
Route::get('register', ['as' => 'auth.register', 'uses' => 'Auth\AuthController@showRegistrationForm']);
Route::post('register', ['as' => 'auth.register', 'uses' => 'Auth\AuthController@register']);

// Password Reset Routes for email...
Route::get('password/reset/{token?}', ['as' => 'auth.password.reset', 'uses' => 'Auth\PasswordController@showResetForm']);
Route::post('password/email', ['as' => 'auth.password.email', 'uses' => 'Auth\PasswordController@sendResetLinkEmail']);

Route::post('/password/reset', ['as' => 'auth.password.reset', 'uses' => 'Auth\PasswordController@reset']);
Route::post('/password/reset/post', ['as' => 'auth.password.reset', 'uses' => 'Auth\PasswordController@getResetType']);

Route::post('/password/reset/otp', ['as' => 'auth.password.reset.change', 'uses' => 'Auth\PasswordController@resetPasswordByOTP']);

Route::get('/password/reset/otp/{token}/{mobile}', ['as' => 'auth.password.reset.otp', 'uses' => 'Auth\PasswordController@showResetOTP']);

//Other routes
Route::get('support', ['as' => 'get.support', 'uses' => 'UtilityController@index']);

Route::post('support', ['as' => 'post.support', 'uses' => 'UtilityController@support']);
Route::get('about/team', ['as' => 'about.team', 'uses' => 'WelcomeController@aboutTeam']);

Route::get('attendance/add',function(){return View::make('attendance.add'); });

Route::post('/post/u/0/attendance/new', ['as' => 'attendance.new', 'uses' => 'BatchController@saveBatchDetails']);

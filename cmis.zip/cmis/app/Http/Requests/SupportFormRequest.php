<?php

namespace App\Http\Requests;

use App\Http\Requests\Request;
use Auth;
class SupportFormRequest extends Request
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {

        if (Auth::check()){
            return [
            //
            'desc' => 'required|min:5|max:500',
             
            'title' => 'required'
            ];
        }
        else{
            return [
            'desc' => 'required|min:5|max:500',
            'email' => 'required|email',
            'title' => 'required',
            'fname' => 'required',
            'g-recaptcha-response' => 'required|captcha'
            ];
        }
    }

    public function messages()
    {
        if (Auth::check()){
            return [
                'desc.required' => 'Description field required',
                'title.required' => 'Problem Title field required'
            ];
        }
        else{
            return [
                'title.required' => 'Problem Title field required',
                'fname.required' => 'Your Name is required',
                'g-recaptcha-response.required' => 'Recaptcha required',
                'desc.required' => 'Description field required',
                'email.required' => 'Valid Email Address is required'
            ];
        }
    }
}

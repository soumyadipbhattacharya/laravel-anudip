<?php

namespace App\Http\Requests;
use Auth;
use App\Http\Requests\Request;

class ResetOTPPasswordFormRequest extends Request
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules(){

        return [
            //
            'otp'=> 'required|min:5|max:5',
            'password' => 'required|min:6|confirmed',
            'otp_token' => 'required',
            'encode_mobile' => 'required'

        ];
    }
    
    public function messages()
    {
        return [
            'otp.required' => "Not a valid OTP format",
            'password.required' => "Password field not valid",
            'otp_token' => "Invalid OTP",
            'encode_mobile' => "Invalid Mobile",
            'password_confirmation.required' => "Password mismatched"
        ];
    }
}

<?php

namespace App\Http\Requests;
use Auth;
use App\Http\Requests\Request;

class ResetPasswordFormRequest extends Request
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules(){

        return [
            //
            'email'=> 'required_if:reset_type,1|email',
            'mobile'=> 'required_if:reset_type,0|digits:10',
            'g-recaptcha-response' => 'required|captcha'
        ];
    }
	
	public function messages()
	{
	    return [
	        'email.required_if' => "Email requires to send reset link",
	        'mobile.required_if' => "Invalid Mobile No. format",
            'g-recaptcha-response.required' => 'You failed to prove humanity'
	    ];
	}
}

<?php

namespace App\Http\Requests;

use App\Http\Requests\Request;

class StudentRegistrationFormRequest extends Request
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        //Custom validation check
        $marital_status = Request::get('marital_status');
        $gender_status = Request::get('gender');
        $flag = FALSE;
        $value = "";
        if($marital_status == "married" && $gender_status == "female"){
            $flag = TRUE;
        }
        if($flag){
            $value = "required";
        }

        return [
            //
            'centre_code' => 'required',
            'first_name' => 'required|Min:1|Max:20',
            'last_name' => 'required|Min:1|Max:20',
            'dob' => 'required',
            'doc_type' => 'required',
            'identity_no' => 'required',
            'disability_desc' => 'required_if:disability_status,on',
            'religion' => 'required',
            'contact_no' => 'required|digits:10|numeric',
            'alt_contact_no' => 'digits:10|numeric',
            'email_id' => 'email',
            'l_pincode' => 'required',
            'l_police_station' => 'required',
            'l_address' =>'required',
            'p_address' =>'required_if:clone_address,off',
            'language' =>'required',
            'highest_qualification' =>'required',
            'current_monthly_earning' =>'required_if:occupation_status,on',
            'employment_type' =>'required_if:occupation_status,on',
            'technical_knowledge' =>'required_if:can_operate_computer,on',
            'father_name' =>'required',
            'father_occupation' =>'required',
            'mother_name' =>'required',
            'mother_occupation' =>'required',
            'bpl_card_no'=>'required_if:eco_status,on',
            'family_monthly_earning' => 'required',
            'no_of_members' => 'required|min:1',
            'no_of_earning_members' => 'required',
            'come_to_know' => 'required',
            'livelihood_preference' => 'required',
            'referral_name' =>'required_if:come_to_know,Other Reference',
            'referral_id'=> 'required_if:come_to_know,Anudip Student',
        ];
    }
    public function messages()
    {
        return [ 
            'centre_code.required' => 'Please choose your center',
            'first_name.required' => 'Please mention student firstname',
            'last_name.required' => 'Please mention student lastname',
            'dob.required' => 'Please specify date of birth of student',
            'doc_type.required' => 'Please select Id proof type given by student',
            'identity_no.required' => 'Please mention Id proof no',
            'disability_desc.required_if' => 'Please give detail on disability',
            'religion.required' => 'Please select student religion',
            'contact_no.required' => 'Please enter students contact number',
            'l_pincode.required' => 'please enter a valid pincode',
            'l_police_station.required' => 'Please enter nearest police station',
            'l_address.required' =>'Please fillup students address',
            'p_address.required_if' => 'Please fillup students permanent address',
            'language.required' => 'Please Select languages known',
            'highest_qualification.required' => 'Please select highest qualification',
            'current_monthly_earning.required_if' => 'Please select your monthly income',
            'employment_type.required_if' => 'Please select employment type',
            'technical_knowledge.required_if' => 'Please fillup skills',
            'father_name.required' => 'Please mention fathers name',
            'father_occupation.required' => 'Please select fathers occupation',
            'mother_name.required' => 'Please mention mothers name',
            'mother_occupation.required' => 'Please mention mothers occupation ',
            'bpl_card_no.required_if' => 'Please fillup BPL card number',
            'family_monthly_earning.required' => 'Please Select family monthly income',
            'no_of_members.required' => 'Please give number of family members',
            'no_of_earning_members.required' => 'Please give number of earning members',
            'come_to_know.required' => 'Please select how you came to know',
            'livelihood_preference.required' => 'Please select livelihood preference',
            'referral_name.required_if' =>'Please give referral name',
            'referral_id.required_if'=> 'Please fillup referral ID',


        ];
    }
}

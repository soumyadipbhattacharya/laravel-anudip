<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Auth;
use DB;
use Input;
use Validator;
use Session;
use Redirect;
use Response;
use App\Http\Requests;
use App\Http\Controllers\Auth\AuthController;

class RelocationController extends Controller
{
	
	public function __construct()
	{
	   $this->middleware('auth');
	   $this->user_id = Auth::user()->id;
	   $this->curr_timestamp = strtotime(date("Y-m-d H:i:s"));
	}
  
	/**
     * Show attendance form
     *
     * @return view
     */
	public function userRoles(){
		// $get_batches = DB::table('batches')
						// ->where('status','running')
						// ->get(['id','batch_code','center_id','status']);
		// $get_centers = (new StudentController)->getCenters();
		
		$get_program_list = DB::table('programs as p')
			->where('status',1)
			->orderBy('name','asc')
		  	->get(['p.id', 'p.name', 'p.program_code']);
			
		$get_centers = DB::table('centers')
		  	->orderBy('short_code','asc')
			->where('status',1)
		  	->get(['short_code','id']);
			
		$get_roles = DB::table('roles')
			->where('status',1)
		  	->get(['id','name','description','types']);
			
		return view('relocation.assignUser', compact('get_centers','get_program_list', 'get_roles'));
	}

	public function userRolesForPromotion(){
		$get_centers = DB::table('centers')
		  	->orderBy('short_code','asc')
			->where('status',1)
		  	->get(['short_code','id']);
		
		$get_roles = DB::table('roles')
			->where('status',1)
		  	->get(['id','name','description','types']);
		return view('promotion.assignUser', compact('get_centers', 'get_roles'));
	}
	
	    /**
	* Show All Member list - ajax request for Relocation
	*
	* @return view
	*/
	public function getmemberlist(){
	  	$st_id = Input::get('st_id');
	  	$keyword = Input::get('keyword');
	  	$type = Input::get('type');
	  	$getMemberLists = array();
		$getMemberLists = DB::table('members as m')
			->leftJoin('file_uploads_tr as ft','ft.member_id','=','m.id')
			->leftJoin('users as u','u.member_id','=','m.id')
			->where('m.type',$type)
			->where('m.member_code', 'like', $keyword.'%')
			->where('ft.file_upload_id','1')
    		->where('ft.status',TRUE)
			->take(5)
			->get(['m.member_code','m.id','m.first_name','m.last_name', 'm.email_id', 'm.mobile_no', 'ft.data','u.id as user_id']);
	  	return Response::json($getMemberLists);
	}
	
	/**
	* Show Member Roles - ajax request for Relocation
	*
	* @return view
	*/
	public function getMemberRoles(){
	  	$member_id = Input::get('member_id');
	  	$getMemberRoles = array();
		$getMemberRoles = DB::table('users as u')
			->leftJoin('users_roles as ur','ur.user_id','=','u.id')
			->leftJoin('centers as c','c.id','=','ur.center_id')
			->leftJoin('roles as r','r.id','=','ur.role_id')
			->leftJoin('programs as p','p.id','=','ur.program_id')
			->where('u.member_id',$member_id)
			->where('ur.status','1')
			->get(['u.member_id', 'u.id', 'ur.role_id', 'r.name', 'c.short_code', 'ur.created_at', 'ur.user_id', 'p.name as program_name', 'p.id as prog_id','ur.center_id']);		
	  	return Response::json($getMemberRoles);
	}
	
	/**
	* Show Program List by Center - ajax request for Relocation
	*
	* @return view
	*/
	public function getProgramListByCenter(){
	  	$center_id = Input::get('center_id');
	  	$getProgramList = array();
		$getProgramList = DB::table('programs_centers as pc')
			->leftJoin('programs as p','p.id','=','pc.program_id')
			->where('pc.center_id',$center_id)
			->where('pc.status','1')
			->where('p.status','1')
			->get(['p.id', 'p.name', 'p.program_code']);		
	  	return Response::json($getProgramList);
	}

	/**
	* Show Center List by Program - ajax request for Relocation
	*
	* @return view
	*/
	public function getCenterListByProgram(){
	  	$program_id = Input::get('program_id');
	  	$getCenterList = array();
		$getCenterList = DB::table('programs_centers as pc')
			->leftJoin('centers as c','c.id','=','pc.center_id')
			->where('pc.program_id',$program_id)
			->where('pc.status','1')
			->where('c.status','1')
			->get(['c.short_code','c.id']);		
	  	return Response::json($getCenterList);
	}
	
	/**
	* Assign USer role - ajax request for Relocation
	*
	* @return view
	*/
	public function assignUserRole(Request $request){
	  	$center_ids = $request->input('center_ids');
		$role_id = $request->input('role_id');
		$program_id = $request->input('program_id');
		$start_date = $request->input('from_date');
		$from_date = date('Y-m-d', strtotime($start_date));
		if($program_id == ''){
			$response = "noProgram";
			return Response::json($response);
		}if(count($center_ids) == 0){
			$response = "noCenter";
			return Response::json($response);
		}if($role_id == ''){
			$response = "noRole";
			return Response::json($response);
		}else{
		  	$user_id = $request->input('user_id');
				try{
					foreach($center_ids as $key){
						$getUser = array();
						$getUser = DB::table('users_roles')
								  ->leftJoin('roles','roles.id','=','users_roles.role_id')
								  ->where('users_roles.center_id',$key)
								  ->where('users_roles.user_id',$user_id)
								  ->where('users_roles.program_id',$program_id)
								  ->where('users_roles.role_id',$role_id)
								  ->get(['roles.name', 'users_roles.id', 'users_roles.status']);
						if(count($getUser)>0){
							$getRoleStatus = $getUser[0]->status;
						}else{
							$getRoleStatus = 1;
							$successCenterArray = array();
							$successCenterArray[] = $key;
							session()->forget('success_center_list');					
							session()->put('success_center_list', $successCenterArray);
							// session()->put('success_assigned_role', $getUser[0]->name);
						}  
						if(count($getUser)>0 && $getRoleStatus == '1'){
							$errCenterArray = array();
							$errCenterArray[] = $key;
							session()->forget('error_center_list');				
							session()->put('error_center_list', $errCenterArray);
							session()->put('error_assigned_role', $getUser[0]->name);
						}
						// if(count($getUser)>0 && $getRoleStatus == '0'){
							// $status = DB::table('users_roles')
				            // ->where('center_id', $center_id)
				            // ->where('user_id', $user_id)
				            // ->where('role_id', $role_id)
				            // ->where('program_id', $key)
				            // ->update(['status' => '1', 'updated_at' => date("Y-m-d  h:i:s")]);
						// }
						
						if(count($getUser) == 0 && $getRoleStatus ==1){  
					        $resultGetId = DB::table('users_roles')->insertGetId(
						        array(
						          'center_id' => $key,
						          'user_id' => $user_id,
						          'role_id' => $role_id,
						          'program_id' => $program_id,
						          'start_date' => $from_date,
								  'end_date' => '',
						          'status' => 1,
						          'created_by' => $this->user_id
						          )
					        );
						}
			        }
			        $status = TRUE;
		      }	
		      catch(\Exception $e){
		        $status = FALSE;
		      }
		  $getMemberRoles = array();
		  $getMemberRoles = DB::table('users as u')
				->leftJoin('users_roles as ur','ur.user_id','=','u.id')
				->leftJoin('centers as c','c.id','=','ur.center_id')
				->leftJoin('roles as r','r.id','=','ur.role_id')
				->leftJoin('programs as p','p.id','=','ur.program_id')
				->where('u.id',$user_id)
				->where('ur.status','1')
				->get(['u.member_id', 'u.id', 'ur.role_id', 'r.name', 'c.short_code', 'ur.created_at', 'ur.user_id', 'p.name as program_name','p.id as prog_id', 'ur.center_id']);	
				
		  return Response::json($getMemberRoles);
	  }
	}
	
	/**
	* Remove User from the list- ajax request for Relocation
	*
	* @return view
	*/
	public function removeUserRole(Request $request){
	  	$center_id = $request->input('center_id');
		$user_id = $request->input('user_id');
	  	$role_id = $request->input('role_id');
	  	$program_id = $request->input('program_id');
		$status = DB::table('users_roles')
            ->where('center_id', $center_id)
            ->where('user_id', $user_id)
            ->where('role_id', $role_id)
            ->where('program_id', $program_id)
            ->update(['status' => '0', 'updated_at' => date("Y-m-d  h:i:s")]);
			if($status){
				$getMemberRoles = array();
			  	$getMemberRoles = DB::table('users as u')
					->leftJoin('users_roles as ur','ur.user_id','=','u.id')
					->leftJoin('centers as c','c.id','=','ur.center_id')
					->leftJoin('roles as r','r.id','=','ur.role_id')
					->leftJoin('programs as p','p.id','=','ur.program_id')
					->where('u.id',$user_id)
					->where('ur.status','1')
					->get(['u.member_id', 'u.id', 'ur.role_id', 'r.name', 'c.short_code', 'ur.created_at', 'ur.user_id', 'p.name as program_name','p.id as prog_id', 'ur.center_id']);	
			   return Response::json($getMemberRoles);		
			}
					
	}
}

<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\Http\Requests;
use Auth;
class WelcomeController extends Controller
{
	
    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */

    public function index()
    {
        if (Auth::check()){
            return redirect('/u/0/account');
        }
        else{
            return view('auth.login');
        }
    }

    public function aboutTeam(){

        return view('team');
    }
}

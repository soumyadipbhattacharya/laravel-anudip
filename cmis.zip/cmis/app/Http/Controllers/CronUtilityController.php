<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\Http\Requests;
use DB;
use Input;
use Redirect;
use Jenssegers\Agent\Agent;
use Mail;
use Vsmoraes\Pdf\Pdf;
use Excel;
use App\Http\Controllers\UtilityController;

class CronUtilityController extends Controller
{
    /**
     * Cron job to send reset password link
     *
     * @param  int  $id
     * @return Response
    */
    
    private $pdf;
	
	public function __construct(Pdf $pdf)
    {
        $this->pdf = $pdf;
    }
	
    public function passwordReminder(){
    	
    	$getUser = DB::table("users as u")
						->where('u.password','')
						->leftJoin('members as m','u.member_id','=','m.id')
						->get(['m.first_name','u.email','u.user_id']);
						
		$count = sizeof($getUser);
		foreach($getUser as $key=>$value){
			$data = [
				'first_name' => $value->first_name,
				'email_id' => $value->email,
				'user_id' => $value->user_id,
				'time' => date('Y-m-d H:i:s')
			];
			Mail::send('auth.emails.cronemailresetpassword', $data, function($message) use ($data){
			    $message->from('no-reply@anudip.org', 'Anudip Foundation');                  
				$message->to($data['email_id'])->subject('CMIS - Password Reminder');
			});
		}
		return redirect()->to('/');
    }
	
	
	/**
     * Cron job to send reset password link
     *
     * @param  int  $id
     * @return Response
    */
    public function welcomeMail(){
    	
    	$getUser = DB::table("users as u")
						->where('u.password','')
						->leftJoin('members as m','u.member_id','=','m.id')
						->leftJoin('password_resets_trans as prt', 'u.id','=','prt.user_id')
						->get(['m.first_name','m.last_name','u.email','u.user_id','prt.token','prt.expires_at','u.mobile']);
						
		$count = sizeof($getUser);
		foreach($getUser as $key=>$value){
			$data = [
				'first_name' => $value->first_name,
				'last_name' => $value->last_name,
				'email_id' => $value->email,
				'token' => $value->token,
				'mobile' => $value->mobile,
				'expires_at' => $value->expires_at,
				'user_id' => $value->user_id,
				'time' => date('Y-m-d H:i:s')
			];
			Mail::send('auth.emails.welcomemail', $data, function($message) use ($data){
			    $message->from('no-reply@anudip.org', 'Anudip Foundation');                  
				$message->to($data['email_id'])->subject('[CMIS2] - Welcome to CMIS 2');
			});
		}
		return redirect()->to('/');
    }
	
	
	
	/**
     * Setting up cron utility for sms
     *
     * @param  int  $id
     * @return Response
    */
    public function smsCronJob(){
 
    }
	
	/**
     * Setting up cron utility for sms
     *
     * @param  int  $id
     * @return Response
    */
    public function errorReporting(){
 		$getUser = DB::table("users as u")
						//->where('u.email','tamaghna@anudip.org')
						->leftJoin('members as m','u.member_id','=','m.id')
						->get(['m.first_name','m.last_name','u.email']);
						
		$count = sizeof($getUser);
		foreach($getUser as $key=>$value){
			$data = [
				'first_name' => $value->first_name,
				'last_name' => $value->last_name,
				'email_id' => $value->email,
				'time' => date('Y-m-d H:i:s')
			];
			Mail::send('auth.emails.error', $data, function($message) use ($data){
			    $message->from('no-reply@anudip.org', 'Anudip Foundation');                  
				$message->to($data['email_id'])->subject('[CMIS2] - Domain Relocation');
			});
		}
		return redirect()->to('/');
    }

	  /**
	  * Mail Report Send - Center Wise
	  *
	  * @return view
	  */
	  public function mailReport(){
	    $start_date = "2016-09-01";
		$end_date = date("Y-m-d");
	    $sql = 'CALL fetch_center_wise_daily_report("'.$start_date.'","'.$end_date.'")';
	    $getReport = (new UtilityController)->patchForPDO($sql);
		
		//pdf report build and export-save	
		$html = view('auth.emails.report')
					->with('start', $start_date)
					->with('end', $end_date)
					->with('report', $getReport)
					->render();
					
		$this->pdf->load($html);
		$this->pdf->setPaper('A4','landscape');
		$label = $this->pdf->output();
		file_put_contents(public_path()."/resources/report/pdf/CWR-".date("Y-m-d").".pdf",$label);
		$pdf_url = url("/resources/report/pdf/CWR-".date("Y-m-d").".pdf");	
		//return $this->pdf->load($html)->download();

		//excel report build and export-save
		Excel::create('CWR-'.date("Y-m-d"), function($excel) use ($start_date,$end_date,$getReport) {
    		$excel->sheet('CWR-1', function($sheet) use ($start_date,$end_date,$getReport) {
				$sheet->setFontFamily('Comic Sans MS');
				// Set font with ->setStyle()`
				$sheet->setStyle(array(
				    'font' => array(
				        'name'      =>  'Calibri',
				        'size'      =>  12
				    )
				));	
				// Set top, right, bottom, left
				$sheet->setPageMargin(array(
				    0.25, 0.30, 0.25, 0.30
				));
				
				// Set all margins
				$sheet->setPageMargin(0.25);
				$sheet->loadView('auth.emails.report')
						->with('start',$start_date)
						->with('end',$end_date)
                        ->with('report',$getReport);
				 $sheet->setOrientation('landscape');
    		});
		})->store('xls', public_path('/resources/report/sheets'));
		$xl_url = url("/resources/report/sheets/CWR-".date("Y-m-d").".xls");	
		
		$get_users = DB::table("cron_users as cu")->get();
		$count = sizeof($get_users);
		foreach($get_users as $key=>$value){			
			$data = [
					'name' => $value->name,
					'email' => $value->email,
					'report' => $getReport,
					'start' => $start_date,
					'end' => $end_date,
					'pdf_url' => $pdf_url,
					'xl_url' => $xl_url
			];
		Mail::send('auth.emails.mailcronreport', $data, function($message) use ($data){
			$message->attach($data['pdf_url']);	
			$message->attach($data['xl_url']);
			$message->from('no-reply@anudip.org', 'Anudip Foundation');                  
			$message->to($data['email'])->subject("[CMIS2] - Center Wise Daily Statistics - ".date("F j, Y",strtotime($data['end'])));
		});		
	}
	return redirect()->to('/login');
	}
}

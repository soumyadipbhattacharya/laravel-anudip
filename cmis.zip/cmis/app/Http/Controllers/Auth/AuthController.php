<?php

namespace App\Http\Controllers\Auth;

use App\User;
use Validator;
use Auth;
use DB;
use Session;
use Redirect;
use App\Http\Controllers\Controller;
use Illuminate\Foundation\Auth\ThrottlesLogins;
use Illuminate\Foundation\Auth\AuthenticatesAndRegistersUsers;

class AuthController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Registration & Login Controller
    |--------------------------------------------------------------------------
    |
    | This controller handles the registration of new users, as well as the
    | authentication of existing users. By default, this controller uses
    | a simple trait to add these behaviors. Why don't you explore it?
    |
    */

    use AuthenticatesAndRegistersUsers, ThrottlesLogins;

    /**
     * Where to redirect users after login / registration.
     *
     * @var string
     */
    protected $redirectTo = '/u/0/home';
	protected $username = 'user_id';

    /**
     * Create a new authentication controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware($this->guestMiddleware(), ['except' => 'logout']);
        if (\Auth::check())
        {
        	$this->user_id = Auth::user()->id;
			$this->timestamp = date("Y-m-d H:i:s");
            return redirect()->intended('/u/0/home');
        }
    }

    /**
     * Get a validator for an incoming registration request.
     *
     * @param  array  $data
     * @return \Illuminate\Contracts\Validation\Validator
     */
    protected function validator(array $data)
    {
        return Validator::make($data, [
            'name' => 'required|max:255',
            'email' => 'required|email|max:255|unique:users',
            'password' => 'required|min:6|confirmed',
        ]);
    }

    /**
     * Create a new user instance after a valid registration.
     *
     * @param  array  $data
     * @return User
     */
    protected function create(array $data)
    {
        return User::create([
            'name' => $data['name'],
            'email' => $data['email'],
            'password' => bcrypt($data['password']),
        ]);
    }
	
	/**
     * Destroy All session data on logoff.
     *
     * @param  array  $data
     * @return User
     */
	protected function logout(){
		DB::table('event_logs')
		->where('event_table_name', 'users')
		->where('event_status', 'FALSE')
		->where('event_action', 'select')
		->where('event_tr_id', $this->user_id)
		->where('created_by', $this->user_id)
		->update(['event_status' => TRUE, 'updated_at' => $this->timestamp]);
        Auth::logout();
        Session::flush();
        return Redirect::to('/');
    }

	/* Overriding default login form display */
	protected function showLoginForm(){
		return Redirect::to('/');
	}
	
	public function getCredentials($request)
    {
        $credentials = $request->only($this->loginUsername(), 'password');
        return array_add($credentials, 'status', '1');
    }
}

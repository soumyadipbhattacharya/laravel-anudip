<?php

namespace App\Http\Controllers\Auth;
use Illuminate\Http\Request;
use DB;
use Illuminate\Support\Facades\Input;
use Jenssegers\Agent\Agent;
use Password;
use Auth;
use Hash;
use Mail;
use App\Http\Controllers\Controller;
use Illuminate\Foundation\Auth\ThrottlesLogins;
use Illuminate\Foundation\Auth\AuthenticatesAndRegistersUsers;
use Illuminate\Foundation\Auth\ResetsPasswords;
use App\Http\Requests\ResetPasswordFormRequest;
use App\Http\Requests\ResetOTPPasswordFormRequest;
use App\Http\Requests\ResetEmailPasswordFormRequest;
use App\Http\Requests\ChangePasswordFormRequest;
use App\Http\Controllers\UtilityController;
class PasswordController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Password Reset Controller
    |--------------------------------------------------------------------------
    |
    | This controller is responsible for handling password reset requests
    | and uses a simple trait to include this behavior. You're free to
    | explore this trait and override any methods you wish to tweak.
    |
    */

    use ResetsPasswords;
	//send to this when reset password
   	
   	protected $redirectTo = '/u/0/home';
   	protected $loginPath = '/';
   	

    /**
     * Create a new password controller instance.
     *
     * @return void
     */
     
    private $device,$platform,$browser;
	
    public function __construct()
    {
        $this->middleware('guest', ['except' => 'getLogout']);
		if(Auth::check()){
			$this->user_id = Auth::user()->id;
		}
		else{
			$this->user_id="";
		}
		$this->curr_timestamp = strtotime(date("Y-m-d H:i:s"));
		$agent = new Agent();
		//getting client info
		$this->device = $agent->device();
		$this->platform = $agent->platform();
		$this->browser = $agent->browser();
    }
	
	/**
     * Check reset type of requested user
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
	protected function getResetType(ResetPasswordFormRequest $request){
		
		//initializing agent object
		$client_ip = base64_decode($request->input('client_ip'));
		
		//checking reset type(boolean)
		$reset_type_value = $request->input('reset_type');
		$otp = "";
		$getToken = "";
		$api_response_code = "";
		
		//Get date & time,expiry time
			if($reset_type_value){
				$reset_input_value = $request->input('email');
				$date = strtotime("+1 day", $this->curr_timestamp);
				$expiry_date = date('Y-m-d H:i:s',$date);
				$user_id = DB::table('users')->where('email',$reset_input_value)->value('id');
				if(is_null($user_id)){
					return redirect('/password/reset')->withErrors("This email address doesn't match our records.");
				}
				else {
					$reset_type = "Email";
					$getToken = str_random(200);
				}
			}
			else {
				$reset_input_value = $request->input('mobile');
				$user_id = DB::table('users')->where('mobile',$reset_input_value)->value('id');
				if(is_null($user_id)){
					return redirect('/password/reset')->withErrors("This mobile number doesn't match our records.");
				}
				else {
					$date = strtotime("+30 minutes", $this->curr_timestamp);
					$expiry_date = date('Y-m-d H:i:s',$date);
					$reset_type = "Mobile";
					$getToken = uniqid().uniqid();
					$encode_mobile = base64_encode($reset_input_value);
					
					//generating otp
					$otp = substr(uniqid(), 4, -4);
					$full_name = DB::table('users')->where('mobile',$reset_input_value)->value('name');
					$url = url('/password/reset/otp/'.$getToken.'/'.$encode_mobile);
					
					$json_response = PasswordController::sendOtpDetails($url,$otp,$reset_input_value,$full_name,$expiry_date);
					$api_response = json_decode($json_response, true);
					$api_response_status = $api_response['status'];
					if($api_response_status == "success"){
						$api_response_code = 'success';
					}else{
						$api_response_code = $api_response['errors'][0]['code'];
					}
				}
			}
			try {
				//Saving reset password transaction
				DB::enableQueryLog();
				$resultGetId = DB::table('password_resets_trans')->insertGetId(
						array(
								'user_id' => $user_id, 
								'status' => FALSE,
								'token' => $getToken,
								'type' => $reset_type,
								'platform' => $this->device,
								'device' => $this->device,
								'response' => $api_response_code,
								'browser' => $this->browser,
								'otp' => $otp,
								'ip_address' => $client_ip,
								'updated_at' => date('Y-m-d H:i:s'),
								'expires_at' => $expiry_date
						)
					);
					
					//$result = $resultGetId->toSql();
					$flag = TRUE;
			    }
				catch(\Exception $e){
					$flag = FALSE; 
				}
				$event_name = "Reset Password Request";
				$event_action = "insert";
				$event_details = DB::getQueryLog();
				$event_status = $flag;
				$event_table = "password_resets_trans";
				DB::disableQueryLog();
				
				(new UtilityController)->saveEventLogs($event_name,$event_action,$event_details[0]['query'],$event_status,$resultGetId,$event_table);
				
				if($flag){
					$get_member_info = DB::table('members as m')
									 ->where('u.id',$user_id)
									 ->leftJoin('users as u','u.member_id','=','m.id')
									 ->get(['u.email','m.first_name']);
					
					$data = [
						    'email' => $get_member_info[0]->email,
						    'token' => $getToken,
						    'first_name' => $get_member_info[0]->first_name,
						    'time' => date('Y-m-d H:i:s')
					];
					Mail::send('auth.emails.password', $data, function($message) use ($data){
			             $message->from('no-reply@anudip.org', 'Anudip Foundation');                  
						 $message->to(trim($data['email']))->subject('CMIS - Password Reset Assistance');
					});
			}
		
			if($reset_type_value && $reset_type == "Email" && $flag){
				return redirect('/')->with('success',"A reset link on it's way to your mailbox.");
			}
			else{
				if($api_response_code == "success"){
					//redirecting upon user reset type
					if(!$reset_type_value && !is_null($api_response_code)){
						return redirect('/password/reset/otp/'.$getToken.'/'.$encode_mobile)->with('success',"An OTP code is sent to your mobile..");
					}
					else{
						return redirect('/')->with("danger","Look like some ugly things happend. Try again later");
					}
				}
				else{
					return redirect('/')->with("danger","We are unable to send OTP to your mobile at this time. Please try after a while.");
				}
			}
		}
	
	/**
     * Reset/Change password through OTP Confirmation
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
    */
	protected function resetPasswordByOTP(ResetOTPPasswordFormRequest $request){
		
		$token = $request->input('otp_token');
		$encode_mobile = $request->input('encode_mobile');
		$mobile = base64_decode($encode_mobile);
		$otp = $request->input('otp');
		$password = bcrypt($request->input('password'));
		$user_details = DB::table('users')->where('mobile',$mobile)->get(['name','email','id']);
		$objtoArray = (array)$user_details;
		if(empty($objtoArray)){
			return redirect('/')->with("danger","System problem detected. Try again later");
		}
		else{
			$expiry_at = DB::table('password_resets_trans')
			->where('token',$token)
			->where('otp',$otp)
			->where('response','success')
			->where('status',FALSE)
			->value('expires_at');
			if(is_null($expiry_at)){
				return redirect('/password/reset/otp/'.$token.'/'.$encode_mobile)->with("danger","OTP invalid for this mobile no.");
			}
			else{
				$expiry_at = strtotime($expiry_at);
				$this->curr_timestamp = strtotime(date("Y-m-d H:i:s"));
				//checking if OTP not expired
				if($expiry_at >= $this->curr_timestamp){
					try {
						DB::enableQueryLog();
						DB::table('users')
			            ->where('id', $user_details[0]->id)
						->where('mobile', $mobile)
			            ->update(['password' => $password]);
						$event_details_users = DB::getQueryLog();
						DB::disableQueryLog();
						$event_name = "Reset Password via Mobile OTP";
						$event_action = "Update";
						$event_status = $flag;
						$event_table = "users";
						(new UtilityController)->saveEventLogs($event_name,$event_action,$event_details[0]['query'],$event_status,$resultGetId,$event_table);
						
						
						DB::enableQueryLog();
						DB::table('password_resets_trans')
			            ->where('id', $user_details[0]->id)
						->where('type',"Mobile")
						->where('status', FALSE)
			            ->update(['status' => TRUE,'updated_at'=>date('Y-m-d H:i:s')]);
						$event_details_password_reset_trans = DB::getQueryLog();
						DB::disableQueryLog();
						$event_name = "Reset Password via OTP";
						$event_action = "update";
						$event_status = $flag;
						$event_table = "password_resets_trans";
						(new UtilityController)->saveEventLogs($event_name,$event_action,$event_details[0]['query'],$event_status,$resultGetId,$event_table);
						
						$flag = TRUE;
			    	}
					catch(\Exception $e){
						$flag = FALSE; 
					}
					if($flag){
						$data = [
						        'name' => $user_details[0]->name,
						        'email' => $user_details[0]->email,
						        'browser' => $this->browser,
						        'platform' => $this->platform,
						        'time' => date('Y-m-d H:i:s')
						];
						Mail::send('auth.emails.success', $data, function($message) use ($data){
			                $message->from('no-reply@anudip.org', 'Anudip Foundation');                  
						    $message->to(trim($data['email']))->cc('tech-team@anudip.org')->subject('CMIS - Successful Password Reset');
						});
						return redirect('/')->with('success',"Password changed successfully.Get started.");
					}
					else{
						return redirect('/password/reset/otp/'.$token.'/'.$encode_mobile)->with("danger","Look like some ugly things happend. Try again later");
					}
				}
				else{
					try {
						DB::enableQueryLog();
						DB::table('password_resets_trans')
			            ->where('token', $token)
						->where('user_id',$user_details[0]->id)
						->where('otp', $otp)
			            ->update(['status' => 2,'updated_at'=>date('Y-m-d H:i:s')]);
						$flag = TRUE;
						$event_details = DB::getQueryLog();
						$event_name = "Reset Password - OTP";
						$event_action = "update";
						$event_details = DB::getQueryLog();
						$event_status = $flag;
						$event_table = "password_resets_trans";
						DB::disableQueryLog();
						(new UtilityController)->saveEventLogs($event_name,$event_action,$event_details[0]['query'],$event_status,$resultGetId,$event_table);
			    	}
					catch(\Exception $e){
						$flag = FALSE; 
					}
					if($flag){
						return redirect('/password/reset/otp/'.$token.'/'.$encode_mobile)->with("danger","OTP expired for this mobile. Reset again");
					}
					else{
						return redirect('/')->with("danger","Some unusual things happened with the system. Try again later");
					}
				}
			}
		}
	}
	
	/**
     * Show reset form through OTP
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
    */
	protected function showResetOTP($getToken,$encode_mobile){
		
		if(is_null($getToken) || is_null($encode_mobile)){
			return redirect('/password/reset')->with("danger","Look like some ugly things happend. Try again later");
		}
		else{
			return view('auth.passwords.otp',compact('getToken','encode_mobile'));
		}
	}
		
	//Send OTP and return response
	protected function sendOtpDetails($url,$otp,$reset_input_value,$full_name,$expiry_date){
		
		//SMS API Configure(from .env)
		$username = config('app.sms_auth');
		$hash = config('app.sms_key');
		
		//Message details
		$numbers = array($reset_input_value);
		$sender = urlencode('TXTLCL');
		$message = rawurlencode('Hi '.$full_name.',Enter OTP '.$otp.' to reset password. This OTP will expire on '.$expiry_date.'. You can reset from here '.$url); 
		$numbers = implode(',', $numbers);
	 
		//Prepare data for POST request
		$data = array('username' => $username, 'hash' => $hash, 'url' => $url, 'numbers' => $numbers, "sender" => $sender, "message" => $message);
	 
		//Send the POST request through cURL
		$ch = curl_init('http://api.textlocal.in/send/');
		curl_setopt($ch, CURLOPT_POST, true);
		curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		$response = curl_exec($ch);
		curl_close($ch);
		
		//Returning response
		return $response;
	}
	
	/**
     * Overriding Email Subject
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
    */
	protected function getEmailSubject()
    {
        return isset($this->subject) ? $this->subject : 'CMIS Password Reset Assistance';
    }
	
	/**
     * Change password form - Show/GET
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
    */
	protected function showChangePasswordForm(){
		return view('auth.passwords.change_password');
	}
	
	/**
     * Change password form - Post
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
    */
    protected function postChangePassword(ChangePasswordFormRequest $request){
    	
		$user = Auth::user();
		$current_password = Input::get('current_password');
		$password = bcrypt(Input::get('password'));
		
		$user_count = DB::table('users')->where('id',$this->user_id)->count();
		
		if (Hash::check($current_password, $user->password) && $user_count == 1) {
			$user->password = $password;
			try {
				DB::enableQueryLog();
				$user->save();
				$flag = TRUE;
				$event_details = "";
				$event_name = "Change Password";
				$event_action = "update";
				$event_status = $flag;
				$event_table = "users";
				DB::disableQueryLog();
				$resultGetId = $this->user_id;
				(new UtilityController)->saveEventLogs($event_name,$event_action,$event_details,$event_status,$resultGetId,$event_table);
			}
			catch(\Exception $e){
				$flag = FALSE;
			}
			if($flag){
				return redirect('/u/0/home')->with('success',"Password changed successfully.");
			}
			else{
				return redirect('/logout')->with("danger","Unable to process request this time. Try again.");
			}
		}
		else{
			return redirect('/u/0/change/password')->with("warning","Your current password do not match our record");
		}
    }
	
	/**
     * Email Notification & Update status TRUE
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
    */ 
    protected function reset(ResetEmailPasswordFormRequest $request){
    	$email = Input::get('email');
		$token = Input::get('token');
		$password = bcrypt(Input::get('password'));
		
		//get user id & name
		$user_details = DB::table('users')->where('email',$email)->get(['id']);
		$objtoArray = (array)$user_details;
		if(empty($objtoArray)){
			return redirect('/')->with("danger","System problem detected. Try again later");
		}
		else{
			//checking expiry time
			$expiry_time = DB::table('password_resets_trans')
						   ->where('token',$token)
						   ->where('user_id',$user_details[0]->id)
						   ->where('status',FALSE)
						   ->value('expires_at');
			if(is_null($expiry_time)){
				return redirect('/')->with("warning","This reset link has expired or invalid credentials. Try Reset Again.");
			}
			else{
				$expiry_timestamp = strtotime($expiry_time);
				if($expiry_timestamp < $this->curr_timestamp){
					try {
						DB::enableQueryLog();
						DB::table('password_resets_trans')
				            ->where('token', $token)
							->where('user_id', $user_details[0]->id)
							->where('type','Email')
				            ->update(['status' => 2,'updated_at'=>date('Y-m-d H:i:s')]);
							$flag = TRUE;
						
						$resultGetId = DB::table('password_resets_trans')
				            ->where('token', $token)
							->where('user_id', $user_details[0]->id)
							->where('type','Email')
				            ->value('id');
							
						$event_details = DB::getQueryLog();
						DB::disableQueryLog();
						$event_name = "Invalid/Expired Token Access";	
						$event_action = "Update";
						$event_status = $flag;
						$event_table = "password_resets_trans";	
						(new UtilityController)->saveEventLogs($event_name,$event_action,$event_details[0]['query'],$event_status,$resultGetId,$event_table);
				    }
					catch(\Exception $e){
						$flag = FALSE; 
					}
					if(!$flag){
						return redirect('/')->with("danger","System problem detected. Try again later");
					}
					return redirect('/')->with("warning","This reset link has expired and not valid. Try Reset Again.");
				}
				else{
					try {
							DB::enableQueryLog();
							DB::table('users')
				            ->where('id', $user_details[0]->id)
							->where('email', $email)
				            ->update(['password' => $password]);
							$flag = TRUE;
							
							$event_details = DB::getQueryLog();
							DB::disableQueryLog();
							$event_name = "Password Reset Action";	
							$event_action = "Update";
							$event_status = $flag;
							$event_table = "users";
							$resultGetId = $user_details[0]->id;	
							(new UtilityController)->saveEventLogs($event_name,$event_action,$event_details[0]['query'],$event_status,$resultGetId,$event_table);
						
							
							DB::table('password_resets_trans')
				            ->where('user_id', $user_details[0]->id)
							->where('type',"Email")
							->where('token',$token)
							->where('status', FALSE)
				            ->update(['status' => TRUE]);
							
							DB::enableQueryLog();
							$result_Id = DB::table('password_resets_trans')
							            ->where('user_id', $user_details[0]->id)
										->where('type',"Email")
										->where('token',$token)
										->where('status', TRUE)
										->value('id');
							$flag = TRUE;
							$resultGetId = $result_Id;
							$event_details = DB::getQueryLog();
							DB::disableQueryLog();
							$event_name = "Password Reset Action";	
							$event_action = "Update";
							$event_status = $flag;
							$event_table = "password_resets_trans";	
							(new UtilityController)->saveEventLogs($event_name,$event_action,$event_details[0]['query'],$event_status,$resultGetId,$event_table);
						
				    	}
						catch(\Exception $e){
							$flag = FALSE; 
						}
					if(!$flag){
						return redirect('/')->with("danger","System problem detected. Try again later");
					}
					else{
						$get_member_info = DB::table('members as m')
										->where('u.id',$user_details[0]->id)
										->leftJoin('users as u','m.id','=','u.member_id')
										->value('m.first_name');
						$data = [
						           'first_name' => $get_member_info,
						           'email' => $email,
						           'browser' => $this->browser,
						           'platform' => $this->platform,
						           'time' => date('Y-m-d H:i:s')
						];
						Mail::send('auth.emails.success', $data, function($message) use ($data){
			                $message->from('no-reply@anudip.org', 'Anudip Foundation');                  
						    $message->to(trim($data['email']))->cc('tech-team@anudip.org')->subject('CMIS - Successful Password Reset');
						});
						return redirect('/')->with('success',"Password changed successfully. Get Stareted");
					}
				}
			}
	    }
    }
}

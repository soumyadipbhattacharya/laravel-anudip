<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Auth;
use DB;
use Input;
use Validator;
use Session;
use Response;
use Jenssegers\Agent\Agent;
use Mail;
use Redirect;
use App\Http\Requests;
use App\Http\Controllers\Auth\AuthController;
use App\Http\Requests\SupportFormRequest;
class UtilityController extends Controller
{
    //
    public function __construct()
    {
    	$agent = new Agent();
    	if(Auth::user()){
    		$this->middleware('auth');
			$this->user_id = Auth::user()->id;
		}
		else{
			$this->user_id = "";
		}
		$this->device = $agent->device();
		$this->platform = $agent->platform();
		$this->browser = $agent->browser();
		$this->curr_timestamp = strtotime(date("Y-m-d H:i:s"));
    }

    /**
     * Get pincodes list
     *
     * @param  int  $id
     * @return Response
    */
    public function getSearchLists(){
    	$keyword = Input::get('keyword');
		$type = Input::get('type');
		$getLists = array();
		if($type == "directory"){
			$getLists = DB::table('directory_lists')
	                      ->where('pincode', 'like', $keyword.'%')
	                	  ->get(['pincode','id','division_name','officename']);
		}
    	return Response::json($getLists);
    }
	
	/**
     * Get Language list
     *
     * @param  int  $id
     * @return Response
    */
    
    public function getLanguageList(){
    	$languageList = DB::table("languages")
						->where('status',TRUE)
						->get(['id','short_name','icon']);
		return $languageList;	
    }
	
	
	
	/**
     * Support page view
     *
     * @param  int  $id
     * @return Response
    */
    public function index()
    {
        return view('support');
    }

    
    /**
     * Saving event log details
     *
     * @param  int  $id
     * @return Response
    */
    public function saveEventLogs($name,$action,$details,$status,$id,$table){
		DB::table('event_logs')->insert(
			[   
				'ip' => getenv('REMOTE_ADDR'),
				'event_name' => $name,
				'event_action' => $action,
				'event_details' => $details,
				'event_status' => $status,
				'event_tr_id' => $id,
				'event_table_name' => $table,
				'browser' => $this->browser,
				'device' => $this->device,
				'platform' => $this->platform,
				'created_by' => $this->user_id,
				'created_at' => date("Y-m-d H:i:s"),
				'updated_at' => date("Y-m-d H:i:s")
			]);
    }
    
    public function support(SupportFormRequest $request){

        $ticket = "CMISTKT".strtoupper(uniqid());
        $file = array('image' => Input::file('image'));
        $size = filesize(Input::file('image'));
        if (Auth::user()) { 
            $get_details = DB::table('users')
                            ->leftJoin('members','users.member_id','=','members.id')
                            ->where('users.id',Auth::user()->id)
                            ->get(['first_name','last_name','email_id']);
            if(!empty($get_details)){

                $full_name = $get_details[0]->first_name.' '.$get_details[0]->last_name;
                $email = $get_details[0]->email_id;
            }
            else{
                return redirect()->back()->with("danger","Some problem occurred. Try Again...");
            }
        }
        else{
            $full_name = trim($request->input('fname'));
            $email = trim($request->input('email'));
        }
        
        $title = trim($request->input('title'));
        $desc = trim($request->input('desc'));
        $rules = array('image' => 'required'); 
        //$validator = Validator::make($file, $rules);

        $data = array('full_name'=>$full_name,'email'=>$email, 'time'=> date("Y-m-d H:i:s"),'ticket'=>$ticket);
        if($size > 2097152){
            if ($validator->fails() && !is_null($file['image'])) {
                return Redirect::to('reach-us')->withInput()->withErrors($validator);
            }
            else{
                return Redirect::to('reach-us')->with('filesizeerror','Uploaded file size more than 2MB');
            }
        }
        else {
            $path = '';
            if (!is_null($file['image']) && Input::file('image')->isValid()) {
                $destinationPath = 'resources/support';
                $extension = Input::file('image')->getClientOriginalExtension();
                $fileName = $ticket.'.'.$extension; 
                Input::file('image')->move($destinationPath, $fileName);
                $dbImagePath = $destinationPath.'/'.$fileName;
                $path = $dbImagePath;
            }
            try {
            	DB::enableQueryLog();
            	$resultGetId =  DB::table('supports')->insertGetId(
            	array(
                        'email' => $email, 
                        'full_name' => $full_name,
                        'description'=>$desc,
                        'file'=>$path,
                        'ticket'=>$ticket
                    )
				);
                $status = TRUE;
            }
            catch(\Exception $e){
                $status = FALSE; 
            }
			
			$event_name = "Support Request";
			$event_action = "insert";
			$event_details = DB::getQueryLog();
			$event_status = $status;
			$event_table = "supports";
			DB::disableQueryLog();
				
			UtilityController::saveEventLogs($event_name,$event_action,$event_details[0]['query'],$event_status,$resultGetId,$event_table);
			
            if($status == TRUE){
                
                Mail::send('auth.emails.support', $data, function($message) use ($data){
                    $message->from('info@anudip.org', 'Anudip Foundation');                    
                    $message->to($data['email'], $data['full_name'])->subject('CMIS Support Acknowledgement');
                });
                
                return redirect()->back()->with("success","Your support request is processed successfully with ticket no.".$ticket);
            }
            else {
                return redirect()->back()->with("danger","We can't process your request now. Try later.");
            }
        }
    }

    public function patchForPDO($sql){

        $pdo = new \PDO("mysql:host=".config('app.db_host').";dbname=".config('app.db_name'), config('app.db_user'),config('app.db_pwd'));
        $q = $pdo->query($sql);
        $q->setFetchMode(\PDO::FETCH_ASSOC);
        $get_pdo_results = $q->fetchAll();
        return $get_pdo_results;
    }

}

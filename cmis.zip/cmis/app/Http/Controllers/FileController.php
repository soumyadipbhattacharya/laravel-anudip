<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use Auth;
use DB;
use Validator;
use Input;
use Redirect;
use File;
use App\Http\Requests;
use Session;
use App\Http\Controllers\UtilityController;
class FileController extends Controller
{
    //
    public function __construct()
    {
    	$this->middleware('auth');
		$this->user_id = Auth::user()->id;
		$this->curr_timestamp = strtotime(date("Y-m-d H:i:s"));
    }
	
	/**
     * Get file meta data.
     *
     * @return Request
     */
	public function getFileMetaData(){
		$filesinfo = DB::table("file_uploads")
					->where('status',TRUE)
					->get();
		return $filesinfo;
	}
	
	/**
     * Get file count
     *
     * @return Request
     */
	public function getFileCount(){
		$filescount = DB::table("file_uploads")
					->where('status',TRUE)
					->where('required',TRUE)
					->count('id');
		return $filescount;
	}
	
		/**
     * Show file list of specified student
     *
     * @return view
     */
    public function getStudentFilesList(Request $request){

    	$rules['image'] = 'mimes:jpg,png,gif,svg,jpeg';
    	$this->validate($request, [
	        'student_registration' => 'required',
    	]);
		$member_id = $request->input('student_registration');
		$member_code = DB::table('members as m')
						->leftJoin('admissions as a','m.id','=','a.member_id')
						->where('m.id',$member_id)
						->value('m.member_code','m.disability_status','a.eco_status');
						
		$doc_type_id = $request->input('doc_type');
		$description = $request->input('description');

		if(is_null($member_id)){
			return Redirect::back()->with("danger","No data found relevant to your search");
		}
		else{

			$files = Input::file('change_lmx_u750_document_upload');
			$file_count = count($files);
			
			// start count how many uploaded
	    	$uploadcount = 0;
			foreach($files as $file) {
				if(is_null($file)){
					return Redirect::back()->with("danger","You have missed to upload file :)");
				}
				if($doc_type_id == 1){
					$rules = array('file' => 'mimes:jpeg,bmp,png,svg,gif');
				}
				else{		
					$rules = array('file' => 'mimes:jpeg,bmp,png,pdf'); //'required|mimes:png,gif,jpeg,txt,pdf,doc'
				}
				$validator = Validator::make(array('file'=> $file), $rules);
				if($validator->passes()){
			        	$filename = $file->getClientOriginalName();
						$filename = $file->getClientOriginalName();
						$file_ext = substr($filename, strripos($filename, '.')); // get file extention
						$filename = $member_code.$filename.'@'.'-'.strtotime(date("Y-m-d H:i:s"));
						$destinationPath = "uploads/documents/".$member_code;

						$filename = base64_encode($filename);
						$file_get_path = $destinationPath.'/'.$filename;
						
						if($doc_type_id == 1){
							try {
								
									DB::table('file_uploads_tr')
							            ->where('member_id', $member_id)
										->where('file_upload_id', $doc_type_id)
							            ->update(['status' => FALSE]);
									
									//Saving file upload transaction
									DB::enableQueryLog();
			  						$insertDocId = DB::table('file_uploads_tr')->insertGetId(
				  					array(
										'member_id' => $member_id, 
										'approval' => FALSE,
										'details' => $description,
										'extension' => $file_ext,
										'data' => $file_get_path,
										'file_upload_id' => $doc_type_id,
										'created_by' => $this->user_id,
										'status' => TRUE
									));
									$flag = TRUE;
							    }
								catch(\Exception $e){
									$flag = FALSE; 
								}
							  
							  $event_name = "Student File Upload";
					          $event_action = "insert";
					          $event_details = DB::getQueryLog();
					          $event_status = $flag;
					          $event_table = "file_uploads_tr";
					          DB::disableQueryLog();
					          (new UtilityController)->saveEventLogs($event_name,$event_action,$event_details[0]['query'],$event_status,$insertDocId,$event_table);
								
						}
						else{
						      try {
						        //Saving file upload transaction
									DB::enableQueryLog();
			  						$insertDocId = DB::table('file_uploads_tr')->insertGetId(
				  					array(
										'member_id' => $member_id, 
										'approval' => FALSE,
										'details' => $description,
										'extension' => $file_ext,
										'data' => $file_get_path,
										'file_upload_id' => $doc_type_id,
										'created_by' => $this->user_id,
										'status' => TRUE
									));
									$flag = TRUE;
							    }
								catch(\Exception $e){
									$flag = FALSE; 
								}
							  
							  $event_name = "Student File Upload";
					          $event_action = "insert";
					          $event_details = DB::getQueryLog();
					          $event_status = $flag;
					          $event_table = "file_uploads_tr";
					          DB::disableQueryLog();
					          (new UtilityController)->saveEventLogs($event_name,$event_action,$event_details[0]['query'],$event_status,$insertDocId,$event_table);
							
							}
							if($flag){
									$upload_success = $file->move($destinationPath, $filename);
							        $uploadcount ++;
							}
							else{
								return redirect()->action('StudentController@showUploadsForm')->with("danger","Look like some ugly things happend. Try again later");
							}
				      	}
						else{
							return redirect()->action('StudentController@showUploadsForm')->withInput()->withErrors($validator);
						}
					}
					if($uploadcount == $file_count && $flag){
						$get_member_file_details = (new StudentController)->getDocumentList($member_id);												
						$check_economy_status = DB::table('admissions')
												->where('member_id',$member_id)
												->value('eco_status');
						
						session()->forget('member_id','member_code','user_details','check_eco_status');					
						session()->put('member_code', $member_code);
						session()->put('member_id', $member_id);
						session()->put('user_details', $get_member_file_details);
						session()->put('check_eco_status', $check_economy_status);
				      	return redirect()->action('StudentController@showUploadsForm')->with("success","File uploaded successfully");
				    }
					else {
		      			return redirect()->action('StudentController@showUploadsForm')->withInput()->withErrors($validator);
		    		}
				}
			}
	}

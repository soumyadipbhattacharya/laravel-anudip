<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Auth;
use DB;
use Input;
use Validator;
use Session;
use Redirect;
use Response;
use App\Http\Requests;
use App\Http\Controllers\Auth\AuthController;

class AttendanceController extends Controller
{
	
	public function __construct()
	{
	   $this->middleware('auth');
	   $this->user_id = Auth::user()->id;
	   $this->curr_timestamp = strtotime(date("Y-m-d H:i:s"));
	}
  
	/**
     * Show attendance form
     *
     * @return view
     */
	public function showAttendanceform(){
		$get_batches = DB::table('batches')
						->where('status','running')
						->get(['id','batch_code','center_id','status']);
		$get_centers = (new StudentController)->getCenters();
		return view('attendance.new',compact('get_batches','get_centers'));
	}
	
    /**
     * Save batch info for attendance
     *
     * @return view
     */
    public function saveAttendance(Request $request){
			
		$inputs = Input::all();
		$rules = [
		      'start_time' => 'required',
		      'end_time' => 'required|after:start_time',
	    ];	
	    $messages = [
	        'start_time.required' => 'Start time required',
	        'end_time.required' => 'End time required',
	        'end_time.after' => 'End time must be ahead of start time',
	     ];	
	    $validator = Validator::make($inputs, $rules, $messages);
	    if ($validator->fails()) {
			return redirect()->back()->withInput()->withErrors($validator)->with("warning","Validation fails, check for missing field.");
	    }
		
    	$batch_code = trim($request->input('batch_id'));
    	$atn_status = trim($request->input('attendance_status'));
    	$student_list = $request->input('student_list');
		$date = date('Y-m-d', strtotime(str_replace('/', '-', trim($request->input('date')))));
    	
       	$start_time = date("H:i:s", strtotime(trim($request->input('start_time'))));
		$end_time = date("H:i:s", strtotime(trim($request->input('end_time'))));
		//checking if date inserted should be less then batch start date and within 30 days 
		$batch_start_date = (new AttendanceController)->getBatchStartDate($batch_code);
		if(count($batch_start_date)>0){
			$batchStartDate = strtotime($batch_start_date[0]->start_date);
			$date30DaysBefore = strtotime(date('Y-m-d', strtotime('-30 days')));
			$attendanceDate = strtotime($date);
			if($attendanceDate >= $batchStartDate AND $attendanceDate >= $date30DaysBefore){
				$dateChecking =  TRUE;
			}else{
				$dateChecking =  FALSE;
				return redirect()->back()->with("warning","Class Date should not be before 30 days and not before Batch Start Date");
			}
		}
		
		if($dateChecking){
			//checking if attendance collected
			DB::enableQueryLog(); 	
	    	$count_records = DB::table('attendances as at')
	                ->where('at.batch_code', $batch_code)
	                ->where('at.date', $date)
					->where(function($q) use ($start_time,$end_time) {
	                	  $q->where(function($query) use ($start_time,$end_time) {
	                        	$query->whereBetween('at.start_time',array($start_time,$end_time))
							  		  ->orWhereBetween('at.end_time',array($start_time,$end_time));
	                    })
	                  ->orWhere(function($query) use ($start_time,$end_time) {
	                       $query->where('at.start_time','<=',$start_time)
						  	  ->where('at.end_time','>=',$end_time);
	                    });
	                })
	                ->count();
			
		    if($count_records >=1){
	    		return redirect()->back()->with('warning',"Attendance for this batch already taken.");
	    	}
			else{
				//dd($student_list);
				if(sizeof($student_list) == 0 || $student_list == "" ){
					return redirect()->back()->with('warning',"Students list not found");
				}
				else{
		    		try{
						DB::enableQueryLog(); 	 
						$last_atn_id = DB::table('attendances')->insertGetId(
							array(
								'batch_code' => trim($request->input('batch_id')),
							    'date' => $date,
							    'start_time' => trim($request->input('start_time')),
							    'end_time' => trim($request->input('end_time')),
							    'created_by' => $this->user_id
								)
							);
						$status = TRUE;
					}
					catch(\Exception $e){
				   		$status = FALSE;
					}
				}
				
				$event_details = DB::getQueryLog();
			    DB::disableQueryLog();
				(new UtilityController)->saveEventLogs("Attendance collected","Insert",$event_details[0]['query'],$status,$last_atn_id,"attendances");
				
				if(!$status){
					return redirect()->back()->with('danger',"Something went wrong. Try again later.");
				}
				else{
					//dd($student_list);
					if(sizeof($student_list) == 0 || $student_list == "" ){
						return redirect()->back()->with('warning',"Students list not found");
					}
					else{
						//dd($student_list);
						foreach ($student_list as $key => $value) {
							try{
								if($value == "off"){
									$value = 0;
								}
								else if($value == "on"){
									$value = 1;
								}
								$last_atntr_id = DB::table('attendance_tr')->insertGetId(
								array(	
										'attandance_id' => $last_atn_id, 
										'member_id' => $key,
										'status' => $value,
										'created_by' => $this->user_id,
										'updated_at' => date("Y-m-d H:i:s")
									)
								);
								$flag = TRUE;
							}
							catch (\Exception $ex) {
								$flag = FALSE;
					       	}
							
							$event_details = DB::getQueryLog();
						    DB::disableQueryLog();
							(new UtilityController)->saveEventLogs("Attendance links Student","Insert",$event_details[0]['query'],$flag,$last_atntr_id,"attendance_tr");
			       		}
						
			       		if(!$flag){
			       			return redirect()->back()->with('danger',"Something went wrong. Try again later.");
			       		}
			       		else{
							return redirect()->back()->with('success',"Attandance for this batch has been recorded successfully");
						}
					}
				}	
			}
		}	
    }

    public function getBatchStudents(){

    	$batch_code = Input::get('batch_code');
    	$get_batch_students = DB::table('enrollments as e')
							->leftJoin('batches as b','b.id','=','e.batch_id')
							->leftJoin('members as m','m.id','=','e.member_id')
							->leftJoin('file_uploads_tr as fut','fut.member_id','=','e.member_id')
							->where('b.id',$batch_code)
							->where('fut.file_upload_id',1)
							->where('fut.status',1)
							->get(['e.member_id as m_id','m.member_code as m_code','m.first_name as fname','m.last_name as lname','fut.data as dp']);

		return Response::json($get_batch_students);
    }
    
	public function getBatchStartDate($batch_code){
    	$get_batch_start_date = DB::table('batches as b')
							->where('b.id',$batch_code)
							->get(['b.start_date']);

		return $get_batch_start_date;
    }
}

<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Auth;
use Response;
use Input;
use Session;
use DB;
use App\Http\Requests;
use App\Http\Controllers\StudentController;
use App\Http\Controllers\Auth\AuthController;
use Validator;

class BatchController extends Controller{
    public function __construct(){
    	$this->middleware('auth');
		$this->user_id = Auth::user()->id;
		$this->curr_timestamp = strtotime(date("Y-m-d H:i:s"));
    }

    /**
     * Show the batch creation view.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(){
  
    	$centers = (new StudentController)->getCenters();
        return view('batch.new',compact('centers'));
    }
	
	/**
     * Show the batches list center wise
     *
     * @return \Illuminate\Http\Response
     */
    public function showBatchesList(){

    	$get_member_id = Session::get('session_m_id');

    	$get_batch_info = DB::select('call fetch_batches('.$get_member_id.')');
		//dd($get_batch_info);
    	$get_batch_count = DB::table('batches as b')
    		->whereIn('ur.user_id', explode(',', $this->user_id))
    		->leftJoin('users_roles as ur','b.center_id','=','ur.center_id')
    		->where('ur.status',1)
    		->count('b.id');

    	$get_batch_count_running = DB::table('batches as b')
						->whereIn('ur.user_id', explode(',', $this->user_id))
						->leftJoin('users_roles as ur','b.center_id','=','ur.center_id')
						->where('ur.status',1)
						->where('b.status', 'running')
						->count('b.id');

	    return view('batch.view',compact('get_batch_info','get_batch_count','get_batch_count_running'));
    }
	
	/**
     * Ajax dependency List
     *
     * @return \Illuminate\Http\Response
     */
    public function getDependencyList(){
    	$value = Input::get('value');
    	$type = Input::get('type');
		$getDependentList = "";
		
		//checking with certain dropdown type id
		if($type == "batchx_center_id"){							  
		/*	$getDependentList = DB::table('users_roles')
							  ->join('programs','users_roles.program_id','=','programs.id')
							  ->where('users_roles.center_id',$value)
							  ->where('users_roles.user_id',Auth::user()->id)
							  ->groupBy('users_roles.program_id')
							  ->get(['programs.id','programs.name']);
		*/

			$getDependentList = DB::table('programs_centers as pc')
								->leftJoin('programs as p','p.id','=','pc.program_id')
								->where('pc.center_id',$value)
								->get(['pc.program_id as id','p.name as name']);

			//dd($getDependentList);
							  
		}

		else if($type == "batchx_program_id"){
			$getDependentList = DB::table('modules')
							  ->where('modules.program_id',$value)
							  ->where('modules.status',1)
							  ->get();
		}
		
		else if($type == "batchx_module_id"){
			$center_id = Input::get('center_id');
			$program_id = Input::get('program_id');
			$getDependentList = DB::table('users')
							  ->join('users_roles as ur','users.id','=','ur.user_id')
							  ->join('members as m','users.member_id','=','m.id')
							  ->where('ur.center_id',$center_id)
							  ->where('ur.program_id',$program_id)
							  ->where('ur.status',1)
							  ->where('ur.role_id',7)
							  ->where('users.status',1)
							  ->groupBy('m.id')
							  ->get(['m.id','m.first_name as name']);
		}
		else if($type == "get_batch_trainer_id"){
			$getDependentList = DB::table('batch_trainers as bt')
						->where('bt.batch_id',$value)
						->leftJoin('members as m','bt.member_id','=','m.id')
						->leftJoin('file_uploads_tr as ft','bt.member_id','=','ft.member_id')
						->where('ft.status',TRUE)
						->get(['m.id','m.first_name','m.last_name','ft.data']);
		}
		
		return Response::json($getDependentList);
    }

	/**
     * Post/Save New Batch
     *
     * @return \Illuminate\Http\Response
     */
    public function saveBatchDetails(Request $request){
    	
		$batch_code = DB::table('batches')
	                     ->orderBy("batches.batch_code","desc")
	                     ->value("batch_code");
	    $batch_code++;

    	if(empty($request->input('batchx_trainer_id')) || empty(trim($request->input('batchx_center_id'))) || empty(trim($request->input('batchx_program_id'))) || empty(trim($request->input('batchx_module_id')))){
    		return redirect()->back()->with("danger","Fields are empty. Resetting form values");		
    	}
		else{
			try{
				DB::enableQueryLog();
				$insertGetBatchId = DB::table('batches')->insertGetId(
					array(
						'batch_code' => trim($batch_code),
						'program_id' => trim($request->input('batchx_program_id')),
						'center_id' => trim($request->input('batchx_center_id')),
						'module_id' => trim($request->input('batchx_module_id')),
						'status' => 'not_started',
						'created_by' => $this->user_id
					)
				);
				$insertGetBatchId1 = $insertGetBatchId;
				$status = TRUE;	
			}
			//exception
	        catch(\Exception $e){
	             $status = FALSE; 
	        }
			
			$event_name = "Batch Starting";
		    $event_action = "insert";
		    $event_details = DB::getQueryLog();
		    $event_status = $status;
		    $event_table = "batches";
		    DB::disableQueryLog();
		    $resultGetId = $insertGetBatchId;
		    (new UtilityController)->saveEventLogs($event_name,$event_action,$event_details[0]['query'],$event_status,$resultGetId,$event_table);
					
			if(!$status){
				return redirect()->back()->with("danger","Something wrong happend. Try again later");
			}
			else{
				foreach($request->input('batchx_trainer_id') as $value){
						try{
							$insertGetBatchId = DB::table('batch_trainers')->insertGetId(
							array(
									'batch_id' => $insertGetBatchId1, 
									'member_id' => $value,
									'description' => $request->input('batchx_description'),
									'status' => 1,
									'created_by' => $this->user_id
							));
							$status = TRUE;	
						}
						catch(\Exception $e){
	             			$status = FALSE; 
	        			}
						$event_name = "Adding Trainers to batch";
					    $event_action = "insert";
					    $event_details = DB::getQueryLog();
					    $event_status = $status;
					    $event_table = "batch_trainers";
					    DB::disableQueryLog();
					    $resultGetId = $insertGetBatchId;
					    (new UtilityController)->saveEventLogs($event_name,$event_action,$event_details[0]['query'],$event_status,$resultGetId,$event_table);
						
					}
					 if(!$status){
					 	return redirect()->back()->with("danger","Something wrong happend. Try again later");
					 }
					 else{
					 	//session()->forget('unique_batch_id');
					 	return redirect()->back()->with("success","Batch Information saved successfully. Please note ".trim($batch_code)." for reference.");
					 }
			}
		}
    }

	/**
     * Show center wise batch
     *
     * @return \Illuminate\Http\Response
     */
    public function batchEnrollmentDetails($token = ""){
    		
    	$batch_id = base64_decode($token);
    	$center_info = DB::table('centers as c')
    				   ->leftJoin('users_roles as ur','c.id','=','ur.center_id')
    				   ->where('ur.status',1)
					   ->where('ur.user_id',$this->user_id)
					   ->groupBy('c.id')
					   ->get(['c.id','c.short_code']);
		
		$batch_info = DB::select('call fetch_enrollable_batches("'.$this->user_id.'")');
		//dd($batch_info);
		$get_valid_students_list = array();
		$get_students_list = array();	
		
		if(!empty($batch_id)){
			$batch_code =  (string) DB::table('batches as b')->where('b.id',$batch_id)->value('batch_code');
			
			$get_enrolled_students_list = (array) DB::table('enrollments as e')
								->where('e.batch_id',$batch_id)
								->where('e.status','enrolled')
								->get(['e.member_id']);
			
			$count_enrolled_students = DB::table('enrollments as e')
								->where('e.batch_id',$batch_id)
								->where('e.status','enrolled')
								->count('e.id');
			
			$sql = 'CALL fetch_valid_student("'.$batch_code.'")';
			$get_valid_students_list = (new UtilityController)->patchForPDO($sql);
			
			//dd($get_valid_students_list);
			foreach($get_valid_students_list as $key=>$val){
				$get_valid_students_list[$key]['name_alias'] = strtoupper(substr($val['t_f_name'],0,1).substr($val['t_l_name'],0,1));
			}

			$get_batch_size = DB::table('modules as m')
								->leftJoin('batches as b','m.id','=','b.module_id')
								->where('b.id',$batch_id)
								->value('m.max_batch_size');				 
		}
	
		$get_students_list = $get_valid_students_list;
		return view('batch.enrollment',compact('center_info','batch_info','batch_id','get_students_list','count_enrolled_students','get_batch_size'));
    }
    
    
	/**
     * Save batch enrollment details
     *
     * @return \Illuminate\Http\Response
     */
	public function saveBatchEnrollmentDetails(Request $request){
			
		$batchid = $request->input('getBatchesList');
		$module_max_size = DB::table('batches as b')
							  ->where('b.id',$batchid)
							  ->leftJoin('modules as m','b.module_id','=','m.id')
							  ->value('m.max_batch_size');
		
		$batch_count_students =  DB::table('enrollments as e')
								->where('e.batch_id',$batchid)
								->count('e.member_id');
		
		$validStudents = $request->input('valid_students');
		if(sizeof($validStudents) == 0 || $batchid == ""){
			return redirect()->back()->with("danger","You have missed to select option. Try Again");
		}
		else if((sizeof($validStudents)+$batch_count_students) > $module_max_size){
			return redirect()->back()->with("warning","You have exceeded maximum limit of enrollment. Try Again");
		}
		else{
			
			foreach ($validStudents as $key => $value) {
				try{
					 try {
						DB::enableQueryLog();
						$insertGetFeesId = DB::table('fees')->insertGetId(
	      					array(	
								'member_id' => $key,
								'amount' => $value,
								'receiving_date' => date('Y-m-d'),
								'type' => 'D',
								'status' => TRUE,
								'received_by' => $this->user_id,
								'created_by' => $this->user_id,
								'updated_at' => date("Y-m-d H:i:s")
							));
							$getFeesLog = DB::getQueryLog();
							DB::disableQueryLog();
							$flag = TRUE;
						}
						catch(Exception $e){
							$flag = FALSE;
						}
						(new UtilityController)->saveEventLogs("Fees Collection","Insert",$getFeesLog[0]['query'],$flag,$insertGetFeesId,"fees");
						
					 try {
					 	 DB::enableQueryLog();
						 $insertGetEnrollmentId = DB::table('enrollments')->insertGetId(
	      					array(
						
								'member_id' => $key, 
								'batch_id' => $batchid,
								'enroll_date' => date('Y-m-d'),
								'created_date' => date('Y-m-d'),
								'status' => 'enrolled',
								'created_by' => $this->user_id,
								'updated_at' => date("Y-m-d H:i:s")
							));
							$getEnrollmentLog = DB::getQueryLog();
							DB::disableQueryLog();
						//	dd($getEnrollmentLog);
							$flag = TRUE;
						} catch(Exception $e){
							$flag = FALSE;
						}
						(new UtilityController)->saveEventLogs("Student Enrollment","Insert",$getEnrollmentLog[0]['query'],$flag,$insertGetEnrollmentId,"enrollments");
						
					}
					catch (\Exception $ex) {
						$flag = FALSE;
						
		       		}
		       		//(new UtilityController)->saveEventLogs("Student Enrollment","Insert",$getEnrollmentLog[0]['query'],$flag,$insertGetEnrollmentId,"enrollments");
					//(new UtilityController)->saveEventLogs("Fees Collection","Insert",$getFeesLog[1]['query'],$flag,$insertGetFeesId,"fees");
					
       			}
			}
			if($flag){
				return redirect()->back()->with("success","Batch enrolled successfully");
			}
			else{
				return redirect()->back()->with("danger","Something wrong happend. Try again later");
			}
		}
	
	
	/**
     * Show center wise batch
     *
     * @return \Illuminate\Http\Response
    */
    public function showBatchScheduleForm(){
    	
		$center_info = DB::table('centers as c')
    				   ->leftJoin('users_roles as ur','c.id','=','ur.center_id')
    				   ->where('ur.status',1)
					   ->where('ur.user_id',$this->user_id)
					   ->groupBy('c.id')
					   ->get(['c.id','c.short_code']);
		/*
		$batch_info = DB::table('batches as b')
							  ->leftJoin('modules as m','b.module_id','=','m.id')
							  ->havingRaw("COUNT(e.member_id) >= 2")
							  ->leftJoin('enrollments as e','b.id','=','e.batch_id')
							  ->leftJoin('users_roles as ur','b.center_id','=','ur.center_id')
							  ->groupBy('e.batch_id')
							  ->get(['b.id as batch_id','b.batch_code','b.center_id','b.module_id']);
		*/

		$batch_info = DB::select('call fetch_startable_batches("'.$this->user_id.'")');
		//dd($batch_info);
		
    	return view('batch.schedule',compact('center_info','batch_info'));
	}

	/**
     * Save batch time and date
     *
     * @return \Illuminate\Http\Response
    */
	public function saveBatchDateTime(Request $request){

		$batch_days = $request->input('batch_days');
		$schedule_start_time = $request->input('start_time');
		$schedule_end_time = $request->input('end_time');

		$get_batch_trainer_id = $request->input('batch_id');
		$show_trainer_id = $request->input('trainer_id');

		foreach ($batch_days as $key => $value) {
				try{
					$insertGetBatchDayId = DB::table('batch_days')->insertGetId(
					array(	
							'batch_trainer_id' => $show_trainer_id, 
							'batch_id' => $get_batch_trainer_id,
							'day' => $value,
							'created_date' => date('Y-m-d'),
							'created_by' => $this->user_id,
							'updated_at' => date("Y-m-d H:i:s")
						)
					);
					
					DB::table("batch_times")->insert(
						[	
							'batch_day_id' => $insertGetBatchDayId,
							'time_from' => $schedule_start_time,
							'time_to' => $schedule_end_time,
							'created_by' => $this->user_id,
							'created_date' => date('Y-m-d'),
							'updated_at' => date("Y-m-d H:i:s")
						]);
						$flag = TRUE;
					}
					catch (\Exception $ex) {
						$flag = FALSE;
		       		}

       		}
		
			$getBatchDayTime = DB::table('batch_days as bd')	
								->leftJoin('batch_times as bt','bt.batch_day_id','=','bd.id')
								->where('bd.batch_id', $get_batch_trainer_id)
								->leftJoin('members as m','m.id','=','bd.batch_trainer_id')
								->get(['bd.id as id','bd.day as day','bt.time_from as t_from',
										'bt.time_to as t_to','m.first_name as fname',
										'm.last_name as lname']);		
			return Response::json($getBatchDayTime);
	}

	/**
     * Get the Batch Day and Time
     *
     * @return \Illuminate\Http\Response
    */
	public function getBatchDayTime(Request $request){
		$batch_id = $request->input('batch_id');
		try{
			$getBatchDayTime = DB::table('batch_days as bd')	
				->leftJoin('batch_times as bt','bt.batch_day_id','=','bd.id')
				->where('bd.batch_id', $batch_id)
				->leftJoin('members as m','m.id','=','bd.batch_trainer_id')
				->get(['bd.id as id','bd.day as day','bt.time_from as t_from',
						'bt.time_to as t_to','m.first_name as fname',
						'm.last_name as lname']);	
			$flag = TRUE;	
		}
		catch (\Exception $ex) {
			$flag = false;
		}
		return Response::json($getBatchDayTime);
	}

	/**
     * Delete Schedule Batch
     *
     * @return \Illuminate\Http\Response
    */
	public function deleteSheduledBatch(Request $request){
		$batch_day_id = $request->input('batch_day_id');
		try{
			DB::table('batch_days')->where('id', $batch_day_id )->delete();
			DB::table('batch_times')->where('batch_day_id', $batch_day_id)->delete();
			$flag = true;
		}
		catch (\Exception $ex) {
			$flag = false;
		}
		return Response::json($flag);
	}

	/**
     * Start A Batch
     *
     * @return \Illuminate\Http\Response
    */
	public function startBatch(Request $request){
		$inputs = Input::all();
		//dd($request->input('start_date'),$request->input('end_date'));
	    // setting up custom error messages for the field validation
	    $rules = [
		      'get_batch_trainer_id' => 'required',
		      'start_date' => 'required|date_format:d/m/Y',
		      'end_date' => 'required|date_format:d/m/Y|after:start_date',
		      'start_time' => 'required',
		      'end_time' => 'required|after:start_time',
	    ];	
	    $messages = [
	     	'get_batch_trainer_id.required' => 'Trainer ID is Required',
	     	'start_date.required' => 'Start Date is Required',
	        'end_date.required' => 'Enter a Valid End Date',
	        'start_time.required' => 'Start Time Required',
	        'end_time.required' => 'End Time Required',
	     ];	
	    $validator = Validator::make($inputs, $rules, $messages);
	    if ($validator->fails()) {
			//return redirect('/get/u/0/batch/schedule')->withInput()->withErrors($validator);
			return redirect()->back()->withInput()->withErrors($validator)->with("warning","Validation fails, check for missing field.");
	    }
	    else {
	    	$s_date = $request->input('start_date');
	    	$e_date = $request->input('end_date');

	    	// $s_date = '11/10/2016';
	    	// $e_date = '15/10/2017';


			$batch_id = trim($request->input('get_batch_trainer_id'));
			$batch_start_date = date('Y-m-d', strtotime($s_date));
			$batch_end_date = date('Y-m-d', strtotime($e_date));
			//dd($s_date."-".$e_date."---".$batch_start_date."-".$batch_end_date);	
			$check_batchtime_exist = DB::table('batch_days as bd')
										->where('bd.batch_id', $batch_id)
										->count('bd.batch_id');
			if($check_batchtime_exist != 0){
				$status = DB::table('batches')
	            	->where('id', $batch_id)
	            	->update(
	            		[
	            			'start_date' => $batch_start_date, 
	            			'end_date' => $batch_end_date,
	            			'status' => 'running',
	            		]
					);
				if($status){
					return redirect()->back()->with("success","Batch started successfully");
				}
				else{
					return redirect()->back()->with("danger","Something wrong happend. Try again later");
				}
			}
	    }		
	}

	/**
     * Show Enrolled Students in batch view
     *
     * @return \Illuminate\Http\Response
    */
	public function showEnrolledStudentList(){
		$b_id = Input::get('batch_id');
		$student_list = DB::table('enrollments as e')
						->where('e.batch_id',$b_id)
						->where('fut.status',TRUE)
						->where('fut.file_upload_id',1)
						->leftJoin('members as m','m.id','=','e.member_id')
						->leftJoin('file_uploads_tr as fut','m.id','=','fut.member_id')
						->leftJoin('batches as b','b.id','=','e.batch_id')
						->get(['b.id','b.batch_code','fut.data','m.middle_name','m.email_id','m.mobile_no','m.member_code','m.first_name','m.last_name']);
		return Response::json($student_list);
	}

}

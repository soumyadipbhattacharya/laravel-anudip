<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Auth;
use DB;
use Input;
use Validator;
use Session;
use Redirect;
use Response;
use App\Http\Requests;
use App\Http\Controllers\Auth\AuthController;
use App\Http\Controllers\UtilityController;
use App\Http\Controllers\FileController;
use App\Http\Requests\StudentRegistrationFormRequest;
use Route;

class StudentController extends Controller
{
  public function __construct()
  {
    $this->middleware('auth');
    $this->user_id = Auth::user()->id;
    $this->curr_timestamp = strtotime(date("Y-m-d H:i:s"));
  }

  /**
  * Show the student registration view.
  *
  * @return view
  */
  public function showStudentRegistrationForm()
  {
    //load utilitycontroller
    $getLanguageList = (new UtilityController)->getLanguageList();
    $centers = StudentController::getCenters();
    $degrees = StudentController::getDegreeList();
    return view('student.new',compact('getLanguageList','centers','degrees'));
  }

  /**
  * Save student registration data.
  *
  * @return \Illuminate\Http\Response
  */
  public function studentRegistration(StudentRegistrationFormRequest $request){

    //getting last member code
    $member_code = DB::table('members')
    ->where('type','student')
    ->orderBy("members.id","desc")
    ->value("member_code");

    //incrementing two times as in CMIS 1.0
    $member_code++;

    //checking if is checked
    if(trim($request->input('clone_address'))){
      $p_address = trim($request->input('l_address'));
    }
    else{
      $p_address = trim($request->input('parm_address'));
    }

    if((int)trim($request->input('no_of_earning_members')) > (int)trim($request->input('no_of_members'))){
      return redirect()->back()->with("errors","Earning members can't be greater than no. family members")->withInput(Input::all());
    }


    //if hidden value is null of pincode
    if(empty(trim($request->input('l_pincode')))){
      return redirect()->back()->with("danger","Pincode is not set. We are resetting values..");
    }
    else{
      $l_pincode = trim($request->input('l_pincode'));
    }

    //query execution to members schema
    try {
      DB::enableQueryLog();
      $insertGetMemberId = DB::table('members')->insertGetId(
      array(
        'member_code' => $member_code,
        'type' => 'student',
        'first_name' => trim($request->input('first_name')),
        'middle_name' => trim($request->input('mid_name')),
        'last_name' => trim($request->input('last_name')),
        'gender' => trim($request->input('gender')),
        'dob' => date('Y-m-d', strtotime(trim($request->input('dob')))),
        'l_address' => trim($request->input('l_address')),
        'l_pincode' => $l_pincode,
        'l_police_station' => trim($request->input('l_police_station')),
        'p_address' => $p_address,
        'mobile_no' => trim($request->input('contact_no')),
        'alt_contact_no' => trim($request->input('alt_contact_no')),
        'landline_no' => trim($request->input('landline_no')),
        'email_id' => trim($request->input('email_id')),
        'marital_status' => trim($request->input('marital_status')),
        'disability_status' => trim($request->input('disability_status')),
        'disability_desc' => trim($request->input('disability_desc')),
        'cast' => trim($request->input('cast')),
        'religion' => trim($request->input('religion')),
        'highest_qualification' => trim($request->input('highest_qualification')),
        'father_name' => trim($request->input('father_name')),
        'father_occupation' => trim($request->input('father_occupation')),
        'mother_name' => trim($request->input('mother_name')),
        'mother_occupation' => trim($request->input('mother_occupation')),
        'husband_name' => trim($request->input('husband_name')),
        'husband_occupation' => trim($request->input('husband_occupation')),
        'updated_at' => date("Y-m-d H:i:s")
        )
      );
      $status = TRUE;
    }
    //exception
    catch(\Exception $e){
      $status = FALSE;
    }

    $event_name = "Student Registation - Step 1";
    $event_action = "insert";
    $event_details = DB::getQueryLog();
    $event_status = $status;
    $event_table = "members";
    DB::disableQueryLog();
    $resultGetId = $insertGetMemberId;
    (new UtilityController)->saveEventLogs($event_name,$event_action,$event_details[0]['query'],$event_status,$resultGetId,$event_table);

    if(!$status){
      return redirect()->back()->with("danger","Some problems occured. Try again later");
    }
    else{
      //query execution to admission schema
      try{
        DB::enableQueryLog();
        $resultGetId = DB::table('admissions')->insertGetId(
        array(
          'member_id' => $insertGetMemberId,
          'center_id' => trim($request->input('centre_code')),
          'doc_type' => trim($request->input('doc_type')),
          'identity_no' => trim($request->input('identity_no')),
          'occupation_status' => trim($request->input('occupation_status')),
          'current_monthly_earning' => trim($request->input('current_monthly_earning')),
          'employment_type' => trim($request->input('employment_type')),
          'no_of_members' => trim($request->input('no_of_members')),
          'no_of_earning_members' => trim($request->input('no_of_earning_members')),
          'family_monthly_earning' => trim($request->input('family_monthly_earning')),
          'can_operate_computer' => trim($request->input('can_operate_computer')),
          'technical_knowledge' => trim($request->input('technical_knowledge')),
          'ready_to_relocate' => trim($request->input('ready_to_relocate')),
          'livelihood_preference' => trim($request->input('livelihood_preference')),
          'eco_status' => trim($request->input('eco_status')),
          'bpl_card_no' => trim($request->input('bpl_card_no')),
          'come_to_know' => trim($request->input('come_to_know')),
          'referral_name' => trim($request->input('referral_name')),
          'referral_id' => trim($request->input('referral_id')),
          'status' => 1,
          'created_by' => $this->user_id
          )
        );
        $status = TRUE;
      }
      catch(\Exception $e){
        $status = FALSE;
      }

      $event_name = "Student Registation - Step 2";
      $event_action = "insert";
      $event_details = DB::getQueryLog();
      $event_status = $status;
      $event_table = "admissions";
      DB::disableQueryLog();
      (new UtilityController)->saveEventLogs($event_name,$event_action,$event_details[0]['query'],$event_status,$resultGetId,$event_table);

      if(!$status){
        return redirect()->back()->with("danger","Some problems occured. Try again later");
      }

      //getting array checkbox values and setting it
      if(!empty($request->input('language'))){
        foreach ($request->input('language') as $key => $value){
          foreach($value as $type=>$val){
            //query execution to language transactions schema
            try{
              DB::enableQueryLog();
              $resultGetId = DB::table('languages_tr')->insertGetId(
              array(
                'created_by' => $this->user_id,
                'status' => FALSE,
                'language_id' => $key,
                'type'=>$val,
                'member_id' => $insertGetMemberId
              )
            );
            $status = TRUE;
          }
          catch(\Exception $e){
            $status = FALSE;
          }

          $event_name = "Student Registation - Step 3";
          $event_action = "insert";
          $event_details = DB::getQueryLog();
          $event_status = $status;
          $event_table = "languages";
          DB::disableQueryLog();
          (new UtilityController)->saveEventLogs($event_name,$event_action,$event_details[0]['query'],$event_status,$resultGetId,$event_table);

          if(!$status){
            return redirect()->back()->with("danger","Some problems occured. Try again later");
          }
          else{
            //query execution to file uploads schema
            try{
              if(trim($request->input('gender')) == "female"){
                $data = 'uploads/documents/default-avatar-female.png';
              }
              else{
                $data = 'uploads/documents/default-avatar.png';
              }

              $resultGetId = DB::table('file_uploads_tr')->insertGetId(
              array(
                'created_by' => 0,
                'data' => $data,
                'member_id' => $insertGetMemberId,
                'file_upload_id' => '1',
                'status' => TRUE
              )
            );
            $status = TRUE;
          }
          catch(\Exception $e){
            $status = FALSE;
          }

          $event_name = "Student Registation - Step 4";
          $event_action = "insert";
          $event_details = DB::getQueryLog();
          $event_status = $status;
          $event_table = "file_uploads_tr";
          DB::disableQueryLog();
          (new UtilityController)->saveEventLogs($event_name,$event_action,$event_details[0]['query'],$event_status,$resultGetId,$event_table);
          if(!$status){
            return redirect()->back()->with('danger',"Something went wrong. Try again later.");
          }
          else{
            return redirect()->back()->with('success',"A new student record is saved with registration no. ".$member_code);
          }
        }
      }
    }
  }
  else{
    return redirect()->back()->with("danger","Language fields are empty. Check at least one");
  }
}
return redirect()->back()->with("danger","Some problems occured. Try again later");
}

/**
* Show the student fees collection view.
*
* @return view
*/
public function showFeesForm( $id="" )
{
  $query_result = array();
  if($id != ""){
  	$get_id = decrypt($id);
  	$query_result = DB::table('members as m')
					  ->where('m.type','student')
					  ->leftJoin('fees as f','m.id','=','f.member_id')
					  ->where('m.id',$get_id)
					  ->where('f.type','C')
					  ->get(['m.id','m.member_code',DB::raw('sum(f.amount) as amount')]);
	if(empty($query_result[0]->amount)){
		$query_result[0]->amount = "0.00";
	}
  }
  return view('student.fees',compact('query_result'));
}


/**
* Show the student fees collection view.
*
* @return view
*/
public function showUploadsForm()
{
  $fileLists = (new FileController)->getFileMetaData();
  $new_users_details = array();	
  $count = 0;
  $flag_file = FALSE;
  
  // dd(session('user_details'));
  if(Session::has('user_details')){
	if(!empty(Session::get('user_details'))){
		
  	}
  }  
   //dd($new_users_details);
  return view('student.uploads',compact('fileLists','flag_file', 'new_users_details','count'));
}

/**
* Saving the student fees.
*
* @return view
*/
public function studentFeesCollection(Request $request){
	  if(empty($request->input('member_code')) || empty(trim($request->input('amount'))) || empty(trim($request->input('receiving_date'))) || empty(trim($request->input('receipt_no'))) || empty($request->input('received_by'))){
	    $status = FALSE;
	  }
	  else{
	  	$member_code = $request->input('member_code');
		$received_by = $request->input('received_by');
	    try{
	    	  DB::enableQueryLog();	
			  $insertGetFeeId = DB::table('fees')->insertGetId(
				  array(
					  'member_id' => $member_code,
					  'amount' => trim($request->input('amount')),
					  'receiving_date' => date('Y-m-d', strtotime(trim($request->input('receiving_date')))),
					  'receipt_no' => trim($request->input('receipt_no')),
					  'pay_method' => "cash",
					  'status' => TRUE,
					  'type' => 'C',
					  'received_by' => $received_by,
					  'created_by' => $this->user_id,
					  'updated_at' => date("Y-m-d H:i:s")
				   )
			);
		  	$status = TRUE;
		}
		catch(\Exception $e){
		  $status = FALSE;
		}
		  $event_name = "Student Fees Collection";
		  $event_action = "insert";
		  $event_details = DB::getQueryLog();
		  $event_status = $status;
		  $event_table = "Fees";
		  (new UtilityController)->saveEventLogs($event_name,$event_action,$event_details[0]['query'],$event_status,$insertGetFeeId,$event_table);
		  DB::disableQueryLog();	
	}
	return Response::json($status);
}

/**
* Show student details
*
* @return view
*/
public function showStudentDetails($param = "")
{
  /*
  $student_details = DB::table('members as m')
  ->where('m.type','student')
  ->where('ft.status',TRUE)
  ->where('ft.file_upload_id','1')
  ->whereIn('ur.user_id', explode(',', $this->user_id))
  ->leftJoin('admissions as a','m.id','=','a.member_id')
  ->leftJoin('users_roles as ur','a.center_id','=','ur.center_id')
  ->where('ur.status',1)
  ->leftJoin('file_uploads_tr as ft', 'm.id', '=', 'ft.member_id')
  ->leftJoin('directory_lists as dl', 'm.l_pincode', '=', 'dl.id')
  ->leftJoin('fees as f','m.id','=','f.member_id')
  ->orderBy("m.id",'desc')
  ->groupBy('m.id')
  ->get(['m.id as member_id','m.*','dl.*','a.center_id','ft.*',DB::raw('SUM(f.amount) as total')]);
  */

  $student_details = DB::select('call fetch_view_students('.$this->user_id.',0)');
  //dd($student_details);

  $student_count = DB::table('members as m')
  ->where('m.type','student')
  ->whereIn('ur.user_id', explode(',', $this->user_id))
  ->leftJoin('admissions as a','m.id','=','a.member_id')
  ->leftJoin('users_roles as ur','a.center_id','=','ur.center_id')
  ->where('ur.status',1)
  ->count('m.id');
  
  $route_url = Route::getCurrentRoute()->getPath();
  
  if( strpos($route_url, "center-summary" ) !== false ) {
  		$route = "center-summary";
  }
  	return view('student.view',compact('student_details','student_count','param','route'));
}

public function getDegreeList(){
  $degrees =  DB::table('degree_level')
              ->orderBy('level_id','asc')
              ->get();
  return $degrees;
}

public function getCenters(){
  $centers =  DB::table('centers')
  ->leftJoin('users_roles', 'centers.id', '=', 'users_roles.center_id')
  ->where('users_roles.user_id','=',$this->user_id)
  ->where('users_roles.status',1)
  ->where('centers.status',1)
  ->orderBy('centers.short_code','asc')
  ->groupBy('centers.id')
  ->get(['centers.short_code','centers.id']);
  return $centers;
}

/**
* Show student list - ajax request
*
* @return view
*/
public function getStudentList(){
  $st_id = Input::get('st_id');
  $keyword = Input::get('keyword');
  $type = Input::get('type');
  $getLists = array();

  if($type=="lists"){
    $getLists = DB::table('members as m')
    ->where('ft.file_upload_id','1')
    ->where('ft.status',TRUE)
    ->where('m.member_code', 'like', $keyword.'%')
    ->leftJoin('admissions as a','m.id','=','a.member_id')
    ->leftJoin('users_roles as ur','a.center_id','=','ur.center_id')
    ->leftJoin('centers as cen','cen.id','=','ur.center_id')
    ->where('ur.status',1)
    ->where('cen.status',1)
    ->where('a.status',1)
    ->whereIn('ur.user_id', explode(',', $this->user_id))
    ->leftJoin('file_uploads_tr as ft','ft.member_id','=','m.id')
    ->groupBy('m.id')
    ->take(5)
    ->get(['ft.data','m.member_code','m.id as member_id','m.first_name','m.last_name']);
  }
  else if($type =="staff"){
    $type = "staff";
    $student_center_id = DB::table('admissions')
    				   ->where('member_id',$st_id)
                       ->value('center_id');
    $getLists = DB::table('users as u')
    ->leftJoin('users_roles as ur','ur.user_id','=','u.id')
	  ->leftJoin('centers as cen','cen.id','=','ur.center_id')
	  ->leftJoin('members as m','m.id','=','u.member_id')
    ->leftJoin('file_uploads_tr as fut','fut.member_id','=','u.member_id')
	  ->where('u.status',1)
    ->where('ur.status',1)  
    ->where('ur.role_id',7)	
    ->where('cen.status',1)
    ->where(function($query) use ($keyword){
            $query->where('m.member_code', 'like', $keyword.'%')
                  ->orWhere('m.first_name','like', $keyword.'%')
                  ->orWhere('m.last_name','like', $keyword.'%');
            })
    ->where('ur.center_id',$student_center_id)
    ->get(['u.id','u.user_id as member_code','u.member_id','m.first_name','m.last_name','ur.center_id','fut.data']);
  }
  else {
    $type="student";
    $getLists = DB::table('members as m')
    ->where('m.type',$type)
    ->where('ft.file_upload_id','1')
    ->where('ft.status',TRUE)
    ->where('m.member_code', 'like', $keyword.'%')
    ->leftJoin('admissions as a','m.id','=','a.member_id')
    ->leftJoin('users_roles as ur','a.center_id','=','ur.center_id')
    ->leftJoin('centers as cen','cen.id','=','ur.center_id')
    ->where('ur.status',1)
    ->where('cen.status',1)
    ->where('a.status',1)
    ->whereIn('ur.user_id', explode(',', $this->user_id))
    ->leftJoin('file_uploads_tr as ft','ft.member_id','=','m.id')
    ->groupBy('m.id')
    ->take(5)
    ->get(['ft.data','m.member_code','m.id','m.first_name','m.last_name']);

    //get total amounts id wise
    $getCAmounts = DB::table('fees')
    ->groupBy('fees.member_id')
	  ->where('fees.type','C')
    ->get(['fees.member_id',DB::raw('SUM(fees.amount) as total_amount')]);

    $getDAmounts = DB::table('fees')
    ->groupBy('fees.member_id')
    ->where('fees.type','D')
    ->get(['fees.member_id',DB::raw('SUM(fees.amount) as total_amount')]);

    //checking if amount exists in key=>value pair
    foreach($getLists as $gLkey=>$gLval){
      foreach($getCAmounts as $gAkey=>$gAval){
        if($gLval->id == $gAval->member_id){
          $gLval->total_Cr_amount = $gAval->total_amount;
        }
      }
    
      foreach($getDAmounts as $gAkey=>$gAval){
        if($gLval->id == $gAval->member_id){
          $gLval->total_Db_amount = $gAval->total_amount;
        }
      }
    }

  }
  return Response::json($getLists);
}

  /**
  * Show uploaded documents list - ajax request
  *
  * @return view
  */
  public function getDocumentList($member_id = ""){
  	if(!empty($member_id)){
  		$m_id = $member_id;
  	}
	else{
		$m_id = Input::get('member_id');
	}
    $sql = 'CALL fetch_file_upload_status("'.$m_id.'")';
    $students_file_upload_status = (new UtilityController)->patchForPDO($sql);
    return $students_file_upload_status;
    // return Response::json($students_file_upload_status);
  }
}

<?php

namespace App\Http\Controllers;

use App\Http\Requests;
use Illuminate\Http\Request;
use Jenssegers\Agent\Agent;
use DB;
use Auth;
use Session;
use App\Http\Controllers\UtilityController;
class HomeController extends Controller {
	/**
	 * Create a new controller instance.
	 *
	 * @return void
	 */
	public function __construct() {
		$agent = new Agent();
		if (Auth::user()) {
			$this -> middleware('auth');
			$this -> user_id = Auth::user() -> id;
		} else {
			$this -> user_id = "";
		}
		$this -> device = $agent -> device();
		$this -> platform = $agent -> platform();
		$this -> browser = $agent -> browser();
		$this -> curr_timestamp = strtotime(date("Y-m-d H:i:s"));
	}

	/**
	 * Show the application dashboard.
	 *
	 * @return \Illuminate\Http\Response
	 */
	public function index() {
		
		if(empty(Session::get('user_id'))){		
			DB::enableQueryLog();
			$event_details = 'collecting user id';
			$event_name = "Authentication Success";
			$event_action = "select";
			$event_status = FALSE;
			$event_table = "users";
			DB::disableQueryLog();
			$resultGetId = $this -> user_id;
			(new UtilityController)->saveEventLogs($event_name,$event_action,$event_details,$event_status,$resultGetId,$event_table);
			session()->put('user_id', $this -> user_id);
		}
		return redirect('/u/0/account');
	}

}

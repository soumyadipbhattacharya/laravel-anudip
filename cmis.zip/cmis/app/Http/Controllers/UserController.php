<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Auth;
use DB;
use Input;
use Validator;
use Session;
use Response;
use Jenssegers\Agent\Agent;
use Mail;
use Redirect;
use App\Http\Requests;

class UserController extends Controller
{
    //
    public function index(){
    	return view('auth.account');
    }
}

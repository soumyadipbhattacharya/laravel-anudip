<?php

// Home
Breadcrumbs::register('dashboard', function($breadcrumbs) {
    $breadcrumbs->push('Dashboard', route('dashboard'));
});

//support
Breadcrumbs::register('get.support', function($breadcrumbs) {
    $breadcrumbs->push('Get Support', route('get.support'));
});

//password change
Breadcrumbs::register('change.password', function($breadcrumbs) {
	$breadcrumbs->parent('dashboard');
	$breadcrumbs->push('Change Password', route('change.password'));
});
Breadcrumbs::register('auth.password.reset', function($breadcrumbs) {
    $breadcrumbs->push('Reset Password', route('auth.password.reset'));
});
Breadcrumbs::register('auth.password.email', function($breadcrumbs) {
    $breadcrumbs->push('Reset Password', route('auth.password.email'));
});
Breadcrumbs::register('auth.password.reset.otp', function($breadcrumbs) {
    $breadcrumbs->push('OTP Confirmation', route('auth.password.reset.otp'));
});

//student registration
Breadcrumbs::register('student.registration', function($breadcrumbs) {
	$breadcrumbs->parent('dashboard');
    $breadcrumbs->push('New Student', route('student.registration'));
});

//student registration upload
Breadcrumbs::register('student.uploads', function($breadcrumbs) {
    $breadcrumbs->parent('dashboard');
    $breadcrumbs->push('Uploads', route('student.uploads'));
});

//student fees
Breadcrumbs::register('student.fees', function($breadcrumbs) {
    $breadcrumbs->parent('dashboard');
    $breadcrumbs->push('Fees', route('student.fees'));
});

//batch creation
Breadcrumbs::register('batch.new', function($breadcrumbs) {
	$breadcrumbs->parent('dashboard');
    $breadcrumbs->push('New Batch', route('batch.new'));
});

//My Account
Breadcrumbs::register('auth.account', function($breadcrumbs) {
	$breadcrumbs->parent('dashboard');
    $breadcrumbs->push('My Account', route('auth.account'));
});

//batch view
Breadcrumbs::register('batch.view', function($breadcrumbs) {
	$breadcrumbs->parent('dashboard');
    $breadcrumbs->push('View Batches', route('batch.view'));
});

//batch enrollment
Breadcrumbs::register('batch.enrollment', function($breadcrumbs) {
	$breadcrumbs->parent('dashboard');
    $breadcrumbs->push('Enrollment', route('batch.enrollment'));
});

//batch enrollment
Breadcrumbs::register('batch.schedule', function($breadcrumbs) {
    $breadcrumbs->parent('dashboard');
    $breadcrumbs->push('Schedule Batch', route('batch.schedule'));
});

//view students
Breadcrumbs::register('student.view', function($breadcrumbs) {
    $breadcrumbs->parent('dashboard');
    $breadcrumbs->push('All Students', route('student.view'));
});

//File Uploads
Breadcrumbs::register('student.files', function($breadcrumbs) {
    $breadcrumbs->parent('dashboard');
    $breadcrumbs->push('File Uploads', route('student.files'));
});

//File Uploads
Breadcrumbs::register('cronJob', function($breadcrumbs) {
    $breadcrumbs->push('Cron Job', route('cronJob'));
});

//About Team
Breadcrumbs::register('about.team', function($breadcrumbs) {
    $breadcrumbs->parent('dashboard');
    $breadcrumbs->push('Meet the Team', route('about.team'));
});

//Attendence New
Breadcrumbs::register('attendance.new', function($breadcrumbs) {
    $breadcrumbs->parent('dashboard');
    $breadcrumbs->push('Attendance', route('attendance.new'));
});

//Attendence Add
Breadcrumbs::register('attendance.add', function($breadcrumbs) {
    $breadcrumbs->parent('dashboard');
    $breadcrumbs->push('Daily Attendance', route('attendance.add'));
});

//HR Movement
Breadcrumbs::register('relocation.assignUser', function($breadcrumbs) {
    $breadcrumbs->parent('dashboard');
    $breadcrumbs->push('Relocation', route('relocation.assignUser'));
});

//Promotions
Breadcrumbs::register('promotion.assignUser', function($breadcrumbs) {
    $breadcrumbs->parent('dashboard');
    $breadcrumbs->push('Promotion', route('promotion.assignUser'));
});
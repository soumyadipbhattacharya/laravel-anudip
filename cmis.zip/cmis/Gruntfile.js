module.exports = function(grunt) {

    // 1. All configuration goes here 
    grunt.initConfig({
        pkg: grunt.file.readJSON('package.json'),
        sass: {                                 // Task
            dist: {                            // Target
              options: {                       // Target options
                style: 'expanded'
            },
            files: {                         // Dictionary of files
                'public/styles/css/materialize.css':'public/vendor/materialize/sass/materialize.scss',
                'public/styles/css/font-awesome.css':'public/vendor/font-awesome/scss/font-awesome.scss',
                'public/styles/css/hover.css':'public/vendor/hover/scss/hover.scss',
                'public/styles/css/app.css':'resources/assets/sass/style.sass'
            }
        }
    },
    uglify: {
        dist: {
            files: {
                //destination files:source files
                'public/scripts/min/jquery.min.js': 'public/vendor/jquery/core/jquery.js',
                'public/scripts/min/jquery-ui.min.js': 'public/vendor/jquery/ui/jquery-ui.js',
                'public/scripts/min/materialize.min.js': 'public/vendor/materialize/js/bin/materialize.js',
                'public/scripts/min/app.min.js': 'public/scripts/app.js',
                'public/scripts/min/freshslider.min.js': 'public/vendor/freshslider/freshslider.js',
                'public/scripts/min/typeit.min.js': 'public/vendor/typeit/typeit.min.js',
                'public/scripts/min/clockpicker.min.js': 'public/vendor/clockpicker/clockpicker.js',
                'public/scripts/min/pace.min.js': 'public/vendor/pace-loader/pace.min.js'
            }
        },
    },
    cssmin: {
        target: {
            files: [{
              expand: true,
              cwd: 'public/styles/css/',
              src: ['*.css', '!*.min.css'],
              dest: 'public/styles/min/',
              ext: '.min.css'
          }]
      }
  },
  concat: {   
            css: {
                src: ['public/styles/min/materialize.min.css',
                'public/styles/min/font-awesome.min.css',
                'public/vendor/animate/animate.css',
                'public/styles/min/hover.min.css',
                'public/vendor/freshslider/freshstyle.css',
                'public/styles/min/mixins.min.css',
                'public/vendor/clockpicker/clockpicker.css'
                ],
                dest: 'public/styles/css/vendor.min.css'
            }
        },
        watch: {
            scripts: {
                files: ['public/scripts/app.js',
                'resources/assets/sass/*.sass'
                ],
                tasks: ['sass','cssmin','concat','uglify'],
                options: {
                    spawn: false,
                },
            } 
        }
    });

    // 3. Where we tell Grunt we plan to use this plug-in.
    grunt.loadNpmTasks('grunt-contrib-sass');
    grunt.loadNpmTasks('grunt-contrib-uglify');
    grunt.loadNpmTasks('grunt-contrib-cssmin');
    grunt.loadNpmTasks('grunt-contrib-watch');
    grunt.loadNpmTasks('grunt-contrib-concat');

    // 4. Where we tell Grunt what to do when we type "grunt" into the terminal.
    grunt.registerTask('default', ['sass','cssmin','concat','uglify','watch']);

};